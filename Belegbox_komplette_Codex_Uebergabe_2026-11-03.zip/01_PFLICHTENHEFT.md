# Belegbox – vollständiges Pflichtenheft für Codex

Stand: 03.11.2026. Sprache der App: Deutsch. Zielgerät zuerst Android/Samsung. Bestehendes Flutter-Projekt weiterführen. Priorität: Nutzerbelege sicher behandeln, keine Funktion verlieren.

## A. Ziel und Bedienablauf

Die Belegbox erfasst Kassenbons, Rechnungen und mehrseitige Lieferantenbelege. Sie macht aus jedem Beleg eine PDF, ermittelt die Belegdaten und sortiert nach dem **auf dem Beleg stehenden Rechnungs-/Belegdatum**, nicht nach dem Scan- oder Upload-Datum. Ablage zuerst lokal, danach auf ein gewähltes Cloud-Ziel. Die Oberfläche soll auch für 1.000 Belege pro Jahr und zehn Jahre gut bedienbar bleiben.

**Normaler Ablauf:** App öffnen → Dokument automatisch erkennen oder manuell aufnehmen → 1–n Seiten prüfen/korrigieren → (mit Zustimmung) ChatGPT-Auswertung → editierbare Felder prüfen → PDF speichern → optional cloudseitig übertragen → Übertragung prüfen → ggf. nur nach aktivierter Löschoption lokale Kopie entfernen → Eintrag im Archiv dauerhaft behalten und öffnen können.

## B. Scan und PDF-Import

- Android-Dokumentenscanner erkennt vier Dokumentecken, markiert Ränder, richtet Perspektive gerade, schneidet Hintergrund ab und löst bei stabil erkannter Seite automatisch aus. Manueller Auslöser bleibt vorhanden. Nutzer kann Belegecken nachkorrigieren.
- Mehrseitig: nacheinander mehrere Seiten aufnehmen, Seitenvorschau mit Entfernen/Reihenfolge prüfen, daraus **ein PDF** pro Rechnung. Auch Fotos aus Galerie zulassen.
- PDF-Rechnung importieren: mehrseitige bestehende PDFs auswählbar; v0.5.2-Stand konvertiert bis zu 25 Seiten zur Bildvorschau. Original-PDF bei elektronischen Rechnungen **unverändert als Original** aufbewahren; für steuerliche Zwecke nicht nur die gerasterte Neufassung. Manuelles Zuschneiden einzelner Seiten möglich. Verbesserung der Originaldatei-Archivierung als eigene sicherheitsrelevante Aufgabe.
- Bilder auf sinnvolle Größe verkleinern (Richtwert ca. 1,5–2 MB pro Foto, ohne unleserliche Kleinbeträge), EXIF-/Drehung korrigieren; Schrift und Beträge lesbar.
- Standby/Netzwerkunterbrechung darf keine bereits gespeicherte PDF zerstören; Background-Upload soweit Android-rechtlich/technisch möglich zuverlässig mit Neustart/Retry gestalten.

## C. Beleg-Erkennung

- Lokale OCR als Ausweichlösung (Google ML Kit auf Android), offline soweit Modell vorhanden, keine Netzwerkpflicht.
- Optional OpenAI-/ChatGPT-Erkennung aus den tatsächlichen Belegbildern: Firma, Rechnungsdatum, Bruttosumme, Netto, MwSt., Rechnungsnummer, Einzelpositionen und Zahlungsart.
- Zahlungsart: **K** = Kasse (bar), **B** = Bank (EC/Girocard, Debit-/Kreditkarte, Überweisung, vergleichbare bargeldlose Zahlung), **U** = unbekannt. Bei Unsicherheit kein B/K erfinden.
- Sämtliche erkannte Felder vor endgültiger Speicherung bearbeitbar. Beträge centgenau; Großhändler-Rechnungen können mehrere Seiten umfassen, sodass die Gesamtsumme richtig erkannt wird.
- ChatGPT-Bildfreigabe **einmalig explizit** erteilen, speichern, jederzeit widerrufen. Bei weiteren Scans nicht jedes Mal erneut bestätigen. Den mehrseitigen Scan zuerst fertigstellen, dann automatisch auswerten, wenn Zustimmung und Berechtigung vorliegen. Keine Bilder ohne Erlaubnis senden.
- Anmeldung mit vorhandenem ChatGPT-Konto über offiziellen Browser/OAuth, keine Passworteingabe durch Belegbox. Der Nutzer wünscht kostenpflichtig berechtigte ChatGPT-Konten als Voraussetzung für KI-Nutzung; Zugang nur anhand einer tatsächlich belegbaren OpenAI-Berechtigung. Ohne Berechtigung lokale OCR und Grundfunktionen weiterhin nutzbar, oder klar verständliche Meldung – Produktzugang nicht fälschlich aufgrund selbst gemeldeter Tarifangaben vergeben. Fehlermeldungen unterscheiden DNS, Anmeldecode, Token, Einwilligung, Limit und Modellzugang.

## D. PDF-Datei und Ablage

- **Genau ein logischer Hauptordner** `PDF-Eingang`, darunter immer `YYYY/MM` nach Rechnungsdatum, lokal und NAS/Cloud soweit unterstützt.
- Muster: `PDF-Eingang/2026/10/2026-10-12_OBI_37,95_B.pdf` bzw. `_K.pdf`, `_U.pdf`.
- Firma für Dateinamen normieren; keine ungültigen oder unsicheren Dateinamen; Kollisionen deterministisch als `_2`, `_3` …, nie fremde PDF überschreiben.
- Der Beleg enthält Originalabbildungen **aller** Seiten und gut lesbare KI-Auswertung, soweit vorhanden. Elektronische PDF-Originale separat unverändert behalten.
- Lokal zunächst im geschützten App-Speicher. Anzeigen/Öffnen per App; optional Export über Android-Dateiauswahl nach `Dokumente/Belegbox/...`. Im Archiv einen Knopf **„Lokalen Speicherort öffnen“** und klare Anzeige des tatsächlichen Speicherortes/Status.

## E. Belegarchiv – neu noch zu programmieren

**Die bereits gewünschte Ansicht genau so umsetzen:**

```
Meine Belege
▾ 2026
    ▾ 10/2026 – Oktober (87 Belege)
         12.10.2026  OBI          37,95 €  [B] [NAS]
         08.10.2026  HORNBACH     85,60 €  [K] [Lokal]
    ▸ 09/2026 – September (104 Belege)
▸ 2025
▸ 2024
```

- Jahr auf-/zuklappen; darin Monat `MM/YYYY – Monatsname (N Belege)` auf-/zuklappen; die neueren Jahre und Monate oben, Belege innerhalb eines Monats nach Rechnungsdatum absteigend, bei Gleichstand stabile zweite Sortierung.
- Gruppierung anhand **Rechnungsdatum**: am 3. November gescannter Beleg vom 12. Oktober steht unter **10/2026**.
- Zähler pro Monat, klare K/B/U-Anzeige und Cloudstatus: lokal, Upload offen, verifiziert auf Synology/QNAP, beim Google/OneDrive-Provider geschrieben aber Server-Sync unbestätigt, fehlend/Fehler.
- Antippen öffnet die PDF; liegt sie nur auf NAS, bei erreichbarer NAS temporär herunterladen, Prüfsumme vergleichen und öffnen. Offline entsprechend anzeigen. Keine dauerhafte Doppelkopie ohne Freigabe.
- Auch nach erfolgreichem NAS-Upload und Entfernen der lokalen PDF bleibt der Beleg im Archiv sichtbar.
- Schnell bei 10 Jahren und 10.000+ Belegen: Index verwenden, gruppierte/lazy und performant dargestellte Liste, nicht bei jedem Öffnen alle Dateisysteme vollständig durchsuchen.
- Bestehende Funktion „Belege“ entsprechend umbauen, keine Parallel-App.

## F. Cloud-Speicherziele

1. **Synology NAS (Hauptziel)** über HTTPS/WebDAV, **ohne VPN-Voraussetzung**. Eine öffentliche oder lokal erreichbare sichere WebDAV-Adresse wird vom Nutzer selbst konfiguriert. Vorhandene Freigaben/Unterordner wie `Daten/Belege/Eingang` müssen funktionieren; PROPFIND/Ordnerprüfung, MKCOL nur für fehlende `YYYY/MM`, Upload, verifizierter GET/SHA-256-Vergleich, präzise Fehlermeldungen. Keine TLS-Warnung ignorieren; kein QuickConnect als WebDAV-URL vortäuschen.
2. **QNAP NAS** mit eigenem HTTPS/WebDAV-Zugang, gleichen Sicherheits- und Ordnerregeln.
3. **Google Drive** als Speicherziel über Android-Dateianbieter/Ordnerdialog (bestehender Ansatz).
4. **Microsoft OneDrive** analog über Android-Dateianbieter/Ordnerdialog.

Cloud-Ziel auswählbar; vorhandene Belege müssen weiterhin auf ihr ursprüngliches Ziel zeigen, auch wenn später der Anbieter gewechselt wird. Keine unangekündigte Mehrfachkopie in andere Clouds. Für Google/OneDrive vorerst keine automatische Löschung der lokalen Datei, solange Server-Sync nicht nachweisbar abgeschlossen ist. Eventuell später Provider-API zur bestätigten Synchronisation ergänzen.

## G. Upload und automatische lokale Löschung

- Immer zunächst lokal speichern und im Archiv indexieren, auch bei Funkloch oder nicht eingerichteter Synology.
- Uploads nach Fehler später wiederholen, ohne Duplikate zu erzeugen; eindeutige Ziel-URI und erwartete SHA-256 speichern.
- Nach erfolgreichem NAS-Upload remote vollständig abrufen und SHA-256 vergleichen. **Erst dann und nur mit eingeschalteter Einstellung** lokale PDF löschen. Beim allerersten Test standardmäßig ausgeschaltet.
- Bei fehlender Freigabe, Credential-Fehler, Zertifikatsproblem, unvollständiger Datei oder Prüfsummenabweichung lokale Datei und Belegeintrag behalten; Fehler anzeigen.
- Alle Datentransitionen transaktionssicher gestalten; App-Absturz nach Upload, aber vor Statusspeicherung, darf keine Daten verlieren.

## H. Datensicherung, Textdatei, Wiederherstellung

- Ein frei wählbarer externer Sicherungsordner, der außerhalb des bei Deinstallation gelöschten privaten App-Verzeichnisses liegt, z. B. Android `Dokumente`.
- **`.bbx` verschlüsselte Vollsicherung** mit lokalen PDF-Dateien, Belegdaten und nötigen Einstellungen; mit starkem Kennwort. Prüfen, dass Backup geschrieben, lesbar und entschlüsselbar ist, bevor Erfolg gemeldet wird. Vorhandene Backups nicht still überschreiben.
- **`.json` Belegliste als lesbare Textdatei** mit ID, Name, Belegdatum, Betrag, Zahlungsart, Cloud-Ziel, validierter Remote-URI und Hash. Ohne PDFs, Passwörter, Tokens und absolute Android-Pfade. Für Wiederherstellung der Verknüpfungen zu bereits vorhandenen NAS-PDFs. Nie als vollständigen Backup-Ersatz ausgeben.
- Wiederherstellen nach Neuinstallation: `.bbx` setzt lokale PDFs und Index wieder ein; `.json` verknüpft belegbar vorhandene NAS-Dateien. Duplikate anhand stabiler ID+Hash vermeiden, keine alten Pfade übernehmen, Konflikte und fehlende NAS verständlich anzeigen, keine vorhandene PDF überschreiben. Nach Wiederherstellung vor Öffnen NAS-Kopie bei Bedarf überprüfen.
- Backup-Metadaten bei jeder neuen Rechnung, bestätigtem Upload **und Löschung** aktualisieren, damit der Index stimmt. Bestehende Alt-Backups können gelöschte Belege enthalten: dem Nutzer erklären und kontrollierte Bereinigung erlauben. Kein unbeabsichtigtes Wiederauftauchen gelöschter Dateien.
- Betriebssystemseitige Android-Funktion `hasFragileUserData` kann optional helfen, ist aber kein Ersatz für externe Sicherung. Android kann App-Deinstallation nicht immer über die App selbst mit eigener Ja/Nein-Abfrage steuern.
- Wiederherstellung und Update zuerst mit Testdaten erproben. **Bestehende Belegbox auf dem Handy niemals vor Sicherung deinstallieren.**

## I. Einzelnen Beleg gezielt löschen

- In der Belegübersicht je Beleg **ein Papierkorb-Knopf**.
- App ermittelt, wo die Datei liegt. Vor unwiderruflichem Löschen zeigt sie **Dateiname, Ziel (nur lokal / NAS und lokal)** und eine ausdrückliche Bestätigung. Besteht eine NAS-Kopie, prüft sie die eindeutige Datei, den Hash und die Benutzerberechtigung, bevor sie WebDAV DELETE ausführt; danach prüfen, dass sie nicht mehr erreichbar ist. Index erst konsistent aktualisieren, keine andere Datei anfassen.
- **Wenn auch lokal vorhanden, beide Kopien** nach eindeutiger Bestätigung löschen; bei NAS-Fehler lokale PDF erhalten. Bei nur lokalem Beleg nur lokal löschen. Bei Google/OneDrive keine ungeprüfte Fernlöschung behaupten; sinnvolle Meldung/Alternative.
- Stornieren muss garantiert nichts löschen. Fehler/Abbruch transparent protokollieren, Wiederholung ermöglichen.
- Vergangenheits-Backups können Kopien enthalten, auf diesen Umstand hinweisen.

## J. Info und Rechtliches

- Button „Info & Rechtliches“ oben oder unten. Projektname, Version/Build, Veröffentlichungsdatum, HGI KG als Herausgeber/Rechteinhaber nach Prüfung, Urheberhinweis, Beta-/Teststatus, fehlende abgeschlossene DSGVO-Prüfung, externe Übertragungsziele, Datenspeicherung und Risiken.
- Nutzungsbedingungen/Haftungshinweis als **Entwurf**, keine Aussage, dass pauschaler Haftungsausschluss immer gilt. Für öffentliche Bereitstellung fachlich/juristisch prüfen.
- Verantwortlichkeit für Daten beim Nutzer transparent machen; App muss gleichwohl angemessene technische Sicherheit gewährleisten. OpenAI-Bildübertragung nur mit Einwilligung, lokale OCR separat.
- Genaue App-Versionsnummer im Info-Bereich automatisch aus Build-Metadaten verwenden, keine veraltete fest codierte Zahl.

## K. Bedienung/Qualität

- Große Schaltflächen und Navigationsleiste über Android-Systemnavigation, korrekt mit SafeArea.
- Scannen und Cloud-Ablage einzeln testbar: Scanner, lokale OCR, ChatGPT, PDF, Jahres-/Monatsansicht, Backup, Restore, NAS, Google/OneDrive, Delete.
- Wenig Speicherverbrauch, PDF-Qualität ausreichend für Steuerbelege, lesbare Fehlermeldungen, keine versteckten Datenverluste.
- Standby-/Hintergrundupload und Wiederaufnahme nach Netzwechsel nach Möglichkeit implementieren; tatsächliche Android-Beschränkungen ehrlich benennen.

## L. Umsetzungsetappen

**Etappe 1 – jetzt:** Android-Beta sicher fertigstellen (Build reparieren, Backup/Restore/Delete prüfen, Jahres-/Monatsansicht bauen, Regression, APK mit gleichem Keystore und höherem versionCode).

**Etappe 2 – nach Android-Freigabe:** Windows-EXE und Scanner über WIA/TWAIN oder kompatible Lösung; mehrere Scannerseiten als eine PDF, Import vorhandener mehrseitiger Original-PDF. iOS/iPhone-Unterstützung danach separat planen und auf Apple-Gerät testen. Nicht als bereits fertige EXE oder IPA deklarieren.
