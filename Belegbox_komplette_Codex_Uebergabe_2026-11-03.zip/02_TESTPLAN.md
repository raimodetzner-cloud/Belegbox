# Test- und Abnahmeplan für Codex – Belegbox

Codex soll Tests ausführen und einen Ergebnisbericht mit **BESTANDEN / FEHLER / NICHT GETESTET** schreiben. Mock-Daten statt echter Privatbelege verwenden. User-Cloud nur mit bewusst angelegten Testbelegen ansprechen.

## Build/Update

1. `flutter --version`, `flutter pub get`, `flutter analyze`, `flutter test`, `flutter build apk --release --target-platform android-arm64` dokumentieren.
2. App-ID `de.dnh24.belegbox.beta` unverändert; `versionCode` > 13; Zertifikat-Fingerprint identisch zur vorhandenen Beta. Ohne originalen Schlüssel **keine Updatebehauptung**.
3. Bestehende Belege, Sicherung, NAS-Einstellungen und OpenAI-Anmeldung nach Update erhalten (falls Betriebssystem sie nicht selbst widerruft).
4. APK-Inhalt, Installierbarkeit und Start auf realem Android/Samsung testen; keine Android-R8/ML-Kit-NullPointerException.
5. Fehlendes Font-Asset vor Build sauber lösen, ohne fremde Schriftdatei aus dem Handoff zu verwenden.

## Scan, KI, PDF

6. OBI/HORNBACH/Elektrogroßhandel: richtige Firma, Belegdatum, Endbetrag, Zahlungsart K/B/U; schlechte oder unklare Belege bleiben editierbar.
7. Dokument automatisch erkennen/auslösen/zuschneiden; manuell auslösen, Ecken korrigieren, nicht den Tisch miterfassen.
8. 4-Seiten-Rechnung: **ein** PDF in richtiger Reihenfolge, keine Seite verloren. PDF-Original nach Import unverändert archivieren.
9. Einmalige ChatGPT-Bildfreigabe; Folgebelege ohne Wiederholungsdialog; Widerruf funktioniert; keine Bildübertragung ohne Freigabe.
10. Nicht angemeldet/kein Planrecht/Limits/DNS-Fehler: verständliche Nachricht, kein Datenverlust.

## Pfad/Ablage/Archiv

11. Belegdatum 12.10.2026, Scandatum 03.11.2026 => Ordner **2026/10**, Dateiname `2026-10-12_<FIRMA>_<BETRAG>_<K|B|U>.pdf`.
12. Namensgleiches PDF erhält `_2` statt Überschreiben. Umlaute/Sonderzeichen/Längen und Path-Traversal testen.
13. Archiv zeigt `2026 > 10/2026 – Oktober (N Belege)`; aufklappen/zu; Belege nach Belegdatum absteigend; auch 2025, 2024. 10.000 synthetische Belege ohne spürbare UI-Blockade testen.
14. Nur-NAS-Beleg bleibt in Archiv; Antippen lädt/verifiziert Remote-PDF; bei offline NAS verständliche Meldung.
15. Gespeicherter PDF-Beleg direkt antippbar. Lokalordner anzeigen/öffnen/exportieren ohne Systemrechte.

## Synology/QNAP

16. Ziel `https://nas.example:5006` plus Unterordner `Daten/Belege/Eingang` -> bestehende Segmente prüfen, `2026/10` neu anlegen, PDF PUT/GET/SHA-256.
17. Unterordner fehlt / 401 / 403 / 404 / 405 / Redirect / TLS-Zertifikat / falscher Port / DNS / Offline => präzise Meldung; lokale Datei bleibt.
18. Erfolgreicher PUT ohne passenden GET-Hash => lokales PDF **nicht** löschen.
19. Löschoption aus => lokal immer behalten; an + exakter GET-SHA-256 => lokal erst danach entfernen.
20. Upload unterbrechen, App abstürzen lassen, Netzwechsel, erneuter Upload => keine Duplikate und kein verschwundener Indexeintrag.

## Google Drive / OneDrive

21. Android-Ordnerauswahl pro Anbieter; PDF unter `PDF-Eingang/Jahr/Monat`; lokal weiterhin vorhanden, bis echte Server-Verifikation möglich ist.
22. Fehlende Berechtigungen und abgemeldeter Provider sauber behandeln; keine Aussage „auf Server gesichert“, wenn nur Provider-Zwischenspeicher bestätigt ist.

## Backup / Restore

23. Lokaler Testbeleg + NAS-Testbeleg → `.bbx`-Sicherung und `.json`-Belegliste; Dateiintegrität und Lesbarkeit prüfen.
24. `.json` enthält keine Passwörter, Tokens, lokale absolute Pfade oder PDF-Inhalte. JSON allein stellt **keinen** rein lokalen Beleg wieder her.
25. Vollsicherung in frischer Testinstallation einspielen → PDF vorhanden, Daten korrekt; NAS-Belege verknüpft; doppelt importieren erzeugt keine Duplikate.
26. Falsches Sicherungskennwort, beschädigte Datei, manipulierte Pfade, doppelter Name mit anderem Inhalt → Abbruch ohne Überschreiben.
27. Nach NAS-Upload und nach Löschung Backup/Index aktualisiert; alte Backups nicht stillschweigend gelöscht, Warnung zu gelöschten Belegen.

## Löschen

28. Storno im Löschdialog: unveränderte PDF lokal/NAS und Eintrag.
29. Nur lokaler Testbeleg: nach bestätigtem Löschen verschwinden genau Datei und Eintrag.
30. NAS-Testbeleg: Remote-Hash passend → Delete → Remote-Abwesenheit bestätigen → lokale Kopie/Index entfernen. Bei Fehler oder Hashabweichung **nicht** lokal entfernen.
31. Wenn NAS-Delete erfolgreich, aber lokaler Indexschritt fehlschlägt: Wiederanlauf darf keine vorhandenen Belege überschreiben oder verwaiste Zustände falsch deklarieren.
32. Google/OneDrive: Kein unbelegt behauptetes Fernlöschen; klarer Hinweis.

## Rechtliches/Datenschutz

33. Infoseite HGI KG, echte Build-Version, Beta, keine geprüfte DSGVO-Konformität, Datenflüsse, rechtlicher Entwurf sichtbar.
34. Keine API-Schlüssel, NAS-Passwörter, OAuth-Refresh-Tokens, reale Belege oder private Zertifikate im Repo, Log oder Testbericht.

**Endabnahme erst nach Tests 1–34**, mit extra Rubrik für reale End-to-End-Tests, die Codex ohne Nutzergerät/NAS-Zugang nicht selbst ausführen kann.
