# Technischer Bestand und bekannte Risiken

**Geprüfter Übergabestand:** Quellarchiv `Belegbox_0.5.2_Beta_Quellcode_Wiederherstellen_Loeschen.zip` aus dieser Unterhaltung. Das Archiv war lesbar, enthält Flutter-Projekt und Tests. **Der Quellcode wurde in dieser Sitzung nicht mit Flutter kompiliert oder ausgeführt** (Flutter/Dart fehlen in der Laufzeit). Kein Anspruch auf Fehlerfreiheit der 0.5.2.

## Quelle und technische Eckdaten

- Projekt: Flutter; `pubspec.yaml`: `version: 0.5.2+13`, Dart SDK `>=3.12.0 <4.0.0`.
- Android-App-ID aus `android/app/build.gradle.kts`: `de.dnh24.belegbox.beta`; minSdk 24.
- Flutter-Einstieg und UI: `lib/main.dart`.
- Modelle: `lib/models/receipt.dart`, `lib/models/receipt_analysis.dart`.
- Scan/OCR/Bildausschnitt/PDF: `lib/services/document_capture_service.dart`, `scan_service.dart`, `image_crop_service.dart`, `pdf_service.dart`, Android-Kotlin `MainActivity.kt`.
- OpenAI/OAuth: `lib/services/chatgpt_auth_service.dart`, `chatgpt_receipt_service.dart`, `dns_retry.dart`.
- Synology/QNAP: `lib/services/synology_service.dart` mit Zielpfad, Upload, Prüfsumme, Download, DELETE.
- Cloud via Android: `lib/services/cloud_folder_service.dart` und Kotlin-Bridge.
- Lokal/Metadaten: `lib/services/local_archive.dart`, `receipt_paths.dart`.
- Backup: `lib/services/backup_service.dart`, native `android/app/src/main/kotlin/de/dnh24/belegbox/BackupBridge.kt`.
- Ordneransicht: `lib/widgets/local_folder_page.dart`; Info: `lib/widgets/info_page.dart`.
- Tests: `test/*.dart`, darunter `manifest_delete_test.dart`, `backup_restore_test.dart`, `synology_settings_test.dart`.
- Originales `README.md` und `TESTPLAN_0.5.2.md` liegen unter `Quellcode/belegbox/`.

## Aktueller Status – belastbar unterscheiden

- Der Nutzer meldete: Android-Scanner und direkte NAS-Übertragung in **0.5.1** funktionieren gut.
- Die frühere Assistenz schrieb für 0.5.1 von **49 erfolgreichen Tests**, der hier gegebene Quellstand 0.5.2 **wurde dagegen nicht kompiliert**. Codex soll Tests selbst frisch laufen lassen.
- 0.5.2 führt JSON-Manifest und NAS/local DELETE im Quellcode ein. In `main.dart` wird die Liste derzeit weiterhin flach per `for (final receipt in _receipts)` dargestellt. Die **Jahr-/Monat-Klappansicht ist zu implementieren**.
- Android PDF Import ist ein bestehender Ansatz (Original-PDF nur als Bilder weiterverarbeitet); steuerlich relevante elektronische Originaldateien müssen zusätzlich behalten werden.
- Windows/Apple-Projektgerüste sind vorhanden, **keine abgenommene EXE/IPA**.

## Vor der Weiterarbeit gezielt auditieren

1. **Signing:** Der Gradle-Release-Block hat `signingConfig = signingConfigs.getByName("debug")`. Der ursprüngliche private Beta-Update-Keystore ist separat verwahrt, nicht in dieser Übergabe. Für ein updatefähiges Release Zertifikat-/Fingerprint-Gleichheit nachweisen. Eine bloße Behauptung „gleiches Paket“ reicht nicht.
2. **Fehlende Schrift-Datei:** PDF-Service ruft `rootBundle.load('assets/fonts/DejaVuSans.ttf')` auf, `pubspec.yaml` referenziert sie. Schriftdatei wurde im Übergabepaket absichtlich entfernt. Auf legalem Weg passende Unicode-Font-Resource bereitstellen und testen.
3. **Wiederherstellungstext:** `LocalArchive.exportManifestJson()` leert `localPath`, `cloudDocumentUri`, entfernt `analysis`. `mergeFromManifestJson()` soll ausschließlich bestätigte NAS-Einträge übernehmen. Vor Import gefährliche Remote-URIs, Status-Spoofing, fehlende SHA-256 und Duplikate prüfen. Bei geöffnetem NAS-Beleg remote erneut prüfen.
4. **Dateilöschung:** `main.dart::_deleteReceipt` führt nach NAS-Erfolg `deleteRemoteCopy`, `markRemoteDeleted` und `deleteReceipt` nacheinander aus. Für Crash zwischen diesen Schritten robusten Zustand/Recovery (Journal oder idempotente Wiederaufnahme) vorsehen. Kein anderer Beleg darf betroffen sein.
5. **Vollsicherung:** `BackupService` nimmt derzeit ggf. `chatgpt_connection_v1` und NAS-Zugangsdaten in die verschlüsselte `.bbx` auf. Passphrase-Schutz, Speicherort, Schlüsselableitung und Laufzeitverhalten auditieren; Tokens nach Neuinstallation lieber neu freigeben/erneuern, nie im JSON exportieren.
6. **Backup nach Änderung:** Sicherstellen, dass jede erfolgreiche Änderung an Belegen und Remote-Status die Sicherung konsistent aktualisiert, ohne dass Sicherungsfehler die lokale PDF zerstören.
7. **Android-Bridge:** Großes, privates Backup kann viele PDFs enthalten. Speicherverbrauch, Größenlimits, temporäre Entschlüsselungsdateien, Unvollständigkeit und Wiederanlauf sichern. Speicherberechtigung per SAF ohne breite Dateisystemrechte.
8. **Remote-Konfiguration:** URLs dürfen keinen Benutzernamen/Passwort einbetten; Pfadsegment-Encoding, Redirects, Symlinks, nicht vorhandene Freigaben, Doppel-MKCOL und sichere TLS-Verifikation testen.
9. **OpenAI:** Die bisherige Anmeldung über offiziellen Browser/OAuth soll erhalten bleiben. Token-Wiederholung bei DNS-Fehler war für den Nutzer relevant. OAuth-Scopes, Token-Refresh, Entitlement, Consent und Modellzugang an aktuellen offiziellen Unterlagen prüfen.
10. **Speicherindex:** `LocalArchive.list()` sortiert derzeit nach `createdAt`, nicht `invoiceDate`; bei Implementierung des Jahr-/Monat-Archivs umstellen, stabiler Sortierschlüssel/Performance und Migration beachten.
11. **Bildarchiv:** QR-Codes, Kundendaten, Rechnungsnummer und die tatsächlichen Positionen werden ggf. extern verarbeitet. Anzeigen, welche Daten an OpenAI gehen; keine unnötigen Belegdaten in Diagnoselogs.
12. **Alte Dokumente:** Vorhandene Einträge ohne `sha256Digest`/`remoteUri` können aus älteren Versionen stammen. Nicht ohne Nachprüfung löschen oder fälschlich als verifiziert kennzeichnen.

## Quellen für OpenAI-Authentisierung (Stand der Übergabe)

- https://developers.openai.com/siwc/quickstart
- https://developers.openai.com/siwc/token-sharing-open-source/errors-and-recovery
- https://developers.openai.com/cookbook/articles/sign-in-with-chatgpt
- https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus
- https://help.openai.com/en/articles/9039756-managing-billing-for-chatgpt-and-the-api-platform

Die offiziellen Dokumentationen bestätigen grundsätzlich „Sign in with ChatGPT“ und eine gesondert genehmigte Plan-Nutzung für berechtigte Nutzer/Apps; diese ist nicht identisch mit beliebiger, im ChatGPT-Plus-Preis enthaltener Standard-API-Nutzung. Codex soll nicht versuchen, den Login durch private Browsercookies/Passwortweitergabe zu ersetzen.
