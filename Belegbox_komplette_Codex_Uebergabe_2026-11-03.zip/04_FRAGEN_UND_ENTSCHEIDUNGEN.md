# Fragen an Codex – bitte vor Freigabe selbst beantworten

Diese Fragen sind **Prüfaufträge für Codex**, nicht eine Liste von Rückfragen, mit denen der Auftraggeber aufgehalten werden soll. Verwende die beschriebenen Voreinstellungen, soweit keine technische oder rechtliche Hürde dagegensteht.

1. **Kann 0.5.2 sauber gebaut werden?** Falls nein: Welche Zeile/Abhängigkeit verhindert den Build, und wie wurde sie korrigiert?
2. **Bleibt das Android-Update wirklich updatefähig?** Wurde App-ID, versionCode und Fingerprint der Signatur geprüft? Falls der originale Keystore fehlt: Codex muss ihn sicher nachfordern – bitte KEINE Deinstallation empfehlen.
3. **Erkennen und Verarbeiten von E-Rechnungen:** Wird eine ursprünglich digitale PDF unverändert behalten, während eine darstellbare Kopie mit Texterkennung entsteht?
4. **Backup wiederherstellbar?** Ist die `.bbx` in frischer Installation mit einem sicheren Test-Kennwort entschlüsselbar? Werden Dateien bytegleich verglichen? Was passiert bei Teilabbruch?
5. **Textindex korrekt begrenzt?** Kann `.json` ausschließlich NAS-Links herstellen? Kann kein lokaler Beleg aus reinem JSON „vorgegaukelt“ werden?
6. **Wird die Sicherung nach Upload und Löschvorgang aktualisiert?** Was passiert mit älteren Backups, die gelöschte PDFs enthalten?
7. **Kann ein fremder oder gefälschter Indexeintrag versehentlich eine NAS-Datei löschen?** Vor Remote-DELETE echte Serverkopie und SHA-256, Zielhost und Pfad validieren.
8. **Sind Abbrüche sicher?** Was passiert bei App-Absturz nach remote DELETE, vor lokalem Löschen? Gibt es einen konsistenten Wiederanlauf?
9. **Sind 10.000 Belege flüssig navigierbar?** Gruppiert nach Jahr/Monat/Belegdatum, nicht Uploadzeit; Index und lazy Listen statt Vollscan.
10. **Ist der Beleg nach lokaler Auto-Löschung weiter lesbar?** Öffnen über NAS-Download und Prüfsummenvergleich; offline verständliche Anzeige.
11. **Ist die ChatGPT-Freigabe wirklich persistent und widerrufbar?** Keine Bilder ohne Zustimmung; ein Scan mit mehreren Seiten wird erst nach Abschluss ausgewertet.
12. **Wird kostenpflichtige OpenAI-Nutzungsberechtigung verlässlich geprüft?** Nicht allein aus einer E-Mail oder einem angenommenen Tarif ableiten. Kontoanmeldung und Nutzungsfreigabe getrennt halten.
13. **Ist NAS-WebDAV ohne VPN sauber konfigurierbar?** Unterordner auch bei serverseitigem URL-Präfix, TLS korrekt, keine Freigaben außerhalb des Zielverzeichnisses.
14. **Warum ist Google/OneDrive „hochgeladen“?** Tatsächlicher Provider-Readback ≠ Server-Sync. UI-Wortlaut und lokale Datenaufbewahrung korrekt?
15. **Sind Recovery- und Löschdialoge verständlich?** Button nennt lokal/NAS exakt; Abbruch hinterlässt keine Änderung.
16. **Funktioniert Info & Rechtliches?** Zeigt es tatsächliche Versionsnummer, Anbieter und noch fehlende DSGVO-Prüfung ohne überzogene Rechtsversprechen?
17. **Sind alle Daten geheim?** Keine Zugangsdaten, Tokens, echte Kundenbelege oder Signaturdateien in Repo, Build-Logs, Crash-Reports oder ZIP.
18. **Wie installiert der Nutzer sicher?** Liefere genau die aktualisierbare APK und eine kurze Prüfanweisung; keine alte App löschen, bevor alle Belege gesichert sind.
19. **Welche Tests sind noch manuell offen?** Unbedingt reale Kamera, echte NAS (mit Wegwerfbeleg), gültige OpenAI-Freigabe, Backup auf Gerät und Update von alter Beta gesondert ausweisen.
20. **Welche Punkte kommen später?** Windows und iOS erst nach Freigabe Android; keine ablenkende Umsetzung jetzt.

## Vorausgewählte Produktentscheidungen

- Archiveintrag bleibt nach NAS-Speicherung und lokaler Löschung sichtbar.
- Standard-Zielordner heißt `PDF-Eingang`, Unterverzeichnisse `YYYY/MM` nach Belegdatum.
- Zahlungszeichen K = bar, B = bargeldlos, U = unbekannt.
- Auto-Löschung nach Upload standardmäßig **aus**; einschaltbar, nur nach verifiziertem NAS-GET/SHA-256.
- Ein Papierkorb pro Beleg, Dialog beschreibt den Ort, Remote-Löschvorgang nur mit Bestätigung; vorhandene lokale + NAS-Dateien bei bestätigter NAS-Löschung beide entfernen.
- Knappe Oberfläche in Deutsch, Jahres-/Monatsklappen mit Anzahl und Status.
- OpenAI-Consent einmalig und widerrufbar, niemals heimlich Daten senden.
- Mehrseitige Rechnung als ein Dokument.
- Android zuerst; Windows/iOS nachrangig.
- Wenn aktuelle Funktion bereits zuverlässig besteht: erhalten statt neu entwickeln.

## Nur wenn technisch zwingend: vom Auftraggeber anfordern

- **Originaler Android-Beta-Update-Keystore** in einem sicheren lokalen Prozess/Signierschritt; nie in öffentliche Repositorys oder ZIPs.
- Eventuell einen entbehrlichen Testbeleg und die Freigabe, konkrete NAS-Endpunkte auf einem Testgerät zu prüfen. Niemals reale Zugangsdaten in den Prompt kopieren lassen.
- Einen zuverlässigen echten Android-Testlauf für Kamera, ChatGPT, NAS und Installation.
