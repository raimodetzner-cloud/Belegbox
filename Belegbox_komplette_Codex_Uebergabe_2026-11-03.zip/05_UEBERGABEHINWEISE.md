# Inhalt dieses Übergabepakets

Dieses Paket ist für Codex bestimmt und enthält den **Quellcode**, nicht eine fertig kompilierte neue APK.

- `00_START_HIER_CODEX.md`: fertiger Hauptauftrag für Codex.
- `01_PFLICHTENHEFT.md`: sämtliche aus den bisherigen Gesprächen festgelegten Belegbox-Funktionen.
- `02_TESTPLAN.md`: prüfbare Abnahmetests, inklusive Sicherung, Löschung und Jahres-/Monatsansicht.
- `03_QUELLCODE_UND_RISIKEN.md`: Aufbau des vorhandenen Projekts und konkrete Risiken.
- `04_FRAGEN_UND_ENTSCHEIDUNGEN.md`: Codex-Prüffragen, Voreinstellungen und nur wirklich notwendige Rückfragen.
- `Quellcode/belegbox/`: bearbeitbare Flutter-Quellen aus der bestehenden Belegbox v0.5.2.

**Nicht enthalten:** APK, private Signaturdatei, NAS-Zugangsdaten, ChatGPT-Tokens, echte Belege und Schriftdateien.

**Technischer Hinweis:** Für die PDF-Erzeugung referenziert der vorliegende Code `assets/fonts/DejaVuSans.ttf`. Die Schriftdatei wurde in dieser Übergabe nicht weitergegeben. Codex muss die Font-Abhängigkeit vor dem Build sauber beheben bzw. aus einer eigenen zulässigen Quelle beziehen.

**So übergeben:** ZIP im Codex-Projekt als Quelle öffnen/entpacken. `00_START_HIER_CODEX.md` lesen und die darin stehenden Schritte nacheinander ausführen. Falls Codex keine ZIP-Datei direkt entpacken kann, auf dem Windows-PC zuerst entpacken und den Ordner als Arbeitsverzeichnis öffnen.

**Sicherheitsregel:** Bestehende Version auf dem Samsung vorerst installiert lassen und alle Belege sichern. Eine neue APK ist nur mit identischer Signatur als Update geeignet.
