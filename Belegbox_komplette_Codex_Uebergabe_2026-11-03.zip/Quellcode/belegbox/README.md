# Belegbox – Android, Windows und iPhone (Testversion 0.5.2 Beta)

Eine schlichte App zum Fotografieren von Kassenbons/Rechnungen. Sie erkennt
Firma, Rechnungsdatum und Brutto-Endbetrag per Texterkennung auf dem Handy.
Auf Wunsch liest ChatGPT über die offizielle Kontoanmeldung zusätzlich die
Belegpositionen und Zahlungsart aus. Die App zeigt die editierbaren Felder,
erstellt ein PDF mit allen aufgenommenen Seiten und einer Auswertungsseite
und speichert es per HTTPS/WebDAV **in einem freigegebenen Hauptordner mit
automatisch angelegten Jahres-/Monatsordnern**
auf einer Synology oder QNAP. Das Projekt ist unabhängig von Paperless-ngx.

## Was jetzt enthalten ist

- **Neu 0.5.1 (Android):** NAS-Verbindung direkt per HTTPS/WebDAV ohne
  VPN-Pflicht. Die App akzeptiert einen bestehenden Unterordnerpfad, z. B.
  `Daten/Belege/Eingang`, und prüft bei „Verbindung testen“ alle
  Pfadabschnitte. Auch WebDAV-Adressen mit einem Server-Präfix wie `/webdav`
  funktionieren. Fehlende Ordner, Umleitungen auf eine NAS-Anmeldeseite und
  falsche WebDAV-Ports werden genauer gemeldet. Das NAS muss im jeweiligen
  WLAN bzw. von unterwegs über einen sicheren HTTPS-Endpunkt erreichbar sein.
- **Neu 0.5.0 (Android):** Belegscanner mit Live-Dokumenterkennung,
  automatischer Auslösung, Perspektivkorrektur und sauberem Zuschnitt über
  die Google-ML-Kit-Dokumentenscanner-Oberfläche. Kameraauslöser steht auch
  manuell zur Verfügung. Beim ersten Mal können Google Play-Dienste die
  Scanner-Bestandteile herunterladen, dafür ist Internet erforderlich.
- **Neu 0.5.0 (Android):** Empfangene PDF-Rechnungen mit **„PDF-Beleg
  importieren“** auswählen. Bis zu 25 Seiten werden für OCR und Vorschau in
  hochauflösende Bilder umgewandelt. Jede Seite kann einzeln entfernt oder
  über **„Rand ändern“** manuell rechteckig zugeschnitten werden. Die App
  erzeugt anschließend wie bisher ein mehrseitiges neues Beleg-PDF.
  **Für die Steuerunterlagen elektronische Original-PDFs stets unverändert
  zusätzlich aufbewahren**, da ein umgewandeltes Bild-PDF nicht das digitale
  Original ersetzt.
- Android-/iOS-Quellcode mit Flutter und deutscher Oberfläche
- Mehrseitige Belege: Kamera mehrfach verwenden oder Galeriebilder auswählen
- Automatische OCR-Erkennung; manuelle Korrektur vor dem Speichern
- **Optional ChatGPT Plus/Pro:** Anmeldung über den offiziellen Browser mit
  „Sign in with ChatGPT“ und ausdrücklicher Freigabe der Abo-Nutzung; kein
  API-Schlüssel oder ChatGPT-Passwort in der Belegbox notwendig, wenn das
  Konto für diese Funktion berechtigt ist
- ChatGPT erkennt Firma, Datum, Endbetrag, Netto, MwSt., Belegnummer,
  Artikelpositionen und Zahlungsart; vorher muss die Bildübertragung
  ausdrücklich bestätigt werden
- **Kasse** bei Barzahlung, **Bank** bei Girocard, Kreditkarte,
  Debitkarte, Überweisung und PayPal; bei Zweifel „Unbekannt“
- Bruttobetrag centgenau, Datumsprüfung, eindeutiger PDF-Dateiname
- PDF bleibt im lokalen Archiv, auch bei Funkloch / falscher Anmeldung
- Offene Uploads können in „Belege“ später erneut übertragen werden
- Ein Synology- oder QNAP-Hauptordner „PDF-Eingang“, darunter automatisch `2026/10`,
  `2026/11` usw. nach **Belegdatum**; dieselbe Struktur wird auf dem
  Telefon lokal angelegt, auch wenn keine Synology erreichbar ist
- Dateinamen nach `2026-10-27_HORNBACH_37,95_B.pdf` (`K` = Kasse,
  `B` = Bank, `U` = Zahlung unbekannt); Namensgleichheit führt zu `_2.pdf`
- Unter „Belege“ bleiben die lokal gespeicherten PDFs sichtbar, bis die
  Verbindung zur Synology wieder zur Verfügung steht
- Zugangsdaten im geschützten Gerätespeicher; HTTPS-Zertifikate werden geprüft
- Einzelner WebDAV-Benutzer mit Schreibrechten nur im Eingangsordner empfohlen
- Windows: Bilder auswählen und lokal mit **Tesseract OCR** lesen. Für
  Windows-Fotos aus einem Scanner ist kein spezieller Gerätetreiber eingebaut.

**Vorversion 0.4.2 Beta:** Unter **Ablage → Speicherziel**
ist nun **QNAP NAS** zusätzlich zu Synology, Google Drive und Microsoft
OneDrive wählbar. QNAP nutzt HTTPS/WebDAV, mit **eigenen Zugangsdaten**,
Freigabename und Port. QTS-WebDAV muss zuvor aktiviert sein; beim Standard
eines dedizierten HTTPS-WebDAV-Ports ist `5001` häufig, kann aber in QTS
abweichend konfiguriert sein. Die Freigabe `PDF-Eingang` muss existieren;
die App erstellt darin Jahr/Monat automatisch. Hochgeladene QNAP-PDFs
werden **erneut vollständig heruntergeladen und mit SHA-256 abgeglichen**.
Die lokale Datei darf nur bei erfolgreichem Vergleich und aktivierter
Löschoption entfernt werden. Die QNAP-Einstellungen werden in die
verschlüsselte `.bbx`-Sicherung aufgenommen. QNAP wurde mit automatisierten
WebDAV-Tests überprüft; ein Test auf einem echten QNAP ist noch offen.

**Vorversion 0.4.1 Beta:** Im Bereich **Belege** gibt es
jetzt die zusätzliche Schaltfläche **„Lokalen PDF-Ordner öffnen“**. Sie zeigt
die real vorhandenen PDFs gruppiert nach Belegjahr und Monat und öffnet sie
per Antippen. Einzelne PDFs können über den Android-Dateidialog in einen
sichtbaren Ordner wie „Dokumente“ exportiert werden. Geschützte interne
App-Ordner sind im Android-Dateimanager normalerweise nicht direkt sichtbar.

Unter **Ablage → Sicherung für Neuinstallation** wird ein dauerhafter
Sicherungsordner, vorzugsweise auf dem internen Telefon-Speicher unter
„Dokumente“, mit Androids Dateiauswahl gewählt. Die App fragt ein Kennwort
mit mindestens zwölf Zeichen ab. Beim Speichern jedes neuen Belegs erzeugt
sie vor einem möglichen NAS-Upload eine **verschlüsselte AES-256-GCM-Sicherung**
mit Belegindex, lokalen PDFs und den gespeicherten Einstellungen einschließlich
Synology-/QNAP-Zugang und ChatGPT-Verbindungsdaten. Der Dateiname beginnt mit
`Belegbox-Sicherung-` und endet mit `.bbx`. Jede Sicherung wird über
erneutes Lesen und Entschlüsseln auf Beschädigung geprüft. Ältere Sicherungen
werden zum Schutz vor Datenverlust **nicht automatisch gelöscht**. Das
Sicherungskennwort ist nach Deinstallation erforderlich und darf nicht
verloren gehen; es steht nicht in der Sicherungsdatei.

Nach einer Neuinstallation lässt sich eine `.bbx` über **„Vorhandene Sicherung
wiederherstellen“** laden. Vorhandene PDFs werden dabei niemals überschrieben;
identische Belege werden anhand ihrer Kennung übersprungen. Bei vormals
gelöschten lokalen PDFs kann gegebenenfalls die gespeicherte Synology-Kopie
geöffnet werden. Android-Cloud-Ordner müssen nach Neuinstallation neu gewählt
werden; die ChatGPT-Anmeldung kann eine neue Freigabe erfordern.

Androids systemeigene Deinstallationsabfrage kann durch
`android:hasFragileUserData="true"` die Möglichkeit „App-Daten behalten“
anbieten. Das geschieht nicht bei jeder Deinstallationsart; eine externe
Sicherung bleibt deshalb nötig.

**Wichtige Migrationsgrenze:** Die ursprüngliche Belegbox v0.4.0 wurde mit
einem später nicht mehr verfügbaren Testschlüssel signiert. Die neue
Version hat deshalb vorläufig die **separate Paketkennung**
`de.dnh24.belegbox.beta`, damit sie neben der alten Version installiert
werden kann und die bestehenden Belege nicht durch eine erzwungene
Deinstallation verloren gehen. Sie übernimmt die Daten der alten App nicht
automatisch; dafür müssen die dortigen Belege zuvor auf Synology oder
anderweitig gesichert werden. Die neue Beta wird künftig mit ihrem eigenen
aufzubewahrenden Signaturschlüssel aktualisiert. Die Datei
`Belegbox_Beta_v0.4.1_Update_Signaturschluessel.keystore` ist getrennt von
den Quellcodedateien aufzubewahren und **nicht öffentlich zu verbreiten**;
die genauen Signaturzugangsdaten müssen ausschließlich aus einem sicheren lokalen Schlüsselbestand bezogen werden.
Dieser Schlüssel darf nicht für eine öffentliche Produktiv-App verwendet werden.

**Vorversion 0.4.0 Beta:** Android kann lokal gespeicherte
PDFs nun durch Antippen des Belegs mit einem vorhandenen PDF-Programm öffnen.
Die Synology-Ablage kann nach PUT dieselbe Datei wieder per GET lesen und deren
Länge und SHA-256 mit dem lokalen Original vergleichen. Nur nach diesem Test
und bei aktivierter Option **„Nach bestätigter NAS-Sicherung lokal löschen“**
wird die lokale PDF entfernt; ältere NAS-Kopien lassen sich getrennt prüfen.
Belege ohne erreichbare NAS bleiben lokal.

Unter **Ablage** kann man zwischen Synology, QNAP, Google Drive und OneDrive wählen.
Google/OneDrive nutzen den Android-Systemordnerdialog (Storage Access
Framework): Ein auf dem Telefon angemeldeter und dort sichtbarer Provider ist
Voraussetzung. Der Dialog gewährt Zugriff auf einen gewählten Ordner; darin
wird `PDF-Eingang/JJJJ/MM` erstellt. Die App prüft die an den Android-Provider
geschriebene Datei durch erneutes Lesen. **Dieser Vorgang beweist noch nicht,
dass der entfernte Google-/Microsoft-Server die Datei empfangen hat. Daher
werden diese lokalen Belege nicht automatisch gelöscht.** Google Drive und
OneDrive müssen auf dem Samsung selbst ausprobiert werden; die Cloud-Sync-
Funktionalität ist Beta.

Im oberen App-Bereich gibt es **Info & Rechtliches** mit Version, HGI-KG-
Rechten, Beta-/Haftungshinweisen und ausdrücklich noch nicht abgeschlossener
DSGVO-Prüfung. Die Texte sind rechtliche Entwürfe, keine fertigen AGB.
Eine ausdrückliche Bildfreigabe kann im ChatGPT-Bereich dauerhaft gespeichert
und jederzeit widerrufen werden. Bei mehrseitigen Belegen wird die Auswertung
weiterhin nach „Beleg fertig“ manuell gestartet, damit alle Seiten dabei sind.
Windows-EXE und direkte Windows-Scanneranbindung sind weiterhin zurückgestellt.

**Vorversion 0.3.3:** Die App wiederholt den OpenAI-Tokenabruf
bei einem vorübergehenden DNS-Auflösungsfehler bis zu fünf Mal. Sie zeigt den
Versuch an und prüft nach einem DNS-Fehler die OpenAI-Anmeldeseite erneut. Auch
die Signaturprüfung wiederholt nur fehlgeschlagene DNS-Lookups. Andere Fehler
oder von OpenAI abgelehnte Anmeldungen werden nicht wiederholt. Der erfolgreiche
End-to-End-Test auf einem echten Android-Handy steht weiterhin aus.

Seit 0.3.2: Netzwerkfehler
bei ChatGPT werden nicht mehr fälschlich als Synology-Fehler bezeichnet.
Ein neuer Knopf **„ChatGPT-Verbindung prüfen“** testet die drei HTTPS-Ziele
der OpenAI-Anmeldung und API direkt aus der App ohne Kontodaten. Im Fehlerfall
bleibt der erreichte Anmeldeschritt zur Diagnose sichtbar.

Seit Version 0.3.1: Die Browser-Rückkehr bei ChatGPT
zeigt jetzt an, dass der Anmeldevorgang in der App noch geprüft wird.
Im ChatGPT-Bereich sieht man die jeweilige Phase und eine bleibende
Fehlermeldung. Eine einmal erfolgreich gespeicherte Anmeldung wird beim
nächsten App-Start automatisch wieder geladen. Die Android-Codeoptimierung
bleibt im Release deaktiviert, weil Version 0.2.0 bei Google ML Kit eine
`NullPointerException` zeigte. Bei einem behandelbaren OCR-Fehler bleiben
die Bilder zum manuellen Eintragen erhalten. Die Änderung muss auf einem
realen Android-Telefon erneut getestet werden. Auch der ChatGPT-Anmeldefluss
muss dort einmal vollständig getestet werden. Für Windows gibt es
den lauffähig vorbereiteten Quellcode; eine Windows-EXE muss auf einem
Windows-PC mit Visual Studio gebaut werden. iOS benötigt einen Mac.

### Android-Test auf dem Samsung

1. Die APK der Beta-Version 0.5.1 auf das Android-Handy herunterladen.
   Die **alte Belegbox 0.4.0 nicht deinstallieren**. Die 0.5.1-Beta soll
   dagegen die vorhandene 0.5.0-/0.4.2-Beta direkt aktualisieren.
2. Vorher in der bisherigen Beta unter **Ablage** eine externe verschlüsselte
   Sicherung bestätigen. Dann die neue APK über die vorhandene Beta
   installieren – **nicht erst die Beta löschen**.
3. Unter „Scannen“ den neuen Knopf **„Beleg automatisch erkennen und
   zuschneiden“** testen. Google Play-Dienste erkennen den Rand, bieten
   automatische/manuelle Auslösung und geben zugeschnittene Seiten zurück.
   Die Belegbox liest danach direkt lokal Firma, Datum und Betrag.
4. Bei Bedarf bei einem Vorschaubild auf **„Rand ändern“** drücken, die
   grünen Ecken verschieben und „Ausschnitt übernehmen“ wählen.
5. Alternativ **„PDF-Beleg importieren“**, die Seiten als Bilder übernehmen,
   unerwünschte Seiten entfernen und einzelne Bildausschnitte zuschneiden.
6. Für die zusätzliche ChatGPT-Auswertung bei bestehender Kontoverbindung
   die Bildübertragung freigeben und **„Beleg fertig – mit ChatGPT erkennen“**
   drücken. Gegebenenfalls im ChatGPT-Bereich erneut anmelden.
7. Datum, Firma, Brutto-Endbetrag, Zahlungsart und Artikel prüfen;
   bei Bedarf korrigieren; anschließend „PDF speichern und hochladen“ drücken.
8. Unter „Belege“ den lokalen PDF-Ordner öffnen und die PDF ansehen.
   Elektronisch zugestellte Original-PDFs zusätzlich unverändert behalten.
9. Ohne eingerichtete Cloud bleibt das PDF lokal im App-Verzeichnis
   `Belegbox/PDF-Eingang/JJJJ/MM/`.
10. Wenn die Synology später erreichbar ist, unter „Ablage“ zunächst die
   WebDAV-HTTPS-Verbindung einrichten und dann unter „Belege“ die wartenden
   Dateien hochladen. Die App prüft und erstellt Jahr und Monat.

Die Test-APK ist weiterhin eine **Beta-Version** und nicht für den
unbeaufsichtigten produktiven Einsatz freigegeben.

## Voraussetzung auf Synology DS1821+

1. DSM Paket-Zentrum: **WebDAV Server** installieren.
2. Im WebDAV Server **HTTPS** aktivieren (standardmäßig Port `5006`).
3. Den DSM-*freigegebenen* Hauptordner (z. B. **Daten**) und darin den
   gewünschten Beleg-Unterordner (z. B. **Belege/Eingang**) vorher anlegen.
   Einen neuen DSM-Freigabeordner kann WebDAV nicht erstellen. **Jahres- und
   Monatsunterordner erstellt die App selbst**, auch für ältere Belege.
4. Benutzer `belegbox` mit einem eigenen, starken Passwort anlegen. Diesem
   Benutzer nur den nötigen Lese-/Schreibzugriff auf den Ordner geben.
5. Die App benötigt **kein VPN**. Im Heimnetz verbindet sie sich direkt mit
   der NAS-WebDAV-HTTPS-Adresse. Von unterwegs über Mobilfunk funktioniert
   dieselbe Übertragung nur dann, wenn die NAS über einen tatsächlich
   erreichbaren, sicher eingerichteten HTTPS-Endpunkt (zum Beispiel einen
   authentifizierenden Reverse Proxy) erreichbar ist. **Nicht** einfach
   einen ungeschützten WebDAV-Port ins Internet weiterleiten.
6. HTTPS braucht ein Zertifikat, dem das Mobiltelefon vertraut. Keine
   Zertifikatsprüfung deaktivieren.

In der App unter „Synology“ eintragen:

| Feld | Beispiel |
| --- | --- |
| WebDAV-HTTPS-Adresse | `https://nas.example:5006` |
| Freigegebener Belegordner / Unterordner | `Daten/Belege/Eingang` |
| Benutzer | `belegbox` |
| Passwort | Das selbst vergebene Passwort |

**Hinweis zu Version 0.5.1:** Die WebDAV-Adresse darf einen erforderlichen
Server-Präfix enthalten, z. B. `https://nas.example/webdav`. Im separaten Feld
**Freigegebener Belegordner / Unterordner** steht der WebDAV-Pfad *ab der
Freigabe*, z. B. `Daten/Belege/Eingang`. Der Name der Freigabe muss bei
Synology in DSM existieren; **Belege/Eingang** sind bereits eingerichtete
Unterordner darin. Die App prüft jeden dieser Ordner mit `PROPFIND`; fehlt
ein Ordner, erscheint sein genauer Pfad. Beim eigentlichen Upload werden nur
`JJJJ/MM` angelegt und die PDF danach erneut vollständig von der NAS geladen
und mit SHA-256 verglichen. Ein WebDAV-Test kontrolliert die Existenz und
Leseberechtigung, **Schreibrechte werden beim ersten Upload geprüft**.

Für den Zugriff aus dem Mobilfunknetz genügt eine interne IP wie
`192.168.178.20` nicht. Eine Synology-QuickConnect-Adresse ist keine
WebDAV-Adresse. Das NAS und die benötigte HTTPS-Erreichbarkeit müssen einmalig
auf der NAS/Router-Seite eingerichtet werden. Die Android-App kann das nicht
automatisch erledigen. Keine TLS-Zertifikatsprüfung umgehen.

## Voraussetzung auf QNAP (QTS)

1. **Systemsteuerung → Netzwerk und Dateidienste → Win/MAC/NFS/WebDAV → WebDAV**:
   WebDAV aktivieren. Bei älteren QTS-Versionen liegt der Menüpunkt unter
   „Anwendungen → Webserver → WebDAV“.
2. HTTPS-WebDAV und den tatsächlich eingestellten Port prüfen. Bei dediziertem
   WebDAV-Port ist `5001` ein üblicher Standard; QTS erlaubt abweichende Ports.
3. Auf QNAP eine Freigabe **PDF-Eingang** mit passenden Berechtigungen anlegen.
   Vorhandene Unterordner können ergänzt werden, z. B. `PDF-Eingang/Belege`.
   Die App erstellt darunter `2026/10` und weitere Jahres-/Monatsordner.
4. Eigenen QNAP-Benutzer mit Lese- und Schreibrechten für die Freigabe anlegen.
5. Im Bereich **Ablage → Eigene QNAP NAS** die Adresse zum Beispiel
   `https://qnap.example:5001`, Freigabe, Nutzer und Kennwort eintragen,
   **Verbindung speichern** und **Verbindung testen**.
6. Beim ersten Beleg **„Nach bestätigter NAS-Sicherung lokal löschen“**
   deaktiviert lassen und erst nach Prüfung der PDFs auf dem QNAP einschalten.
   Für Zugriff ohne VPN von unterwegs eine sichere öffentliche HTTPS-Adresse
   bereitstellen. Keine ungeschützte NAS-Freigabe ins Internet stellen.

Der QNAP-WebDAV-Zugang ist unabhängig vom Synology-Zugang. Unter **Belege**
kannst du bei weiterhin aktivem QNAP-Speicherziel offene QNAP-Uploads nachholen.
Beim Wechsel auf ein anderes Ziel behalten ältere Belege ihr ursprüngliches
Speicherziel, damit sie nicht versehentlich an eine andere Cloud gehen.

## Aus Quellcode erstellen

Flutter 3.44 / Dart 3.12 oder neuer ist erforderlich. Für Android muss ein
Android SDK bereitstehen; für iOS zwingend ein Mac mit Xcode und ein
passendes Apple-Signierungsprofil.

```bash
cd belegbox
flutter create . --platforms=android,ios,windows --org de.dnh24
dart run tool/configure_platforms.dart
flutter pub get
flutter test
flutter analyze
flutter build apk --release
```

Das Android-Paket liegt anschließend normalerweise unter
`build/app/outputs/flutter-apk/app-release.apk`. Für das iPhone erfolgt der
Build auf einem Mac mit `flutter build ipa --release` und gültiger Signierung.

### Windows starten

Auf einem Windows-11-PC werden Flutter und **Visual Studio 2022 mit
Desktopentwicklung mit C++** benötigt. Außerdem muss [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki)
mit deutschem Sprachpaket installiert sein. Dann im Projektverzeichnis:

```powershell
flutter create . --platforms=windows --org de.dnh24
flutter pub get
flutter test
flutter build windows --release
```

Die Anwendung befindet sich danach im Windows-Buildordner unter
`build\windows\x64\runner\Release\`; zum Weitergeben muss der **ganze
Ordner** einschließlich DLLs und `data` kopiert werden, nicht bloß die EXE.

Wenn Flutter, Visual Studio und Tesseract bereits eingerichtet sind, kann
`build_windows.cmd` per Doppelklick den Windows-Build durchführen. Für einen
Android-Build unter Windows gibt es `build_android_windows.cmd`. Diese Dateien
installieren keine Entwicklungswerkzeuge automatisch.

## ChatGPT und Sicherheit

- **ChatGPT Plus ist kein normaler API-Schlüssel.** Hier wird der offizielle
  OAuth-Flow für persönliche/offene Projekte verwendet. Die OpenAI-Freigabe
  und Modellverfügbarkeit sind Voraussetzung. Abo-Kontingente gelten weiter,
  sie können je nach Nutzung ausgeschöpft sein.
- Ohne aktiv bestätigtes Kästchen für die Bildübertragung werden keine
  Belegbilder an ChatGPT geschickt. Die Auswertung ruft die Responses API
  mit `store: false` und Streaming auf. Die ChatGPT-Antwort wird lokal
  gespeichert; der Originalbeleg geht als PDF an die eigene Synology.
- Die Zugangstokens liegen verschlüsselt im OS-eigenen geschützten Speicher.
  Die App kennt das ChatGPT-Passwort nicht. Unter „ChatGPT“ lässt sich die
  lokale Verbindung wieder entfernen.
- Die Offline-Texterkennung läuft auf Android/iOS über ML Kit, auf Windows
  über installiertes Tesseract. Für Offline-Erkennung ist keine Freigabe
  und keine ChatGPT-Anmeldung nötig.
- Die PDFs enthalten die Bilder der gescannten Seiten. OCR-Text wird **noch
  nicht als durchsuchbare Textebene** in die Originalbild-Seiten eingebettet;
  eine zusätzliche Textseite mit den erkannten Angaben wird angehängt.
- Lieferanten- und Betragsangaben können bei schlechten Fotos falsch erkannt
  werden. Deshalb müssen die Felder vor dem Speichern geprüft werden.
- Die App speichert lokale Sicherheitskopien. Eine Funktion zum gezielten
  Entfernen nach kontrolliertem NAS-Backup ist noch nicht eingebaut.
- Angaben zu Artikeln und Zahlungsart sind Vorschläge der KI und müssen mit
  dem Originalbeleg abgeglichen werden. Kartennummern oder andere
  Zahlungsgeheimnisse werden nicht in die Auswertung übernommen.
- PDF-Seiten werden auf A4 skaliert und Bilddateien aus Speichergründen
  verkleinert; für beweissichere Originalarchivierung ist eine gesonderte
  Prüfung von Vollständigkeit und Unverändertheit nötig.
- Kein Server wurde eingerichtet und keine Anmeldedaten wurden hinterlegt.

## Tests

`test/receipt_parser_test.dart` prüft beispielhafte OBI-/HORNBACH-Belege,
Datum und Centbeträge. `test/synology_settings_test.dart` prüft HTTPS-Zwang,
vorhandene verschachtelte WebDAV-Freigaben, URL-Präfixe und unzulässige Pfade.
`test/chatgpt_receipt_test.dart`
prüft JSON-Daten, Bank/Kasse, alte Belege und abgebrochene KI-Antworten.
`test/pdf_service_test.dart` prüft die Erstellung des PDF mit Auswertungsseite.
`test/receipt_paths_test.dart` prüft die Dateinamen mit K/B/U; die Synology-
Tests simulieren auch das automatische Anlegen von Jahres-/Monatsordnern.
Der echte OpenAI-Login und ein Live-Scan müssen auf einem Gerät getestet werden;
in automatisierten Tests wurden keine OpenAI-Zugangstokens verwendet.

## 0.5.2 Beta – Belegliste und gezieltes Löschen (29.10.2026)

**Neu:** Im bereits eingerichteten Sicherungsordner entstehen bei jeder
Sicherung zwei zusammengehörige Dateien:

- `Belegbox-Sicherung-... .bbx`: kennwortgeschützte Vollsicherung mit den
  aktuell lokal vorhandenen PDFs, sämtlichen Belegdaten und Einstellungen.
  Nach Neuinstallation unter **Ablage → Vollsicherung (.bbx) wiederherstellen**
  einlesen. Belege, die bereits nur auf der NAS liegen, werden als NAS-
  Verknüpfung übernommen. Passwort nach Neuinstallation benötigt.
- `Belegbox-Sicherung-...-Belegliste.json`: lesbare Textdatei mit ID, Name,
  Belegdatum, Betrag, Speicherziel, Sicherungsstatus und SHA-256.
  **Keine Passwörter, keine ChatGPT-Tokens, keine PDF-Dateien und keine
  absoluten Handy-Pfade.** Unter **Ablage → Belegliste (.json) und
  NAS-Verknüpfungen einlesen** kann die Liste importiert werden.
  Nur Belege, deren NAS-Upload zuvor bestätigt wurde, lassen sich damit
  wieder verknüpfen. Für reine lokale Belege ist die .bbx-Datei nötig.

**Neu:** Unter **Belege** besitzt jeder Eintrag ein Papierkorbsymbol. Erst
nach ausdrücklicher Bestätigung wird bei einem noch nicht hochgeladenen
Beleg die lokale PDF gelöscht. Bei einem bereits bestätigten Synology- oder
QNAP-Beleg prüft Belegbox die konkrete NAS-PDF per HTTPS/WebDAV,
führt ein DELETE aus, prüft das Verschwinden per GET und entfernt danach die
lokale Kopie und den Indexeintrag. Wird irgendein Schritt nicht bestätigt,
bleibt der lokale Beleg erhalten. Bei Google Drive und OneDrive ist
Fernlöschen in dieser Version bewusst nicht freigegeben, da der
Android-Dokumentanbieter die abgeschlossene Server-Löschung nicht zuverlässig
bestätigen kann.

**Achtung:** Frühere .bbx-Sicherungen enthalten gegebenenfalls auch später
gelöschte Belege. Wer diese Kopien endgültig entfernen will, muss alte
Sicherungen gesondert prüfen und löschen. JSON-Beleglisten enthalten
Rechnungsmetadaten im Klartext. Den Sicherungsordner vor unbefugtem Zugriff
schützen und ggf. nur die verschlüsselte .bbx verwenden.

Die Tests für Import, Doppelimport, lokale Löschung, WebDAV-DELETE und
abweichende PDF-Prüfsummen sind in `test/manifest_delete_test.dart`
angelegt. **Diese Projektfassung wurde in einer Umgebung ohne Flutter-SDK
bearbeitet; der neue APK-Build und die Flutter-Tests müssen noch in einer
Android-Bauumgebung ausgeführt werden.** Bisherige APK nicht deinstallieren.

### APK-Bau auf einem eingerichteten Rechner

```sh
flutter pub get
flutter test
flutter analyze
flutter build apk --release --target-platform android-arm64
```

Vor dem Bau den für Belegbox Beta 0.4.1–0.5.1 verwendeten und separat
aufbewahrten **Original-Signaturschlüssel** als Android-Debug-Keystore für
diesen privaten Beta-Build einrichten. Andernfalls akzeptiert Android die
neue APK **nicht** als Update und die bisherigen App-Daten sind gefährdet.
Keine neue Signatur erzeugen und die bestehende App nicht deinstallieren.
