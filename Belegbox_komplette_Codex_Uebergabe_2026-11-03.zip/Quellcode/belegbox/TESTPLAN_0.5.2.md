# Belegbox 0.5.2 Beta – Testplan

Bitte die bisherige Version 0.5.1 **nicht deinstallieren**. Erst mit gleichem Signaturschlüssel signiertes Update installieren und Sicherung prüfen.

## Test A – Gesicherte Belegliste

1. Ablage > Sicherung einrichten (Ordner außerhalb der App) bzw. bestehende Sicherung nutzen.
2. Einen Testbeleg speichern und ggf. zu Synology/QNAP hochladen.
3. Ablage > Jetzt Sicherung erstellen und prüfen.
4. Im Android-Dateimanager im Sicherungsordner zwei Dateien vergleichen: `*.bbx` (verschlüsselte Vollsicherung) und `*-Belegliste.json` (lesbarer Index, ohne Passwörter/PDFs).
5. Für einen echten Wiederherstellungstest ohne Deinstallation die JSON-Datei über **Ablage > Belegliste (.json) und NAS-Verknüpfungen einlesen** auswählen. Bereits eingetragene Belege müssen übersprungen werden.
6. Erst auf einem **separaten Testgerät oder mit einer sicheren Vollsicherung** die Wiederherstellung nach Neuinstallation testen. Die `.bbx` stellt lokal vorhandene PDF-Inhalte und Einstellungen wieder her, die JSON-Datei allein verknüpft nur bestätigte NAS-Belege.

## Test B – Lokalen Testbeleg löschen

1. Ein neues Test-PDF erstellen, ohne es auf die NAS hochzuladen.
2. Unter Belege auf den Papierkorb dieses Eintrags drücken.
3. Zunächst abbrechen: PDF und Eintrag müssen bleiben.
4. Erneut löschen und bestätigen: Die lokale PDF sowie der Indexeintrag müssen verschwinden; andere PDFs bleiben bestehen.

## Test C – NAS-Testbeleg löschen

1. Einen **ausdrücklich entbehrlichen Testbeleg** auf die NAS hochladen und dort öffnen.
2. Unter Belege den Papierkorb drücken; prüfen, ob Datei und Speicherort im Dialog stimmen.
3. Abbrechen: NAS-Datei muss erhalten bleiben.
4. Erneut bestätigen: App prüft die NAS-PDF, löscht gezielt die Datei über HTTPS/WebDAV, kontrolliert HTTP 404 und entfernt erst danach den lokalen Eintrag.
5. Bei ausgeschaltetem NAS, abweichendem Dateihash oder unzureichender Löschberechtigung darf die lokale PDF nicht gelöscht werden.

## Sicherheit und Grenzen

- Kein automatisches Löschen aus Google Drive oder OneDrive in dieser Testfassung.
- Alte Sicherungsdateien können nach Löschvorgängen weiterhin frühere PDFs enthalten.
- Eine JSON-Datei ist für sich genommen **kein** Beleg-Backup; sie enthält nur Metadaten und NAS-Verknüpfungen.
- Die im Projekt enthaltenen Flutter-Tests sind in der aktuellen Umgebung **nicht ausgeführt**, weil Flutter/Android-Buildwerkzeuge und deren Downloads fehlen.
- Vor produktiver Verwendung reale Scanner-, NAS- und Wiederherstellungstests durchführen.
