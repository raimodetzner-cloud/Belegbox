package de.dnh24.belegbox

import android.app.Activity
import android.net.Uri
import android.provider.DocumentsContract
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Portable AES-256-GCM backups. The passphrase is required after uninstall;
 * Android's device-bound Keystore cannot be used to decrypt a restored backup.
 * The original document directory is never modified by the extraction step.
 */
class BackupBridge(private val activity: Activity) {
    private val magic = "BBXBACK1".toByteArray(Charsets.US_ASCII)
    private val random = SecureRandom()
    private val archiveRoot: File
        get() = File(activity.applicationInfo.dataDir, "app_flutter/Belegbox")

    fun export(folder: String, password: String, info: String, manifest: String, result: MethodChannel.Result) {
        Thread {
            try {
                require(password.length >= 12) { "Sicherungskennwort muss mindestens 12 Zeichen haben." }
                val tree = Uri.parse(folder)
                val root = DocumentsContract.buildDocumentUriUsingTree(
                    tree, DocumentsContract.getTreeDocumentId(tree)
                )
                val name = "Belegbox-Sicherung-" +
                    SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(Date()) +
                    "-${System.currentTimeMillis() % 1000}.bbx"
                val uri = DocumentsContract.createDocument(
                    activity.contentResolver, root, "application/octet-stream", name
                ) ?: error("Sicherungsdatei konnte nicht erstellt werden.")

                activity.contentResolver.openOutputStream(uri, "w")?.use { stream ->
                    writeEncrypted(stream, password, info)
                } ?: error("Schreiben im Sicherungsordner nicht erlaubt.")

                // Reading the whole file back verifies the GCM tag and ZIP structure.
                val verify = File.createTempFile("belegbox_verify_", ".zip", activity.cacheDir)
                try {
                    decryptToFile(uri, password, verify)
                    require(countEntries(verify) > 0) { "Sicherungsdatei enthält keine Belegdaten." }
                } finally {
                    verify.delete()
                }
                // Portable JSON is a readable index only (no passwords or PDFs).
                require(manifest.toByteArray(Charsets.UTF_8).size <= 8 * 1024 * 1024) {
                    "Belegliste ist zu groß."
                }
                val manifestName = name.removeSuffix(".bbx") + "-Belegliste.json"
                val manifestUri = DocumentsContract.createDocument(
                    activity.contentResolver, root, "application/json", manifestName
                ) ?: error("Belegliste konnte nicht erstellt werden.")
                activity.contentResolver.openOutputStream(manifestUri, "w")?.use { stream ->
                    stream.write(manifest.toByteArray(Charsets.UTF_8))
                    stream.flush()
                } ?: error("Belegliste konnte nicht geschrieben werden.")
                activity.runOnUiThread { result.success(name) }
            } catch (failure: Exception) {
                activity.runOnUiThread {
                    result.error("backup_export", failure.message ?: "Sicherung fehlgeschlagen", null)
                }
            }
        }.start()
    }

    fun readTextManifest(documentUri: String, result: MethodChannel.Result) {
        Thread {
            try {
                val uri = Uri.parse(documentUri)
                val text = activity.contentResolver.openInputStream(uri)?.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        require(output.size() + count <= 8 * 1024 * 1024) { "Belegliste ist zu groß." }
                        output.write(buffer, 0, count)
                    }
                    output.toString("UTF-8")
                } ?: error("Belegliste nicht erreichbar.")
                require(text.contains("belegbox-belegliste-v1")) {
                    "Dies ist keine Belegliste (.json)."
                }
                activity.runOnUiThread { result.success(text) }
            } catch (failure: Exception) {
                activity.runOnUiThread {
                    result.error("manifest_read", failure.message ?: "Belegliste nicht lesbar", null)
                }
            }
        }.start()
    }

    fun restore(documentUri: String, password: String, result: MethodChannel.Result) {
        Thread {
            val staging = File(activity.cacheDir, "belegbox_restore_${System.nanoTime()}")
            val zipFile = File.createTempFile("belegbox_decrypted_", ".zip", activity.cacheDir)
            try {
                decryptToFile(Uri.parse(documentUri), password, zipFile)
                staging.mkdirs()
                val restored = extractValidated(zipFile, staging)
                require(restored > 0) { "Sicherung enthält keine Belegliste." }
                activity.runOnUiThread { result.success(staging.absolutePath) }
            } catch (failure: Exception) {
                staging.deleteRecursively()
                activity.runOnUiThread {
                    result.error(
                        "backup_restore",
                        "Sicherung konnte nicht geöffnet werden. Kennwort oder Datei prüfen.",
                        null
                    )
                }
            } finally {
                zipFile.delete()
            }
        }.start()
    }

    private fun cipher(password: String, salt: ByteArray, nonce: ByteArray, mode: Int): Cipher {
        val spec = PBEKeySpec(password.toCharArray(), salt, 220_000, 256)
        val key = try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        }
    }

    private fun writeEncrypted(raw: OutputStream, password: String, info: String) {
        val salt = ByteArray(16).also(random::nextBytes)
        val nonce = ByteArray(12).also(random::nextBytes)
        raw.write(magic)
        raw.write(salt)
        raw.write(nonce)
        val encryptor = cipher(password, salt, nonce, Cipher.ENCRYPT_MODE)
        ZipOutputStream(CipherOutputStream(raw, encryptor)).use { zip ->
            zip.putNextEntry(ZipEntry("belegbox-info.json"))
            zip.write(info.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            val root = archiveRoot
            val files = if (root.isDirectory) root.walkTopDown().filter {
                it.isFile && (it.extension.equals("pdf", true) || it.name == "belege.json")
            }.toList() else emptyList()
            for (file in files) {
                val relative = file.relativeTo(root).invariantSeparatorsPath
                require(!relative.contains("..")) { "Ungültiger Belegpfad" }
                zip.putNextEntry(ZipEntry("files/$relative"))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
            if (files.none { it.name == "belege.json" }) {
                zip.putNextEntry(ZipEntry("files/belege.json"))
                zip.write("[]".toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
    }

    private fun decryptToFile(uri: Uri, password: String, destination: File) {
        activity.contentResolver.openInputStream(uri)?.use { input ->
            val prefix = ByteArray(magic.size)
            input.readFully(prefix)
            require(prefix.contentEquals(magic)) { "Unbekanntes Sicherungsformat" }
            val salt = ByteArray(16)
            val nonce = ByteArray(12)
            input.readFully(salt)
            input.readFully(nonce)
            val decryptor = cipher(password, salt, nonce, Cipher.DECRYPT_MODE)
            CipherInputStream(input, decryptor).use { decrypted ->
                FileOutputStream(destination).use { output -> decrypted.copyTo(output) }
            }
        } ?: error("Sicherungsdatei kann nicht gelesen werden.")
    }

    private fun InputStream.readFully(bytes: ByteArray) {
        var offset = 0
        while (offset < bytes.size) {
            val n = read(bytes, offset, bytes.size - offset)
            require(n > 0) { "Sicherung ist abgeschnitten." }
            offset += n
        }
    }

    private fun countEntries(zip: File): Int {
        var count = 0
        var hasIndex = false
        ZipInputStream(FileInputStream(zip)).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                if (entry.name == "files/belege.json") hasIndex = true
                count++
                require(count <= 100_000) { "Zu viele Dateien in Sicherung." }
                val buffer = ByteArray(65_536)
                while (input.read(buffer) >= 0) { /* verify decompression */ }
                input.closeEntry()
            }
        }
        require(hasIndex) { "Belegliste fehlt." }
        return count
    }

    private fun extractValidated(zip: File, destination: File): Int {
        val prefix = destination.canonicalPath + File.separator
        var total = 0L
        var count = 0
        var indexFound = false
        ZipInputStream(FileInputStream(zip)).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                val name = entry.name
                require(
                    name == "belegbox-info.json" ||
                        name == "files/belege.json" ||
                        (name.startsWith("files/PDF-Eingang/") && name.endsWith(".pdf"))
                ) { "Ungültiger Archivinhalt" }
                val out = File(destination, name)
                require(out.canonicalPath.startsWith(prefix)) { "Ungültiger Archivpfad" }
                require(!entry.isDirectory) { "Ungültiger Archiveintrag" }
                out.parentFile?.mkdirs()
                FileOutputStream(out).use { stream ->
                    val buffer = ByteArray(65_536)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= 2L * 1024 * 1024 * 1024) { "Sicherung ist zu groß." }
                        stream.write(buffer, 0, read)
                    }
                }
                if (name == "files/belege.json") indexFound = true
                input.closeEntry()
                count++
                require(count <= 100_000) { "Zu viele Dateien" }
            }
        }
        require(indexFound) { "Belegliste fehlt" }
        return count
    }
}
