package de.dnh24.belegbox

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val folderRequest = 8621
    private val backupPickerRequest = 8622
    private val savePdfRequest = 8623
    private val documentScannerRequest = 8624
    private val importPdfRequest = 8625
    private var pendingFolderResult: MethodChannel.Result? = null
    private var pendingBackupFileResult: MethodChannel.Result? = null
    private var pendingSavePdfResult: MethodChannel.Result? = null
    private var pendingSavePdfSource: File? = null
    private var pendingScannerResult: MethodChannel.Result? = null
    private var pendingImportedPdfResult: MethodChannel.Result? = null
    private val backupBridge by lazy { BackupBridge(this) }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "de.dnh24.belegbox/files")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "scanDocument" -> openDocumentScanner(result)
                        "importReceiptPdf" -> openPdfPicker(result)
                        "openPdf" -> {
                            val path = call.argument<String>("filePath") ?: error("PDF fehlt")
                            val file = privateFile(path)
                            val uri = FileProvider.getUriForFile(this, "$packageName.pdfprovider", file)
                            openDocument(uri)
                            result.success(null)
                        }
                        "openCloudCopy" -> {
                            openDocument(Uri.parse(call.argument<String>("documentUri")
                                ?: error("Cloud-Kopie fehlt")))
                            result.success(null)
                        }
                        "chooseFolder" -> {
                            if (pendingFolderResult != null) {
                                result.error("busy", "Ordnerauswahl ist bereits geöffnet", null)
                            } else {
                                pendingFolderResult = result
                                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                                    addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
                                }
                                startActivityForResult(picker, folderRequest)
                            }
                        }
                        "copyPdf" -> {
                            val folder = call.argument<String>("folderUri") ?: error("Cloud-Ordner fehlt")
                            val path = call.argument<String>("filePath") ?: error("PDF fehlt")
                            val name = call.argument<String>("fileName") ?: error("Dateiname fehlt")
                            val year = call.argument<String>("year") ?: error("Jahr fehlt")
                            val month = call.argument<String>("month") ?: error("Monat fehlt")
                            result.success(copyPdf(Uri.parse(folder), path, name, year, month))
                        }
                        "exportEncryptedBackup" -> {
                            val folder = call.argument<String>("folderUri") ?: error("Sicherungsordner fehlt")
                            val password = call.argument<String>("password") ?: error("Sicherungskennwort fehlt")
                            val settings = call.argument<String>("settingsJson") ?: error("Einstellungen fehlen")
                            val manifest = call.argument<String>("manifestJson") ?: error("Belegliste fehlt")
                            backupBridge.export(folder, password, settings, manifest, result)
                        }
                        "selectBackupFile" -> {
                            if (pendingBackupFileResult != null) {
                                result.error("busy", "Dateiauswahl bereits geöffnet", null)
                            } else {
                                pendingBackupFileResult = result
                                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    type = "*/*"
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                                }
                                startActivityForResult(picker, backupPickerRequest)
                            }
                        }
                        "readTextManifest" -> {
                            val uri = call.argument<String>("documentUri") ?: error("Belegliste fehlt")
                            backupBridge.readTextManifest(uri, result)
                        }
                        "restoreEncryptedBackup" -> {
                            val uri = call.argument<String>("documentUri") ?: error("Sicherungsdatei fehlt")
                            val password = call.argument<String>("password") ?: error("Kennwort fehlt")
                            backupBridge.restore(uri, password, result)
                        }
                        "exportPdfAs" -> {
                            if (pendingSavePdfResult != null) {
                                result.error("busy", "PDF-Auswahl bereits geöffnet", null)
                            } else {
                                val file = privateFile(call.argument<String>("filePath") ?: error("Datei fehlt"))
                                pendingSavePdfResult = result
                                pendingSavePdfSource = file
                                val picker = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_TITLE, file.name)
                                    addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                                }
                                startActivityForResult(picker, savePdfRequest)
                            }
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("belegbox_files", error.message ?: "Dateifehler", null)
                }
            }
    }

    @Deprecated("Legacy activity result for system document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == documentScannerRequest) {
            val reply = pendingScannerResult ?: return
            pendingScannerResult = null
            if (resultCode != Activity.RESULT_OK || data == null) {
                reply.success(null)
                return
            }
            Thread {
                try {
                    val result = GmsDocumentScanningResult.fromActivityResultIntent(data)
                        ?: error("Der Dokumentenscanner hat keine Seiten zurückgegeben.")
                    val images = result.pages?.map { it.imageUri }
                        ?: error("Keine gescannten Seiten erhalten.")
                    check(images.isNotEmpty()) { "Keine gescannten Seiten erhalten." }
                    val directory = createScanDirectory("belegscan")
                    val paths = images.mapIndexed { index, uri ->
                        val file = File(directory, "Seite_${index + 1}.jpg")
                        contentResolver.openInputStream(uri)?.use { input ->
                            file.outputStream().use { output -> input.copyTo(output) }
                        } ?: error("Gescanntes Bild konnte nicht gelesen werden.")
                        file.absolutePath
                    }
                    runOnUiThread { reply.success(paths) }
                } catch (error: Exception) {
                    runOnUiThread { reply.error("document_scan", error.message, null) }
                }
            }.start()
            return
        }
        if (requestCode == importPdfRequest) {
            val reply = pendingImportedPdfResult ?: return
            pendingImportedPdfResult = null
            val uri = data?.data
            if (resultCode != Activity.RESULT_OK || uri == null) {
                reply.success(null)
                return
            }
            Thread {
                try {
                    val paths = renderPdfPages(uri)
                    runOnUiThread { reply.success(paths) }
                } catch (error: Exception) {
                    runOnUiThread { reply.error("pdf_import", error.message, null) }
                }
            }.start()
            return
        }
        if (requestCode == backupPickerRequest) {
            val reply = pendingBackupFileResult ?: return
            pendingBackupFileResult = null
            val uri = data?.data
            if (resultCode != Activity.RESULT_OK || uri == null) {
                reply.success(null)
                return
            }
            try {
                activityPersistRead(uri, data.flags)
                reply.success(uri.toString())
            } catch (error: Exception) {
                reply.error("backup_picker", error.message, null)
            }
            return
        }
        if (requestCode == savePdfRequest) {
            val reply = pendingSavePdfResult ?: return
            val source = pendingSavePdfSource
            pendingSavePdfResult = null
            pendingSavePdfSource = null
            val uri = data?.data
            if (resultCode != Activity.RESULT_OK || uri == null || source == null) {
                reply.success(false)
                return
            }
            try {
                contentResolver.openOutputStream(uri, "w")?.use { output ->
                    source.inputStream().use { it.copyTo(output) }
                } ?: error("PDF konnte nicht exportiert werden")
                reply.success(true)
            } catch (error: Exception) {
                reply.error("export_pdf", error.message, null)
            }
            return
        }
        if (requestCode != folderRequest) return
        val reply = pendingFolderResult ?: return
        pendingFolderResult = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            reply.success(null)
            return
        }
        try {
            val flags = data.flags and (
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            contentResolver.takePersistableUriPermission(uri, flags)
            reply.success(uri.toString())
        } catch (error: Exception) {
            reply.error("folder_access", error.message ?: "Ordner nicht freigegeben", null)
        }
    }

    private fun openDocumentScanner(reply: MethodChannel.Result) {
        if (pendingScannerResult != null || pendingImportedPdfResult != null) {
            reply.error("busy", "Bereits ein Scan oder PDF-Import geöffnet.", null)
            return
        }
        pendingScannerResult = reply
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(25)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                try {
                    startIntentSenderForResult(sender, documentScannerRequest, null, 0, 0, 0)
                } catch (error: Exception) {
                    pendingScannerResult = null
                    reply.error("document_scan", error.message, null)
                }
            }
            .addOnFailureListener { error ->
                pendingScannerResult = null
                reply.error(
                    "document_scan",
                    "Scanner konnte nicht geöffnet werden. Bitte Google Play-Dienste prüfen: ${error.message}",
                    null
                )
            }
    }

    private fun openPdfPicker(reply: MethodChannel.Result) {
        if (pendingImportedPdfResult != null || pendingScannerResult != null) {
            reply.error("busy", "Bereits ein Scan oder PDF-Import geöffnet.", null)
            return
        }
        pendingImportedPdfResult = reply
        try {
            val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(picker, importPdfRequest)
        } catch (error: Exception) {
            pendingImportedPdfResult = null
            reply.error("pdf_import", error.message, null)
        }
    }

    private fun createScanDirectory(prefix: String): File =
        File(cacheDir, "${prefix}_${UUID.randomUUID()}").apply {
            check(mkdirs()) { "Temporärer Scanordner konnte nicht angelegt werden." }
        }

    /// Convert each PDF page to a readable JPEG for the existing OCR, preview
    /// and multi-page PDF pipeline. The source PDF is never edited.
    private fun renderPdfPages(uri: Uri): List<String> {
        val directory = createScanDirectory("beleg_pdf_import")
        val source = File(directory, "Original.pdf")
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                source.outputStream().use { output ->
                    val buffer = ByteArray(65536)
                    var total = 0L
                    while (true) {
                        val bytes = input.read(buffer)
                        if (bytes < 0) break
                        total += bytes
                        check(total <= 50L * 1024 * 1024) {
                            "PDF ist zu groß (maximal 50 MB)."
                        }
                        output.write(buffer, 0, bytes)
                    }
                }
            } ?: error("PDF-Datei konnte nicht geöffnet werden.")
            val paths = mutableListOf<String>()
            ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { pdf ->
                    check(pdf.pageCount in 1..25) {
                        "PDF hat ${pdf.pageCount} Seiten. Bitte höchstens 25 Seiten auswählen."
                    }
                    for (index in 0 until pdf.pageCount) {
                        pdf.openPage(index).use { page ->
                            val scale = minOf(3.0, 2400.0 / maxOf(page.width, page.height))
                            val width = maxOf(1, (page.width * scale).toInt())
                            val height = maxOf(1, (page.height * scale).toInt())
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            try {
                                Canvas(bitmap).drawColor(Color.WHITE)
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                val image = File(directory, "Seite_${index + 1}.jpg")
                                image.outputStream().use { output ->
                                    check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, output)) {
                                        "PDF-Seite konnte nicht als Bild gespeichert werden."
                                    }
                                }
                                paths.add(image.absolutePath)
                            } finally {
                                bitmap.recycle()
                            }
                        }
                    }
                }
            }
            return paths
        } catch (error: Exception) {
            directory.deleteRecursively()
            throw error
        } finally {
            source.delete()
        }
    }

    private fun activityPersistRead(uri: Uri, flags: Int) {
        val allowed = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (allowed != 0) contentResolver.takePersistableUriPermission(uri, allowed)
    }

    private fun privateFile(path: String): File {
        val file = File(path).canonicalFile
        val appRoot = File(applicationInfo.dataDir).canonicalPath
        require(file.path.startsWith("$appRoot${File.separator}") && file.isFile) {
            "PDF liegt nicht im geschützten Belegbox-Verzeichnis."
        }
        return file
    }

    private fun openDocument(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "PDF öffnen"))
    }

    private fun copyPdf(
        tree: Uri, path: String, fileName: String, year: String, month: String
    ): String {
        val source = privateFile(path)
        require(fileName.endsWith(".pdf") && !fileName.contains('/') && !fileName.contains('\\')) {
            "Ungültiger PDF-Dateiname."
        }
        require(year.matches(Regex("\\d{4}")) && month.matches(Regex("(0[1-9]|1[0-2])"))) {
            "Ungültiger Jahres- oder Monatsordner."
        }
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        var parent = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        for (part in listOf("PDF-Eingang", year, month)) {
            parent = findChild(tree, parent, part, DocumentsContract.Document.MIME_TYPE_DIR)
                ?: DocumentsContract.createDocument(
                    contentResolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, part
                ) ?: error("Ordner $part konnte nicht angelegt werden.")
        }
        val existing = findChild(tree, parent, fileName, "application/pdf")
        val document = existing ?: DocumentsContract.createDocument(
            contentResolver, parent, "application/pdf", fileName
        ) ?: error("Cloud-Datei konnte nicht angelegt werden.")
        if (existing == null) {
            contentResolver.openOutputStream(document, "w")?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: error("Cloud-Anbieter hat kein Schreiben erlaubt.")
        }
        // This confirms the Android provider's copy only. It cannot prove
        // that a remote Google/Microsoft server has completed its sync.
        val remote = contentResolver.openInputStream(document)
            ?: error("Kopie nicht lesbar; lokale PDF bleibt erhalten.")
        val remoteHash = remote.use(::sha256)
        val sourceHash = source.inputStream().use(::sha256)
        check(remoteHash.contentEquals(sourceHash)) {
            "Cloud-Kopie weicht vom Beleg ab; lokale PDF bleibt erhalten."
        }
        return document.toString()
    }

    private fun sha256(input: InputStream): ByteArray {
        val hash = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(65536)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            hash.update(buffer, 0, count)
        }
        return hash.digest()
    }

    private fun findChild(tree: Uri, parent: Uri, name: String, mime: String): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getDocumentId(parent)
        )
        val fields = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        contentResolver.query(children, fields, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                if (cursor.getString(1) == name && cursor.getString(2) == mime) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, cursor.getString(0))
                }
            }
        }
        return null
    }
}
