@echo off
setlocal
cd /d "%~dp0"
title Belegbox - Android-APK bauen
echo.
echo BELEGBOX - Android-Build unter Windows
echo =====================================
echo.
where flutter >nul 2>&1
if errorlevel 1 (
  echo Flutter wurde nicht gefunden. Bitte zuerst Flutter und Android SDK installieren.
  pause
  exit /b 1
)
call flutter create . --platforms=android --org de.dnh24 --no-pub
if errorlevel 1 goto failed
call dart tool\configure_platforms.dart
if errorlevel 1 goto failed
call flutter pub get
if errorlevel 1 goto failed
call flutter test
if errorlevel 1 goto failed
call flutter build apk --release --split-per-abi
if errorlevel 1 goto failed
echo.
echo Samsung: build\app\outputs\flutter-apk\app-arm64-v8a-release.apk
pause
exit /b 0
:failed
echo.
echo Build fehlgeschlagen. Bitte die Fehlermeldung an mich schicken.
pause
exit /b 1
