@echo off
setlocal
cd /d "%~dp0"
title Belegbox - Windows bauen
echo.
echo BELEGBOX - Windows-Build
echo ========================
echo.
where flutter >nul 2>&1
if errorlevel 1 (
  echo Flutter wurde nicht gefunden.
  echo Bitte Flutter installieren und zum PATH hinzufuegen.
  echo https://docs.flutter.dev/get-started/install/windows
  pause
  exit /b 1
)
echo Flutter gefunden. Die Windows-Version wird erstellt.
call flutter create . --platforms=windows --org de.dnh24 --no-pub
if errorlevel 1 goto failed
call flutter pub get
if errorlevel 1 goto failed
call flutter test
if errorlevel 1 goto failed
call flutter build windows --release
if errorlevel 1 goto failed
echo.
echo Die Windows-App wurde erstellt.
echo Den gesamten Ordner build\windows\x64\runner\Release behalten.
echo Bei fehlender Texterkennung Tesseract OCR mit Deutsch installieren.
pause
exit /b 0
:failed
echo.
echo Build fehlgeschlagen. Bitte die Fehlermeldung an mich schicken.
pause
exit /b 1
