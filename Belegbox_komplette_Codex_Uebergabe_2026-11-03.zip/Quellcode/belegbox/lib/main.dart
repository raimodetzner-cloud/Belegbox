import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import 'models/receipt.dart';
import 'models/receipt_analysis.dart';
import 'services/backup_service.dart';
import 'services/chatgpt_auth_service.dart';
import 'services/chatgpt_receipt_service.dart';
import 'services/cloud_folder_service.dart';
import 'services/document_capture_service.dart';
import 'services/local_archive.dart';
import 'services/pdf_service.dart';
import 'services/receipt_parser.dart';
import 'services/scan_service.dart';
import 'services/synology_service.dart';
import 'widgets/info_page.dart';
import 'widgets/image_crop_page.dart';
import 'widgets/local_folder_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BelegboxApp());
}

class BelegboxApp extends StatelessWidget {
  const BelegboxApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Belegbox',
    debugShowCheckedModeBanner: false,
    locale: const Locale('de', 'DE'),
    supportedLocales: const [Locale('de', 'DE')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176957)),
      scaffoldBackgroundColor: const Color(0xFFF6F8F7),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
      ),
    ),
    home: const BelegboxHome(),
  );
}

class BelegboxHome extends StatefulWidget {
  const BelegboxHome({super.key});

  @override
  State<BelegboxHome> createState() => _BelegboxHomeState();
}

class _BelegboxHomeState extends State<BelegboxHome> {
  final _picker = ImagePicker();
  final _documentCapture = const DocumentCaptureService();
  final _scanner = ScanService();
  final _pdf = PdfService();
  final _archive = LocalArchive();
  final _settingsStore = SettingsStore();
  final _qnapSettingsStore = QnapSettingsStore();
  final _nas = SynologyService();
  final _cloudFiles = CloudFolderService();
  final _cloudStore = const CloudSelectionStore();
  final _backup = const BackupService();
  final _chatAuth = ChatGptAuthService();
  late final _chatReader = ChatGptReceiptService(auth: _chatAuth);

  final _vendor = TextEditingController();
  final _date = TextEditingController();
  final _total = TextEditingController();
  final _invoiceNumber = TextEditingController();
  final _vat = TextEditingController();
  final _net = TextEditingController();
  final _nasUrl = TextEditingController();
  final _folder = TextEditingController(text: 'PDF-Eingang');
  final _nasUser = TextEditingController();
  final _nasPassword = TextEditingController();

  List<XFile> _photos = [];
  List<SavedReceipt> _receipts = [];
  SynologySettings? _config;
  SynologySettings? _qnapConfig;
  CloudSelection _cloudSelection = const CloudSelection();
  ChatGptCredentials? _chatAccount;
  ReceiptAnalysis? _analysis;
  PaymentMethod _paymentMethod = PaymentMethod.unknown;
  List<ChatGptModel> _availableModels = [];
  String? _chosenModel;
  String? _chatConnectionStatus;
  bool _allowSendingToChatGpt = false;
  bool _backupConfigured = false;
  String? _lastBackupName;
  bool _busy = false;
  int _tab = 0;
  String? _scanStatus;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      final settings = await _settingsStore.load();
      final qnapSettings = await _qnapSettingsStore.load();
      final receipts = await _archive.list();
      final cloudSelection = await _cloudStore.load();
      final account = await _chatAuth.load();
      final backupEnabled = await _backup.isConfigured;
      // Android kann beim Öffnen der Kamera die App im Hintergrund beenden.
      final LostDataResponse? lost = Platform.isAndroid
          ? await _picker.retrieveLostData()
          : null;
      if (!mounted) return;
      setState(() {
        _config = settings;
        _qnapConfig = qnapSettings;
        _cloudSelection = cloudSelection;
        _receipts = receipts;
        _chatAccount = account;
        _backupConfigured = backupEnabled;
        _fillNasFields(
          cloudSelection.target == 'qnap' ? qnapSettings : settings,
        );
        if (lost?.files != null && lost!.files!.isNotEmpty) {
          _photos = [...lost.files!];
        }
      });
      if (lost?.exception != null)
        _message('Kamera konnte den vorherigen Scan nicht wiederherstellen.');
      if (account?.planEnabled == true) {
        try {
          await _loadModels();
          if (mounted) {
            setState(
              () => _chatConnectionStatus =
                  'Dein ChatGPT-Konto wurde automatisch wieder verbunden.',
            );
          }
        } catch (error) {
          if (mounted) {
            setState(
              () => _chatConnectionStatus =
                  'Konto gespeichert. Modelle konnten noch nicht geladen werden: ${_errorMessage(error, chatGpt: true)}',
            );
          }
        }
      }
    } catch (error) {
      if (mounted) _message('Daten konnten nicht geladen werden: $error');
    }
  }

  @override
  void dispose() {
    for (final controller in [
      _vendor,
      _date,
      _total,
      _invoiceNumber,
      _vat,
      _net,
      _nasUrl,
      _folder,
      _nasUser,
      _nasPassword,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 5)),
    );
  }

  static bool _isNasTarget(String target) =>
      target == 'synology' || target == 'qnap';

  static String _nasName(String target) =>
      target == 'qnap' ? 'QNAP' : 'Synology';

  SynologySettings? _configFor(String target) =>
      target == 'qnap' ? _qnapConfig : _config;

  void _fillNasFields(SynologySettings settings) {
    _nasUrl.text = settings.url;
    _folder.text = settings.sharedFolder;
    _nasUser.text = settings.user;
    _nasPassword.text = settings.password;
  }

  Future<void> _work(
    Future<void> Function() operation, {
    bool chatGpt = false,
  }) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await operation();
    } catch (error) {
      _message(_errorMessage(error, chatGpt: chatGpt));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _errorMessage(Object error, {bool chatGpt = false}) {
    final value = error.toString().replaceFirst(
      RegExp(r'^(Bad state: |FormatException: )'),
      '',
    );
    if (value.contains('HandshakeException') ||
        value.contains('CERTIFICATE_VERIFY_FAILED')) {
      if (chatGpt) {
        return 'ChatGPT: HTTPS-Verbindung konnte nicht sicher aufgebaut werden. '
            'Prüfe Datum/Uhrzeit und ob VPN, Firewall oder DNS die Verbindung '
            'zu auth.openai.com blockiert. Technischer Fehler: ${_shortDiagnostic(value)}';
      }
      return 'HTTPS-Zertifikat der NAS-Adresse ist nicht vertrauenswürdig. '
          'Bitte einen gültigen Hostnamen mit passendem Zertifikat verwenden.';
    }
    if (value.contains('SocketException')) {
      if (chatGpt) {
        return 'ChatGPT-Netzwerkfehler (die Synology ist daran nicht beteiligt). '
            'Bitte Internetzugriff, VPN/Firewall und DNS für Belegbox prüfen. '
            'Technischer Fehler: ${_shortDiagnostic(value)}';
      }
      return 'NAS per WebDAV nicht erreichbar. Prüfe die HTTPS-Adresse, '
          'den WebDAV-Port und die Freigabe. Ohne VPN muss die NAS unter '
          'dieser Adresse direkt über WLAN oder Internet erreichbar sein.';
    }
    if (value.contains('TimeoutException')) {
      if (chatGpt) {
        return 'Zeitüberschreitung bei der ChatGPT-Anmeldung oder -Verbindung. '
            'Bitte Internet und den Browserrücksprung prüfen.';
      }
      return 'Verbindung hat zu lange gedauert. PDF bleibt lokal erhalten.';
    }
    return value;
  }

  String _shortDiagnostic(String original) {
    final clean = original.replaceAll(RegExp(r'[\r\n]+'), ' ').trim();
    return clean.length <= 260 ? clean : '${clean.substring(0, 260)}…';
  }

  Future<void> _takePhoto() async {
    if (_busy) return;
    try {
      final photo = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 90,
        maxWidth: 2600,
        maxHeight: 2600,
      );
      if (photo != null && mounted)
        setState(() => _photos = [..._photos, photo]);
    } catch (error) {
      _message('Kamera konnte nicht geöffnet werden: ${_errorMessage(error)}');
    }
  }

  Future<void> _scanDocument() => _work(() async {
    final pages = await _documentCapture.scanDocument();
    if (pages.isEmpty || !mounted) return;
    setState(() {
      _photos = [..._photos, ...pages];
      _analysis = null;
      _scanStatus =
          '${pages.length} zugeschnittene Seite(n) übernommen. '
          'Prüfe die Vorschau und starte anschließend die Belegerkennung.';
    });
    await _recognizeCurrentPhotos();
  });

  Future<void> _importPdf() => _work(() async {
    final pages = await _documentCapture.importPdf();
    if (pages.isEmpty || !mounted) return;
    setState(() {
      _photos = [..._photos, ...pages];
      _analysis = null;
      _scanStatus =
          '${pages.length} PDF-Seite(n) importiert. '
          'Du kannst jede Seite zuschneiden oder unerwünschte Seiten entfernen. '
          'Danach die Belegerkennung starten.';
    });
    await _recognizeCurrentPhotos();
  });

  Future<void> _cropPhoto(int index) async {
    if (_busy || index < 0 || index >= _photos.length) return;
    final original = _photos[index];
    final edited = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) => ImageCropPage(path: original.path),
      ),
    );
    if (edited == null || !mounted) return;
    setState(() {
      _photos = [..._photos]..[index] = XFile(edited);
      _analysis = null;
      _scanStatus =
          'Seite ${index + 1} zugeschnitten. '
          'Bitte die Erkennung für die geänderte Seite erneut starten.';
    });
  }

  Future<void> _choosePhotos() async {
    if (_busy) return;
    try {
      final selected = await _picker.pickMultiImage(
        imageQuality: 90,
        maxWidth: 2600,
        maxHeight: 2600,
      );
      if (selected.isNotEmpty && mounted)
        setState(() => _photos = [..._photos, ...selected]);
    } catch (error) {
      _message('Bilder konnten nicht geöffnet werden: ${_errorMessage(error)}');
    }
  }

  void _removePhoto(int index) {
    setState(() => _photos = [..._photos]..removeAt(index));
  }

  Future<void> _recognize() => _work(_recognizeCurrentPhotos);

  Future<void> _recognizeCurrentPhotos() async {
    if (_photos.isEmpty)
      throw StateError('Bitte erst mindestens ein Foto hinzufügen.');
    if (mounted) setState(() => _scanStatus = null);
    String text;
    try {
      text = await _scanner.recognize(_photos);
    } catch (_) {
      // Keep the selected images and editable fields even if the native
      // recognition service fails. Never expose a full Android stack trace.
      if (mounted) {
        setState(
          () => _scanStatus =
              'Die automatische Texterkennung konnte nicht gestartet werden. '
              'Die Fotos sind weiterhin gespeichert. Bitte Firma, Datum '
              'und Betrag unten eintragen; du kannst das PDF trotzdem sichern.',
        );
      }
      return;
    }
    final draft = ReceiptParser.parse(text);
    if (!mounted) return;
    setState(() {
      _analysis = null;
      _paymentMethod = draft.paymentMethod;
      _scanStatus = text.trim().isEmpty
          ? 'Auf dem Foto wurde kein Text gefunden. Du kannst die Felder manuell ausfüllen.'
          : 'Belegdaten vorläufig erkannt. Bitte Firma, Datum und Betrag prüfen '
                'oder für die vollständige Auswertung ChatGPT verwenden.';
      _vendor.text = draft.vendor;
      _date.text = draft.date == null
          ? ''
          : DateFormat('dd.MM.yyyy').format(draft.date!);
      _total.text = draft.totalCents == null
          ? ''
          : _formatEuro(draft.totalCents!);
      _invoiceNumber.clear();
      _vat.clear();
      _net.clear();
    });
  }

  Future<void> _connectChatGpt() => _work(() async {
    try {
      if (mounted) {
        setState(
          () => _chatConnectionStatus =
              'Die ChatGPT-Anmeldung startet. Bitte im Browser bestätigen.',
        );
      }
      final connected = await _chatAuth.connect(
        onProgress: (message) {
          if (mounted) setState(() => _chatConnectionStatus = message);
        },
      );
      if (!mounted) return;
      setState(() {
        _chatAccount = connected;
        _availableModels = [];
        _chosenModel = null;
      });
      await _refreshBackupIfConfigured();
      try {
        await _loadModels();
        if (mounted) {
          setState(
            () => _chatConnectionStatus =
                'ChatGPT ist verbunden. Die verfügbaren Modelle wurden geladen.',
          );
        }
        _message('ChatGPT ist mit der Belegbox verbunden.');
      } catch (error) {
        if (mounted) {
          setState(
            () => _chatConnectionStatus =
                'ChatGPT ist angemeldet. Die Modellliste konnte noch nicht geladen werden: ${_errorMessage(error, chatGpt: true)}',
          );
        }
      }
    } catch (error) {
      if (mounted) {
        final stage = _chatConnectionStatus ?? 'Unbekannter Anmeldeschritt';
        setState(
          () => _chatConnectionStatus =
              '$stage\n\nChatGPT-Anmeldung nicht abgeschlossen: '
              '${_errorMessage(error, chatGpt: true)}',
        );
      }
      rethrow;
    }
  }, chatGpt: true);

  Future<void> _loadModels() async {
    final models = await _chatReader.availableModels();
    if (!mounted) return;
    setState(() {
      _availableModels = models;
      final preferred = models.where((m) => m.slug == 'gpt-6.1-sol');
      _chosenModel = preferred.isNotEmpty
          ? preferred.first.slug
          : (models.isNotEmpty ? models.first.slug : null);
    });
  }

  Future<void> _refreshModels() => _work(() async {
    await _loadModels();
    if (_availableModels.isEmpty) {
      _message('Für dein ChatGPT-Konto sind keine Modelle freigegeben.');
    }
  }, chatGpt: true);

  Future<void> _testChatGptNetwork() => _work(() async {
    if (mounted) {
      setState(
        () => _chatConnectionStatus =
            'Prüfe die Internetverbindung der Belegbox zu OpenAI ...',
      );
    }
    final result = await _chatAuth.checkReachability();
    if (mounted) {
      setState(
        () => _chatConnectionStatus =
            'Verbindungstest aus der Belegbox:\n$result\n\n'
            'Dieser Test verwendet weder dein Passwort noch die Synology.',
      );
    }
  }, chatGpt: true);

  Future<void> _disconnectChatGpt() => _work(() async {
    await _chatAuth.disconnect();
    await _refreshBackupIfConfigured();
    if (!mounted) return;
    setState(() {
      _chatAccount = null;
      _availableModels = [];
      _chosenModel = null;
      _chatConnectionStatus = 'ChatGPT-Verbindung entfernt.';
      _allowSendingToChatGpt = false;
    });
    _message('ChatGPT ist in der Belegbox abgemeldet.');
  }, chatGpt: true);

  Future<void> _setAiConsent(bool allow) => _work(() async {
    if (allow) {
      final granted = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('ChatGPT-Bilder dauerhaft freigeben?'),
          content: const Text(
            'Wenn du zustimmst, darf die Belegbox zukünftig auf deinen Wunsch '
            'jede gescannte Rechnung ohne weitere einzelne Rückfrage zur '
            'Auswertung an OpenAI übertragen. Das gilt, bis du die Zustimmung '
            'in den Einstellungen widerrufst. Du kannst vor jeder Auswertung '
            'noch weitere Seiten hinzufügen.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Abbrechen'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Dauerhaft erlauben'),
            ),
          ],
        ),
      );
      if (granted != true) return;
    }
    final next = _cloudSelection.copyWith(rememberAiConsent: allow);
    await _cloudStore.save(next);
    if (mounted) {
      setState(() {
        _cloudSelection = next;
        if (!allow) _allowSendingToChatGpt = false;
      });
    }
  });

  Future<void> _recognizeWithChatGpt() => _work(() async {
    if (_photos.isEmpty)
      throw StateError('Bitte erst einen Beleg fotografieren.');
    if (_chatAccount?.planEnabled != true) {
      if (mounted) setState(() => _tab = 3);
      throw StateError('Bitte zuerst im Bereich ChatGPT dein Konto verbinden.');
    }
    if (!_allowSendingToChatGpt && !_cloudSelection.rememberAiConsent) {
      throw StateError(
        'Bitte zuerst der Bildübertragung an ChatGPT zustimmen.',
      );
    }
    if (_chosenModel == null) {
      throw StateError(
        'Bitte im ChatGPT-Bereich ein Modell laden und auswählen.',
      );
    }
    final details = await _chatReader.analyze(
      photos: _photos,
      model: _chosenModel!,
    );
    if (!mounted) return;
    setState(() {
      _analysis = details;
      _vendor.text = details.vendor;
      _date.text = details.invoiceDate == null
          ? ''
          : DateFormat('dd.MM.yyyy').format(details.invoiceDate!);
      _total.text = details.grossCents == null
          ? ''
          : _formatEuro(details.grossCents!);
      _invoiceNumber.text = details.invoiceNumber ?? '';
      _vat.text = details.vatCents == null
          ? ''
          : _formatEuro(details.vatCents!);
      _net.text = details.netCents == null
          ? ''
          : _formatEuro(details.netCents!);
      _paymentMethod = details.paymentMethod;
      _scanStatus =
          'Die ChatGPT-Auswertung ist fertig. Bitte Datum, Betrag, '
          'Zahlungsart und die erkannten Artikel anhand des Belegs prüfen.';
    });
  }, chatGpt: true);

  String _formatEuro(int cents) =>
      '${cents ~/ 100},${(cents % 100).toString().padLeft(2, '0')}';

  Future<void> _saveReceipt() => _work(() async {
    if (_photos.isEmpty)
      throw StateError('Bitte erst mindestens ein Foto hinzufügen.');
    final vendor = _vendor.text.trim();
    final date = ReceiptParser.parseDate(_date.text);
    final cents = ReceiptParser.parseEuro(_total.text);
    if (vendor.isEmpty) throw StateError('Bitte die Firma eintragen.');
    if (date == null)
      throw StateError(
        'Bitte ein gültiges Rechnungsdatum eingeben, z. B. 27.10.2026.',
      );
    if (cents == null)
      throw StateError('Bitte den Endbetrag eingeben, z. B. 159,90.');
    final checked = ReceiptAnalysis(
      vendor: vendor,
      invoiceDate: date,
      grossCents: cents,
      paymentMethod: _paymentMethod,
      invoiceNumber: _invoiceNumber.text.trim().isEmpty
          ? null
          : _invoiceNumber.text.trim(),
      vatCents: ReceiptParser.parseEuro(_vat.text),
      netCents: ReceiptParser.parseEuro(_net.text),
      lineItems: _analysis?.lineItems ?? [],
      note: _analysis?.note,
    );
    final bytes = await _pdf.create(
      photos: _photos,
      vendor: vendor,
      analysis: checked,
    );
    final receipt = await _archive.savePdf(
      pdfBytes: bytes,
      vendor: vendor,
      date: date,
      totalCents: cents,
      analysis: checked,
      storageTarget: _cloudSelection.target,
    );
    if (!mounted) return;
    setState(() {
      _receipts = [receipt, ..._receipts];
      _photos = [];
      _vendor.clear();
      _date.clear();
      _total.clear();
      _invoiceNumber.clear();
      _vat.clear();
      _net.clear();
      _paymentMethod = PaymentMethod.unknown;
      _analysis = null;
      _allowSendingToChatGpt = false;
      _scanStatus = null;
    });
    if (_backupConfigured) {
      try {
        // Back up while the original local PDF still exists, before a NAS
        // verification could legitimately remove that local copy.
        final backup = await _backup.save();
        if (mounted) setState(() => _lastBackupName = backup);
      } catch (error) {
        _message(
          'PDF lokal gespeichert. Die automatische Sicherung ist fehlgeschlagen: '
          '${_errorMessage(error)}. Der Cloud-Upload wurde zur Sicherheit pausiert.',
        );
        return;
      }
    }
    try {
      await _uploadReceiptToDestination(receipt);
      await _refreshReceipts();
      await _refreshBackupIfConfigured();
      _message(
        _isNasTarget(receipt.storageTarget)
            ? '${_nasName(receipt.storageTarget)}-PDF erneut gelesen und geprüft. '
                  '${_cloudSelection.deleteAfterNasVerification ? 'Lokale Datei entfernt.' : 'Lokale Datei behalten.'}'
            : 'Im gewählten Android-Cloud-Ordner abgelegt. '
                  'Lokale PDF bleibt bis zur bestätigten Server-Sicherung erhalten.',
      );
    } catch (error) {
      _message(
        'PDF lokal unter ${DateFormat('yyyy/MM').format(date)} gesichert. '
        'Ablage später erneut versuchen: ${_errorMessage(error)}',
      );
    }
  });

  Future<void> _refreshReceipts() async {
    final updated = await _archive.list();
    if (mounted) setState(() => _receipts = updated);
  }

  Future<void> _uploadPending() => _work(() async {
    final pending = _receipts.where(_isPendingUpload).toList();
    var uploaded = 0;
    var failed = 0;
    for (final receipt in pending) {
      try {
        await _uploadReceiptToDestination(receipt);
        uploaded++;
      } catch (_) {
        failed++;
      }
    }
    await _refreshReceipts();
    if (uploaded > 0) await _refreshBackupIfConfigured();
    _message('$uploaded PDF(s) abgelegt, $failed noch offen.');
  });

  bool _isPendingUpload(SavedReceipt receipt) =>
      _isNasTarget(receipt.storageTarget)
      ? !receipt.uploaded
      : receipt.cloudDocumentUri == null;

  Future<void> _uploadReceiptToDestination(SavedReceipt receipt) async {
    if (_isNasTarget(receipt.storageTarget)) {
      final config = _configFor(receipt.storageTarget);
      if (config?.isComplete != true) {
        throw StateError(
          '${_nasName(receipt.storageTarget)} noch nicht verbunden. PDF bleibt lokal erhalten.',
        );
      }
      await _nas.uploadAndVerify(config!, receipt);
      await _archive.markUploaded(
        receipt.id,
        remoteUri: config.documentUri(
          receipt.fileName, date: receipt.invoiceDate,
        ).toString(),
        deleteLocalAfterVerification:
            _cloudSelection.deleteAfterNasVerification,
      );
      return;
    }
    final folderUri = _cloudSelection.folderFor(receipt.storageTarget);
    if (folderUri == null || folderUri.isEmpty) {
      throw StateError(
        'Bitte erst im Bereich Ablage den passenden '
        'Google-Drive- oder OneDrive-Ordner auswählen.',
      );
    }
    final resultUri = await _cloudFiles.copyPdf(folderUri, receipt);
    await _archive.markCloudCopied(receipt.id, resultUri);
    // Android's provider may still be uploading to the actual cloud server.
    // Never delete this local source in response to a provider copy alone.
  }

  Future<void> _openReceipt(SavedReceipt receipt) => _work(() async {
    if (await File(receipt.localPath).exists()) {
      await _cloudFiles.openPdf(receipt.localPath);
      return;
    }
    if (_isNasTarget(receipt.storageTarget) && receipt.uploaded) {
      final config = _configFor(receipt.storageTarget);
      if (config?.isComplete != true) {
        throw StateError(
          'Die lokale Datei wurde geprüft entfernt. '
          'Bitte zuerst dein ${_nasName(receipt.storageTarget)} verbinden, um sie zu öffnen.',
        );
      }
      final preview = await _nas.downloadToCache(config!, receipt);
      await _cloudFiles.openPdf(preview.path);
      return;
    }
    if (receipt.cloudDocumentUri != null) {
      await _cloudFiles.openCloudCopy(receipt.cloudDocumentUri!);
      return;
    }
    throw StateError('Diese PDF ist derzeit nicht erreichbar.');
  });

  Future<void> _cleanupVerifiedCopies() => _work(() async {
    final target = _cloudSelection.target;
    final config = _configFor(target);
    if (!_isNasTarget(target) || config?.isComplete != true) {
      throw StateError('Bitte zuerst das ausgewählte NAS verbinden.');
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Lokale PDF-Kopien entfernen?'),
        content: const Text(
          'Die Belegbox prüft jede ausgewählte NAS-Datei noch einmal '
          'durch Herunterladen und vollständigen Vergleich. Nur identische '
          'Kopien werden danach vom Handy gelöscht. Die PDFs auf der '
          'NAS bleiben unverändert. Möchtest du fortfahren?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Abbrechen'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Prüfen und lokal entfernen'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    var removed = 0;
    var retained = 0;
    for (final receipt in _receipts.where(
      (r) => r.storageTarget == target && r.uploaded,
    )) {
      if (!await File(receipt.localPath).exists()) continue;
      try {
        await _nas.verifyRemoteCopy(config!, receipt);
        await _archive.markUploaded(
          receipt.id,
          deleteLocalAfterVerification: true,
        );
        removed++;
      } catch (_) {
        retained++;
      }
    }
    await _refreshReceipts();
    _message(
      '$removed geprüfte lokale Kopien entfernt, '
      '$retained aus Sicherheitsgründen behalten.',
    );
  });

  /// One delete action: local-only PDFs are removed locally, NAS-backed
  /// PDFs first on the recorded NAS and then locally. Remote failure means
  /// nothing is removed from the receipt list or local storage.
  Future<void> _deleteReceipt(SavedReceipt receipt) => _work(() async {
    final nasCopy = _isNasTarget(receipt.storageTarget) && receipt.uploaded;
    if (!_isNasTarget(receipt.storageTarget) &&
        receipt.cloudDocumentUri != null) {
      throw StateError(
        'Dieser Beleg liegt bei Google Drive oder OneDrive. '
        'Bitte die Cloud-Kopie zuerst dort löschen; danach kann der '
        'lokale Eintrag entfernt werden. Ein Löschen beim Anbieter '
        'wird von dieser Testversion noch nicht bestätigt.',
      );
    }
    final where = nasCopy
        ? '${_nasName(receipt.storageTarget)}-NAS und, falls vorhanden, auf dem Handy'
        : 'nur auf dem Handy';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Beleg wirklich löschen?'),
        content: Text(
          '${receipt.fileName}\n\n'
          'Speicherort: $where\n\n'
          'Die Datei wird dauerhaft gelöscht und aus der Belegliste entfernt. '
          'Frühere Sicherungsdateien können noch alte Kopien enthalten. '
          'Dieser Vorgang kann nicht rückgängig gemacht werden.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Abbrechen'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(nasCopy ? 'Auf NAS und lokal löschen' : 'Lokal löschen'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    if (nasCopy) {
      final config = _configFor(receipt.storageTarget);
      if (config?.isComplete != true) {
        throw StateError('Bitte zuerst ${_nasName(receipt.storageTarget)} '
            'verbinden. Beleg wurde nicht gelöscht.');
      }
      await _nas.deleteRemoteCopy(config!, receipt);
      // If subsequent local removal fails, avoid advertising a NAS copy
      // that no longer exists. The local PDF remains available for retry.
      await _archive.markRemoteDeleted(receipt.id);
    }
    await _archive.deleteReceipt(receipt.id);
    await _refreshReceipts();
    await _refreshBackupIfConfigured();
    _message('Beleg gelöscht: ${receipt.fileName}');
  });

  Future<String?> _askBackupPassword({required bool setup}) async {
    final first = TextEditingController();
    final repeated = TextEditingController();
    String? warning;
    try {
      return await showDialog<String>(
        context: context,
        builder: (outerContext) => StatefulBuilder(
          builder: (dialogContext, update) => AlertDialog(
            title: Text(
              setup ? 'Sicherungskennwort festlegen' : 'Sicherung öffnen',
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    setup
                        ? 'Das Kennwort schützt deine PDFs und Zugangsdaten. '
                              'Du brauchst es nach einer Neuinstallation wieder. '
                              'Bitte gut und getrennt vom Handy aufbewahren.'
                        : 'Bitte das Kennwort eingeben, mit dem die Sicherung '
                              'erstellt wurde.',
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: first,
                    autofocus: true,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Kennwort'),
                  ),
                  if (setup) ...[
                    const SizedBox(height: 10),
                    TextField(
                      controller: repeated,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Kennwort wiederholen',
                      ),
                    ),
                  ],
                  if (warning != null) ...[
                    const SizedBox(height: 10),
                    Text(warning!, style: const TextStyle(color: Colors.red)),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Abbrechen'),
              ),
              FilledButton(
                onPressed: () {
                  if (first.text.length < 12 && setup) {
                    update(() => warning = 'Mindestens 12 Zeichen verwenden.');
                    return;
                  }
                  if (first.text.isEmpty) {
                    update(() => warning = 'Bitte Kennwort eingeben.');
                    return;
                  }
                  if (setup && first.text != repeated.text) {
                    update(
                      () => warning = 'Die Kennwörter stimmen nicht überein.',
                    );
                    return;
                  }
                  Navigator.pop(dialogContext, first.text);
                },
                child: Text(
                  setup ? 'Sicherung einrichten' : 'Wiederherstellen',
                ),
              ),
            ],
          ),
        ),
      );
    } finally {
      // The modal has already closed; its text fields are disposed first.
      first.dispose();
      repeated.dispose();
    }
  }

  Future<void> _configureBackup() => _work(() async {
    final folder = await _backup.chooseFolder();
    if (folder == null || !mounted) return;
    final password = await _askBackupPassword(setup: true);
    if (password == null || !mounted) return;
    await _backup.configure(folder, password);
    if (mounted) setState(() => _backupConfigured = true);
    final name = await _backup.save();
    if (mounted) setState(() => _lastBackupName = name);
    _message('Verschlüsselte Sicherung geprüft: $name');
  });

  Future<void> _saveBackupManually() => _work(() async {
    final name = await _backup.save();
    if (mounted) setState(() => _lastBackupName = name);
    _message('Sicherung geschrieben und erneut geprüft: $name');
  });

  Future<void> _restoreBackup() => _work(() async {
    final uri = await _backup.selectBackupFile();
    if (uri == null || !mounted) return;
    final password = await _askBackupPassword(setup: false);
    if (password == null || !mounted) return;
    final summary = await _backup.restore(
      backupUri: uri,
      password: password,
      archive: _archive,
    );
    await _initialize();
    if (!mounted) return;
    _message(
      '${summary.imported} Beleg(e) übernommen. '
      '${summary.alreadyPresentOrSkipped} bereits vorhanden oder nicht verfügbar. '
      '${summary.synologyOnly} Cloud-Belege ohne lokale Kopie.',
    );
  });

  Future<void> _restoreTextList() => _work(() async {
    final uri = await _backup.selectBackupFile();
    if (uri == null) return;
    final summary = await _backup.restoreManifest(
      documentUri: uri,
      archive: _archive,
    );
    await _refreshReceipts();
    _message(
      '${summary.imported} NAS-Verknüpfungen übernommen, '
      '${summary.alreadyPresentOrSkipped} übersprungen. '
      'Für nur lokale PDFs die verschlüsselte .bbx-Sicherung wiederherstellen.',
    );
  });

  Future<void> _openLocalPdfDirectory() async {
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => LocalFolderPage(archive: _archive, files: _cloudFiles),
      ),
    );
  }

  Future<void> _refreshBackupIfConfigured() async {
    if (!_backupConfigured) return;
    try {
      final name = await _backup.save();
      if (mounted) setState(() => _lastBackupName = name);
    } catch (error) {
      _message(
        'Einstellungen gespeichert, aber Sicherung fehlgeschlagen: '
        '${_errorMessage(error)}',
      );
    }
  }

  Future<void> _setCloudTarget(String? target) => _work(() async {
    if (target == null) return;
    if (!const [
      'synology',
      'qnap',
      'google_drive',
      'onedrive',
    ].contains(target)) {
      throw StateError('Unbekanntes Speicherziel.');
    }
    final next = _cloudSelection.copyWith(target: target);
    await _cloudStore.save(next);
    if (mounted) {
      setState(() {
        _cloudSelection = next;
        if (_isNasTarget(target)) _fillNasFields(_configFor(target)!);
      });
    }
    await _refreshBackupIfConfigured();
  });

  Future<void> _setDeleteAfterVerify(bool enabled) => _work(() async {
    final next = _cloudSelection.copyWith(deleteAfterNasVerification: enabled);
    await _cloudStore.save(next);
    if (mounted) setState(() => _cloudSelection = next);
    await _refreshBackupIfConfigured();
  });

  Future<void> _chooseCloudFolder() => _work(() async {
    final target = _cloudSelection.target;
    if (_isNasTarget(target)) {
      throw StateError('Bitte zuerst Google Drive oder OneDrive auswählen.');
    }
    final chosen = await _cloudFiles.chooseFolder();
    if (chosen == null) return;
    final next = target == 'google_drive'
        ? _cloudSelection.copyWith(googleFolder: chosen)
        : _cloudSelection.copyWith(oneDriveFolder: chosen);
    await _cloudStore.save(next);
    if (mounted) setState(() => _cloudSelection = next);
    await _refreshBackupIfConfigured();
    _message(
      'Cloud-Ordner freigegeben. PDF-Eingang/Jahr/Monat '
      'wird bei der ersten Ablage erstellt.',
    );
  });

  SynologySettings _enteredSettings() => SynologySettings(
    url: _nasUrl.text.trim(),
    sharedFolder: _folder.text.trim(),
    user: _nasUser.text.trim(),
    password: _nasPassword.text,
    providerName: _nasName(_cloudSelection.target),
  );

  Future<void> _saveSettings() => _work(() async {
    final settings = _enteredSettings();
    if (!settings.isComplete)
      throw StateError('Bitte alle vier Verbindungsfelder ausfüllen.');
    final isQnap = _cloudSelection.target == 'qnap';
    if (isQnap) {
      await _qnapSettingsStore.save(settings);
    } else {
      await _settingsStore.save(settings);
    }
    if (!mounted) return;
    setState(() {
      if (isQnap) {
        _qnapConfig = settings;
      } else {
        _config = settings;
      }
    });
    await _refreshBackupIfConfigured();
    _message('${settings.providerName}-Einstellungen gespeichert.');
  });

  Future<void> _testConnection() => _work(() async {
    final settings = _enteredSettings();
    if (!settings.isComplete)
      throw StateError('Bitte zuerst alle Verbindungsfelder ausfüllen.');
    await _nas.testConnection(settings);
    _message(
      'WebDAV direkt erreichbar: ${settings.cleanFolder}. '
      'Alle vorhandenen Unterordner wurden gefunden. '
      'Jahr/Monat werden beim Hochladen angelegt.',
    );
  });

  @override
  Widget build(BuildContext context) {
    final pending = _receipts.where(_isPendingUpload).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Belegbox'),
        backgroundColor: const Color(0xFFF6F8F7),
        actions: [
          IconButton(
            tooltip: 'Info & Rechtliches',
            icon: const Icon(Icons.info_outline),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const BelegboxInfoPage()),
            ),
          ),
          if (_busy)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: Center(
                child: SizedBox(
                  width: 21,
                  height: 21,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _tab,
          children: [
            _scannerPage(),
            _archivePage(pending),
            _settingsPage(),
            _chatGptPage(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.document_scanner_outlined),
            selectedIcon: Icon(Icons.document_scanner),
            label: 'Scannen',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: pending > 0,
              label: Text('$pending'),
              child: const Icon(Icons.folder_outlined),
            ),
            label: 'Belege',
          ),
          const NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            label: 'Ablage',
          ),
          NavigationDestination(
            icon: Icon(
              _chatAccount?.planEnabled == true
                  ? Icons.smart_toy
                  : Icons.smart_toy_outlined,
            ),
            label: 'ChatGPT',
          ),
        ],
      ),
    );
  }

  Widget _scannerPage() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Text(
        'Beleg einscannen',
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      const SizedBox(height: 8),
      const Text(
        'Den Beleg in den Kamerarahmen halten: Die Ränder werden erkannt, '
        'der Beleg wird automatisch oder auf Knopfdruck erfasst und '
        'zugeschnitten. Weitere Seiten kannst du direkt hinzufügen.',
      ),
      const SizedBox(height: 18),
      if (Platform.isAndroid) ...[
        FilledButton.icon(
          onPressed: _busy ? null : _scanDocument,
          icon: const Icon(Icons.document_scanner_outlined),
          label: const Text('Beleg automatisch erkennen und zuschneiden'),
        ),
        const SizedBox(height: 8),
      ],
      if (!Platform.isWindows) ...[
        OutlinedButton.icon(
          onPressed: _busy ? null : _takePhoto,
          icon: const Icon(Icons.photo_camera),
          label: const Text('Foto manuell aufnehmen'),
        ),
        const SizedBox(height: 8),
      ],
      if (Platform.isAndroid) ...[
        OutlinedButton.icon(
          onPressed: _busy ? null : _importPdf,
          icon: const Icon(Icons.picture_as_pdf_outlined),
          label: const Text('PDF-Beleg importieren'),
        ),
        const SizedBox(height: 8),
      ],
      OutlinedButton.icon(
        onPressed: _busy ? null : _choosePhotos,
        icon: const Icon(Icons.photo_library_outlined),
        label: const Text('Aus Galerie auswählen'),
      ),
      if (Platform.isWindows) ...[
        const SizedBox(height: 8),
        const Text(
          'Windows: Zuerst den Beleg einscannen oder fotografieren und dann die Bilddatei auswählen.',
        ),
      ],
      if (_photos.isNotEmpty) ...[
        const SizedBox(height: 20),
        Text(
          '${_photos.length} Seite(n) ausgewählt',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 126,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _photos.length,
            separatorBuilder: (_, _) => const SizedBox(width: 10),
            itemBuilder: (context, index) => SizedBox(
              width: 108,
              child: Column(
                children: [
                  Expanded(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(
                            File(_photos[index].path),
                            width: 108,
                            height: 92,
                            fit: BoxFit.contain,
                          ),
                        ),
                        Positioned(
                          right: 0,
                          top: 0,
                          child: IconButton.filledTonal(
                            tooltip: 'Seite entfernen',
                            iconSize: 18,
                            onPressed: _busy ? null : () => _removePhoto(index),
                            icon: const Icon(Icons.close),
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: _busy ? null : () => _cropPhoto(index),
                    icon: const Icon(Icons.crop, size: 16),
                    label: const Text('Rand ändern'),
                    style: TextButton.styleFrom(padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton.tonalIcon(
          onPressed: _busy ? null : _recognize,
          icon: const Icon(Icons.auto_awesome),
          label: const Text('Ohne Internet erkennen (lokale KI)'),
        ),
        const SizedBox(height: 10),
        if (_chatAccount?.planEnabled == true) ...[
          if (!_cloudSelection.rememberAiConsent)
            CheckboxListTile(
              value: _allowSendingToChatGpt,
              contentPadding: EdgeInsets.zero,
              onChanged: _busy
                  ? null
                  : (value) =>
                        setState(() => _allowSendingToChatGpt = value ?? false),
              title: const Text('Belegfotos an ChatGPT senden'),
              subtitle: const Text(
                'Die Bilder werden zur Auswertung an OpenAI übermittelt. '
                'Die Original-PDF bleibt lokal und wird nur an deine Synology hochgeladen.',
              ),
            )
          else
            const Card(
              child: ListTile(
                leading: Icon(Icons.verified_user_outlined),
                title: Text('ChatGPT-Bildübertragung dauerhaft erlaubt'),
                subtitle: Text(
                  'Die Freigabe lässt sich im ChatGPT-Bereich widerrufen.',
                ),
              ),
            ),
          FilledButton.icon(
            onPressed: _busy ? null : _recognizeWithChatGpt,
            icon: const Icon(Icons.smart_toy_outlined),
            label: const Text('Beleg fertig – mit ChatGPT erkennen'),
          ),
        ] else
          OutlinedButton.icon(
            onPressed: _busy ? null : () => setState(() => _tab = 3),
            icon: const Icon(Icons.smart_toy_outlined),
            label: const Text('ChatGPT-Konto verbinden'),
          ),
      ],
      if (_scanStatus != null) ...[
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFFFFF4DE),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(_scanStatus!),
          ),
        ),
      ],
      const SizedBox(height: 22),
      Text(
        'Erkannte Angaben prüfen',
        style: Theme.of(context).textTheme.titleLarge,
      ),
      const SizedBox(height: 6),
      const Text('Falsche oder fehlende Angaben einfach ändern.'),
      const SizedBox(height: 16),
      TextField(
        controller: _vendor,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(
          labelText: 'Firma',
          hintText: 'z. B. HORNBACH',
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _date,
        keyboardType: TextInputType.datetime,
        decoration: const InputDecoration(
          labelText: 'Rechnungsdatum',
          hintText: '27.10.2026',
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _total,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(
          labelText: 'Endbetrag (brutto)',
          hintText: '159,90 €',
        ),
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<PaymentMethod>(
        key: ValueKey(_paymentMethod),
        initialValue: _paymentMethod,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Zahlungsart'),
        items: [
          for (final method in PaymentMethod.values)
            DropdownMenuItem(value: method, child: Text(method.label)),
        ],
        onChanged: _busy
            ? null
            : (value) => setState(
                () => _paymentMethod = value ?? PaymentMethod.unknown,
              ),
      ),
      const SizedBox(height: 7),
      Text(
        'Buchung: ${_paymentMethod.bookingAccount}',
        style: TextStyle(
          color: _paymentMethod.bookingAccount == 'Unbekannt'
              ? Colors.deepOrange
              : const Color(0xFF176957),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _invoiceNumber,
        decoration: const InputDecoration(
          labelText: 'Rechnungs- / Belegnummer (optional)',
        ),
      ),
      const SizedBox(height: 12),
      Row(
        children: [
          Expanded(
            child: TextField(
              controller: _net,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'Netto (optional)'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _vat,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'MwSt. (optional)'),
            ),
          ),
        ],
      ),
      if (_analysis?.lineItems.isNotEmpty == true) ...[
        const SizedBox(height: 16),
        Text(
          'Erkannte Artikel / Positionen',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 4),
        for (final item in _analysis!.lineItems)
          ListTile(
            dense: true,
            title: Text(item.description),
            subtitle: Text(item.quantity ?? ''),
            trailing: item.grossCents == null
                ? null
                : Text('${_formatEuro(item.grossCents!)} €'),
          ),
      ],
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: _busy ? null : _saveReceipt,
        icon: const Icon(Icons.picture_as_pdf),
        label: const Text('PDF speichern und hochladen'),
      ),
      const SizedBox(height: 14),
      const Text(
        'Auch ohne NAS- oder Cloud-Verbindung wird jedes PDF zuerst im lokalen '
        'PDF-Eingang unter Jahr/Monat gespeichert. Der Upload kann später '
        'nachgeholt werden.',
        style: TextStyle(color: Colors.black54),
      ),
      const SizedBox(height: 20),
    ],
  );

  Widget _archivePage(int pending) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Text('Meine Belege', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 7),
      Text(
        '${_receipts.length} Belege gespeichert · $pending warten auf Upload',
      ),
      const SizedBox(height: 15),
      OutlinedButton.icon(
        onPressed: _busy ? null : _openLocalPdfDirectory,
        icon: const Icon(Icons.folder_open),
        label: const Text('Lokalen PDF-Ordner öffnen'),
      ),
      const SizedBox(height: 8),
      if (pending > 0)
        FilledButton.icon(
          onPressed: _busy ? null : _uploadPending,
          icon: const Icon(Icons.cloud_upload_outlined),
          label: Text('$pending Beleg(e) jetzt hochladen'),
        ),
      const SizedBox(height: 8),
      if (_receipts.isEmpty)
        const Card(
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Text(
              'Noch keine Belege vorhanden. Im Bereich „Scannen“ geht es los.',
            ),
          ),
        ),
      for (final receipt in _receipts)
        Card(
          child: ListTile(
            onTap: _busy ? null : () => _openReceipt(receipt),
            leading: Icon(
              receipt.uploaded || receipt.cloudDocumentUri != null
                  ? Icons.cloud_done
                  : Icons.cloud_off,
              color: receipt.uploaded || receipt.cloudDocumentUri != null
                  ? Colors.green
                  : Colors.orange,
            ),
            title: Text(receipt.vendor),
            subtitle: Text(
              '${DateFormat('dd.MM.yyyy').format(receipt.invoiceDate)} · ${_formatEuro(receipt.totalCents)} €'
              '${receipt.analysis == null ? '' : ' · ${receipt.analysis!.paymentMethod.bookingAccount}'}\n'
              'PDF-Eingang/${DateFormat('yyyy/MM').format(receipt.invoiceDate)} · '
              '${_isNasTarget(receipt.storageTarget) ? (receipt.uploaded ? '${_nasName(receipt.storageTarget)}-Kopie geprüft' : '${_nasName(receipt.storageTarget)}-Upload offen') : (receipt.cloudDocumentUri != null ? 'Beim Cloud-Anbieter abgelegt; Server-Synchronisierung offen' : 'Cloud-Kopie offen')}\n'
              'Zum Öffnen antippen',
            ),
            isThreeLine: true,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: 'Beleg löschen',
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: _busy ? null : () => _deleteReceipt(receipt),
                ),
                const Icon(Icons.open_in_new),
              ],
            ),
          ),
        ),
      if (_receipts.any(
        (r) =>
            r.storageTarget == _cloudSelection.target &&
            _isNasTarget(r.storageTarget) &&
            r.uploaded,
      )) ...[
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _busy ? null : _cleanupVerifiedCopies,
          icon: const Icon(Icons.fact_check_outlined),
          label: Text(
            'Ältere ${_nasName(_cloudSelection.target)}-Kopien prüfen und lokal entfernen',
          ),
        ),
      ],
      const SizedBox(height: 12),
      const Text(
        'Antippen öffnet den Beleg. Der Papierkorb löscht ihn nach '
        'Rückfrage am erkannten Speicherort: lokal oder auf der NAS. '
        'Frühere Sicherungen können noch Kopien enthalten.',
        style: TextStyle(color: Colors.black54),
      ),
    ],
  );

  Widget _settingsPage() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Text(
        'Sicherung für Neuinstallation',
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      const SizedBox(height: 10),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _backupConfigured
                    ? 'Automatische, verschlüsselte Sicherung aktiv'
                    : 'Noch keine dauerhafte Sicherung eingerichtet',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              const Text(
                'Wähle einen Ordner außerhalb der App, am besten '
                '„Interner Speicher / Dokumente / Belegbox-Sicherung“. '
                'Die App legt beim Scannen neue Sicherungsdateien an. '
                'Sie enthalten PDFs, Belegdaten, NAS-Zugang und die '
                'gespeicherte ChatGPT-Verbindung – mit einem Kennwort geschützt. '
                'Zusätzlich wird eine lesbare Belegliste (.json) mit Dateinamen, '
                'Status und NAS-Verknüpfungen angelegt – ohne Kennwörter. '
                'Die .json-Datei enthält keine PDF-Inhalte; für Belege, die '
                'nur auf dem Handy liegen, die verschlüsselte .bbx-Datei '
                'aufbewahren. Nach Neuinstallation kannst du beides einlesen. '
                'Das Sicherungskennwort gut aufbewahren!',
              ),
              if (_lastBackupName != null) ...[
                const SizedBox(height: 8),
                Text('Letzte bestätigte Sicherung: $_lastBackupName'),
              ],
            ],
          ),
        ),
      ),
      OutlinedButton.icon(
        onPressed: _busy ? null : _configureBackup,
        icon: const Icon(Icons.folder_special_outlined),
        label: Text(
          _backupConfigured
              ? 'Sicherungsordner ändern'
              : 'Sicherung einrichten',
        ),
      ),
      if (_backupConfigured)
        FilledButton.icon(
          onPressed: _busy ? null : _saveBackupManually,
          icon: const Icon(Icons.save_outlined),
          label: const Text('Jetzt Sicherung erstellen und prüfen'),
        ),
      OutlinedButton.icon(
        onPressed: _busy ? null : _restoreBackup,
        icon: const Icon(Icons.settings_backup_restore),
        label: const Text('Vollsicherung (.bbx) wiederherstellen'),
      ),
      OutlinedButton.icon(
        onPressed: _busy ? null : _restoreTextList,
        icon: const Icon(Icons.list_alt_outlined),
        label: const Text('Belegliste (.json) und NAS-Verknüpfungen einlesen'),
      ),
      const Text(
        'Wichtig: Vor dem Deinstallieren mindestens eine bestätigte '
        'Sicherungsdatei außerhalb der App besitzen. Android kann bei '
        'Deinstallation nach dem Behalten der App-Daten fragen, aber nicht '
        'bei jedem Deinstallationsweg.',
        style: TextStyle(color: Colors.black54),
      ),
      const Divider(height: 36),
      Text(
        'Speicherziel auswählen',
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        key: ValueKey(_cloudSelection.target),
        initialValue: _cloudSelection.target,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Neue PDFs speichern auf'),
        items: const [
          DropdownMenuItem(
            value: 'synology',
            child: Text('Eigene Synology NAS'),
          ),
          DropdownMenuItem(value: 'qnap', child: Text('Eigene QNAP NAS')),
          DropdownMenuItem(value: 'google_drive', child: Text('Google Drive')),
          DropdownMenuItem(
            value: 'onedrive',
            child: Text('Microsoft OneDrive'),
          ),
        ],
        onChanged: _busy ? null : _setCloudTarget,
      ),
      const SizedBox(height: 12),
      if (_isNasTarget(_cloudSelection.target)) ...[
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Nach bestätigter NAS-Sicherung lokal löschen'),
          subtitle: const Text(
            'Erst nach erneutem Herunterladen und SHA-256-Vergleich. '
            'Beim ersten Test am besten ausgeschaltet lassen.',
          ),
          value: _cloudSelection.deleteAfterNasVerification,
          onChanged: _busy ? null : _setDeleteAfterVerify,
        ),
      ] else ...[
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              'Öffne die Android-Dateiauswahl und wähle dort einen Ordner '
              'deines angemeldeten ${_cloudSelection.target == 'google_drive' ? 'Google Drive' : 'OneDrive'}. '
              'Der Anbieter muss in der Android-Dateiauswahl verfügbar sein. '
              'Die App erstellt darin PDF-Eingang/Jahr/Monat. '
              'Eine Kopie im Android-Cloud-Ordner beweist noch nicht, '
              'dass der Internet-Upload abgeschlossen ist: Das Original '
              'bleibt deshalb auf dem Handy.',
            ),
          ),
        ),
        OutlinedButton.icon(
          onPressed: _busy ? null : _chooseCloudFolder,
          icon: const Icon(Icons.folder_open_outlined),
          label: Text(
            _cloudSelection.folderFor(_cloudSelection.target) == null
                ? 'Cloud-Ordner auswählen'
                : 'Cloud-Ordner ändern (bereits verbunden)',
          ),
        ),
      ],
      if (_isNasTarget(_cloudSelection.target)) ...[
        const Divider(height: 36),
        Text(
          '${_nasName(_cloudSelection.target)}-Verbindung (eigene Cloud)',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 8),
        const Text(
          'Direkte Verbindung zur NAS per HTTPS/WebDAV – ein VPN ist nicht '
          'erforderlich. Trage den freigegebenen Hauptordner ein, bei Bedarf '
          'mit vorhandenem Unterordner, z. B. Daten/Belege/Eingang. '
          'Darunter erstellt Belegbox Jahr und Monat automatisch: 2026/10. '
          'Die Zugangsdaten für Synology und QNAP bleiben getrennt.',
        ),
        const SizedBox(height: 20),
        TextField(
          controller: _nasUrl,
          keyboardType: TextInputType.url,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: 'Direkte WebDAV-HTTPS-Adresse (ohne VPN)',
            hintText: _cloudSelection.target == 'qnap'
                ? 'https://qnap.example:5001'
                : 'https://nas.example:5006',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _folder,
          autocorrect: false,
          decoration: const InputDecoration(
            labelText: 'Freigegebener Belegordner / Unterordner',
            hintText: 'Daten/Belege/Eingang',
            helperText:
                'Freigabe und Unterordner müssen auf der NAS existieren.',
            helperMaxLines: 2,
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _nasUser,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: '${_nasName(_cloudSelection.target)}-Benutzername',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _nasPassword,
          obscureText: true,
          enableSuggestions: false,
          autocorrect: false,
          decoration: const InputDecoration(labelText: 'Passwort'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _busy ? null : _saveSettings,
          icon: const Icon(Icons.save_outlined),
          label: const Text('Verbindung speichern'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _busy ? null : _testConnection,
          icon: const Icon(Icons.wifi_tethering),
          label: const Text('Verbindung testen'),
        ),
        const SizedBox(height: 22),
        Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              _cloudSelection.target == 'qnap'
                  ? 'QNAP QTS:\n1. WebDAV und HTTPS in der NAS-Verwaltung aktivieren.\n2. Direkten HTTPS-WebDAV-Port kontrollieren.\n3. Freigabe und gewünschten Beleg-Unterordner vorher anlegen; Benutzer mit Lese-/Schreibrechten einrichten.\n4. Verbindung testen: jeder konfigurierte Ordner wird per WebDAV geprüft.\n5. Für Zugriff über Mobilfunk ohne VPN ist eine sicher eingerichtete HTTPS-Adresse erforderlich. Die App richtet keine Routerfreigabe ein.'
                  : 'Synology:\n1. Paket „WebDAV Server“ installieren, HTTPS einschalten (oft Port 5006).\n2. Vorhandene Freigabe und Beleg-Unterordner angeben. Beispiel: Daten/Belege.\n3. Benutzer mit Lese-/Schreibrechten auf diesen Pfad einrichten.\n4. „Verbindung testen“ prüft alle vorhandenen Ordner per WebDAV; beim Hochladen werden Jahr/Monat angelegt.\n5. Ohne VPN im Heimnetz direkt erreichbar. Über Mobilfunk ist eine abgesicherte öffentliche HTTPS-/Reverse-Proxy-Adresse nötig; QuickConnect allein reicht für WebDAV nicht.',
            ),
          ),
        ),
      ],
    ],
  );

  Widget _chatGptPage() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Text(
        'Mit ChatGPT verbinden',
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      const SizedBox(height: 10),
      const Text(
        'Verwende dein vorhandenes ChatGPT Plus, um Kassenbons komplett '
        'auszuwerten. Die Belegbox erfährt dein ChatGPT-Passwort nicht. '
        'Du meldest dich im offiziellen Browser an und erlaubst die Nutzung.',
      ),
      if (_chatConnectionStatus != null) ...[
        const SizedBox(height: 12),
        Card(
          color: _chatAccount?.planEnabled == true
              ? const Color(0xFFE5F5EC)
              : const Color(0xFFFFF4DE),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SelectableText(_chatConnectionStatus!),
          ),
        ),
      ],
      const SizedBox(height: 20),
      if (_chatAccount == null) ...[
        FilledButton.icon(
          onPressed: _busy ? null : _connectChatGpt,
          icon: const Icon(Icons.login),
          label: const Text('Mit ChatGPT anmelden'),
        ),
      ] else ...[
        Card(
          color: const Color(0xFFE5F5EC),
          child: ListTile(
            leading: const Icon(Icons.verified_user, color: Color(0xFF176957)),
            title: Text(_chatAccount!.email),
            subtitle: Text(
              _chatAccount!.planEnabled
                  ? 'ChatGPT-Plus-Nutzung freigegeben'
                  : 'Nutzung noch nicht freigegeben',
            ),
          ),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          onPressed: _busy ? null : _refreshModels,
          icon: const Icon(Icons.refresh),
          label: const Text('Verfügbare ChatGPT-Modelle laden'),
        ),
        if (_availableModels.isNotEmpty) ...[
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            key: ValueKey(_chosenModel),
            initialValue: _chosenModel,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Modell für Belege'),
            items: [
              for (final model in _availableModels)
                DropdownMenuItem(value: model.slug, child: Text(model.title)),
            ],
            onChanged: _busy
                ? null
                : (value) => setState(() => _chosenModel = value),
          ),
        ],
        const SizedBox(height: 18),
        OutlinedButton.icon(
          onPressed: _busy ? null : _connectChatGpt,
          icon: const Icon(Icons.login),
          label: const Text('Erneut anmelden'),
        ),
        const SizedBox(height: 8),
        TextButton.icon(
          onPressed: _busy ? null : _disconnectChatGpt,
          icon: const Icon(Icons.logout),
          label: const Text('ChatGPT abmelden'),
        ),
      ],
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: _busy ? null : _testChatGptNetwork,
        icon: const Icon(Icons.wifi_find),
        label: const Text('ChatGPT-Verbindung prüfen'),
      ),
      const SizedBox(height: 12),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Belegbilder künftig ohne Einzelbestätigung senden'),
        subtitle: const Text(
          'Einmalige ausdrückliche Freigabe für spätere ChatGPT-Auswertungen. '
          'Du entscheidest weiter, wann der vollständige Beleg ausgewertet '
          'wird. Hier jederzeit widerrufbar.',
        ),
        value: _cloudSelection.rememberAiConsent,
        onChanged: _busy ? null : _setAiConsent,
      ),
      const SizedBox(height: 18),
      const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            'So funktioniert es:\n'
            '1. Mit ChatGPT anmelden und die Nutzung erlauben.\n'
            '2. Zurück zu „Scannen“ und den Beleg fotografieren.\n'
            '3. Die Bildübertragung einmalig freigeben oder pro Beleg bestätigen.\n'
            '4. „Beleg fertig – mit ChatGPT erkennen“ drücken.\n'
            '5. Firma, Betrag, Zahlungsart und Positionen prüfen.\n'
            '6. Das PDF am ausgewählten Speicherziel ablegen.\n\n'
            'Die Bilder werden nur nach deiner Einwilligung an OpenAI '
            'gesendet. Für ChatGPT Plus gelten Nutzungslimits.',
          ),
        ),
      ),
    ],
  );
}
