import 'receipt_analysis.dart';

class ReceiptDraft {
  const ReceiptDraft({
    required this.vendor,
    required this.date,
    required this.totalCents,
    this.paymentMethod = PaymentMethod.unknown,
  });

  final String vendor;
  final DateTime? date;
  final int? totalCents;
  final PaymentMethod paymentMethod;
}

class SavedReceipt {
  const SavedReceipt({
    required this.id,
    required this.fileName,
    required this.localPath,
    required this.vendor,
    required this.invoiceDate,
    required this.totalCents,
    required this.createdAt,
    required this.uploaded,
    this.storageTarget = 'synology',
    this.cloudDocumentUri,
    this.sha256Digest,
    this.remoteUri,
    this.analysis,
  });

  final String id;
  final String fileName;
  final String localPath;
  final String vendor;
  final DateTime invoiceDate;
  final int totalCents;
  final DateTime createdAt;
  final bool uploaded;

  /// synology, google_drive or onedrive (missing in older indexes = synology).
  final String storageTarget;

  /// Android DocumentProvider copy. This is NOT proof of remote cloud sync.
  final String? cloudDocumentUri;

  /// SHA-256 of the original PDF for safe remote operations.
  /// May be absent on records from older app versions.
  final String? sha256Digest;

  /// Exact WebDAV document URL used on the confirmed upload.
  /// Null for documents created by older versions. No credentials here.
  final String? remoteUri;
  final ReceiptAnalysis? analysis;

  SavedReceipt copyWith({
    bool? uploaded,
    String? cloudDocumentUri,
    String? remoteUri,
  }) =>
      SavedReceipt(
        id: id,
        fileName: fileName,
        localPath: localPath,
        vendor: vendor,
        invoiceDate: invoiceDate,
        totalCents: totalCents,
        createdAt: createdAt,
        uploaded: uploaded ?? this.uploaded,
        storageTarget: storageTarget,
        cloudDocumentUri: cloudDocumentUri ?? this.cloudDocumentUri,
        sha256Digest: sha256Digest,
        remoteUri: remoteUri ?? this.remoteUri,
        analysis: analysis,
      );

  Map<String, dynamic> toJson() => {
    'id': id,
    'fileName': fileName,
    'localPath': localPath,
    'vendor': vendor,
    'invoiceDate': invoiceDate.toIso8601String(),
    'totalCents': totalCents,
    'createdAt': createdAt.toIso8601String(),
    'uploaded': uploaded,
    'storageTarget': storageTarget,
    'cloudDocumentUri': cloudDocumentUri,
    'sha256Digest': sha256Digest,
    'remoteUri': remoteUri,
    'analysis': analysis?.toJson(),
  };

  factory SavedReceipt.fromJson(Map<String, dynamic> data) => SavedReceipt(
    id: data['id'] as String,
    fileName: data['fileName'] as String,
    localPath: data['localPath'] as String,
    vendor: data['vendor'] as String,
    invoiceDate: DateTime.parse(data['invoiceDate'] as String),
    totalCents: data['totalCents'] as int,
    createdAt: DateTime.parse(data['createdAt'] as String),
    uploaded: data['uploaded'] as bool? ?? false,
    storageTarget: data['storageTarget'] as String? ?? 'synology',
    cloudDocumentUri: data['cloudDocumentUri'] as String?,
    sha256Digest: data['sha256Digest'] as String?,
    remoteUri: data['remoteUri'] as String?,
    analysis: data['analysis'] is Map<String, dynamic>
        ? ReceiptAnalysis.fromJson(data['analysis'] as Map<String, dynamic>)
        : null,
  );
}
