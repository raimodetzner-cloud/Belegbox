/// Die KI-Auswertung ist ein Vorschlag, keine ungeprüfte Buchungsgrundlage.
enum PaymentMethod {
  cash,
  girocard,
  creditCard,
  debitCard,
  transfer,
  paypal,
  other,
  unknown;

  String get label => switch (this) {
    cash => 'Barzahlung',
    girocard => 'Girocard / EC-Karte',
    creditCard => 'Kreditkarte',
    debitCard => 'Debitkarte',
    transfer => 'Überweisung',
    paypal => 'PayPal',
    other => 'Sonstige Zahlung',
    unknown => 'Unbekannt',
  };

  String get bookingAccount => switch (this) {
    cash => 'Kasse',
    girocard || creditCard || debitCard || transfer || paypal => 'Bank',
    other || unknown => 'Unbekannt',
  };

  static PaymentMethod fromValue(Object? raw) {
    final value = raw?.toString().trim().toLowerCase() ?? '';
    return switch (value) {
      'cash' || 'bar' || 'barzahlung' => cash,
      'girocard' || 'ec' || 'ec-karte' => girocard,
      'credit_card' || 'creditcard' || 'kreditkarte' => creditCard,
      'debit_card' || 'debitcard' || 'debitkarte' => debitCard,
      'transfer' || 'ueberweisung' || 'überweisung' => transfer,
      'paypal' => paypal,
      'other' || 'sonstige' => other,
      _ => unknown,
    };
  }
}

class ReceiptItem {
  const ReceiptItem({
    required this.description,
    this.quantity,
    this.grossCents,
  });

  final String description;
  final String? quantity;
  final int? grossCents;

  Map<String, dynamic> toJson() => {
    'description': description,
    'quantity': quantity,
    'gross_cents': grossCents,
  };

  factory ReceiptItem.fromJson(Map<String, dynamic> data) => ReceiptItem(
    description: _safeString(data['description']),
    quantity: _nullableString(data['quantity']),
    grossCents: _nullableInt(data['gross_cents']),
  );
}

class ReceiptAnalysis {
  const ReceiptAnalysis({
    required this.vendor,
    this.invoiceDate,
    this.grossCents,
    this.paymentMethod = PaymentMethod.unknown,
    this.invoiceNumber,
    this.vatCents,
    this.netCents,
    this.currency = 'EUR',
    this.lineItems = const [],
    this.note,
  });

  final String vendor;
  final DateTime? invoiceDate;
  final int? grossCents;
  final PaymentMethod paymentMethod;
  final String? invoiceNumber;
  final int? vatCents;
  final int? netCents;
  final String currency;
  final List<ReceiptItem> lineItems;
  final String? note;

  static ReceiptAnalysis fromJson(Map<String, dynamic> data) {
    DateTime? date;
    final inputDate = _nullableString(data['invoice_date']);
    if (inputDate != null &&
        RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(inputDate)) {
      final parsed = DateTime.tryParse(inputDate);
      if (parsed != null &&
          parsed.toIso8601String().startsWith(inputDate) &&
          parsed.year >= 2000 &&
          parsed.year <= DateTime.now().year + 1) {
        date = parsed;
      }
    }
    final rawItems = data['line_items'];
    final items = rawItems is List
        ? rawItems
              .whereType<Map<String, dynamic>>()
              .map(ReceiptItem.fromJson)
              .where((item) => item.description.isNotEmpty)
              .take(150)
              .toList()
        : <ReceiptItem>[];
    final currency = _safeString(data['currency']).toUpperCase();
    return ReceiptAnalysis(
      vendor: _safeString(data['vendor']),
      invoiceDate: date,
      grossCents: _nullableInt(data['gross_cents']),
      paymentMethod: PaymentMethod.fromValue(data['payment_method']),
      invoiceNumber: _nullableString(data['invoice_number']),
      vatCents: _nullableInt(data['vat_cents']),
      netCents: _nullableInt(data['net_cents']),
      currency: currency.isEmpty ? 'EUR' : currency,
      lineItems: items,
      note: _nullableString(data['note']),
    );
  }

  Map<String, dynamic> toJson() => {
    'vendor': vendor,
    'invoice_date': invoiceDate?.toIso8601String().substring(0, 10),
    'gross_cents': grossCents,
    'payment_method': paymentMethod.name,
    'invoice_number': invoiceNumber,
    'vat_cents': vatCents,
    'net_cents': netCents,
    'currency': currency,
    'line_items': lineItems.map((e) => e.toJson()).toList(),
    'note': note,
  };
}

String _safeString(Object? value) => value is String ? value.trim() : '';

String? _nullableString(Object? value) {
  final valueString = _safeString(value);
  return valueString.isEmpty ? null : valueString;
}

int? _nullableInt(Object? value) {
  if (value is int) return value >= 0 ? value : null;
  // Keine Fließkommazahlen für Geldbeträge übernehmen.
  return null;
}
