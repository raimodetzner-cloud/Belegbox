import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'local_archive.dart';

/// A portable, passphrase-protected backup in a user-chosen document folder.
/// The passphrase itself is never placed inside the backup file.
class BackupService {
  const BackupService({FlutterSecureStorage? store})
    : _store = store ?? const FlutterSecureStorage();

  final FlutterSecureStorage _store;
  static const _channel = MethodChannel('de.dnh24.belegbox/files');

  static const _folderKey = 'belegbox_backup_tree_v1';
  static const _passwordKey = 'belegbox_backup_password_v1';

  static const _portableKeys = [
    'nas_url',
    'nas_folder',
    'nas_user',
    'nas_password',
    'qnap_url',
    'qnap_folder',
    'qnap_user',
    'qnap_password',
    'cloud_selected_target_v1',
    'chatgpt_connection_v1',
    'chatgpt_host_id_v1',
  ];

  Future<bool> get isConfigured async =>
      (await _store.read(key: _folderKey)) != null &&
      (await _store.read(key: _passwordKey)) != null;

  Future<void> configure(String folderUri, String password) async {
    if (password.length < 12) {
      throw StateError('Das Sicherungskennwort braucht mindestens 12 Zeichen.');
    }
    await _store.write(key: _folderKey, value: folderUri);
    await _store.write(key: _passwordKey, value: password);
  }

  Future<String?> chooseFolder() =>
      _channel.invokeMethod<String>('chooseFolder');

  Future<String?> selectBackupFile() =>
      _channel.invokeMethod<String>('selectBackupFile');

  Future<String?> saveIfConfigured() async {
    if (!await isConfigured) return null;
    return save();
  }

  Future<String> save() async {
    final folder = await _store.read(key: _folderKey);
    final password = await _store.read(key: _passwordKey);
    if (folder == null || password == null) {
      throw StateError(
        'Bitte zuerst den Sicherungsordner und ein Kennwort festlegen.',
      );
    }
    final settings = <String, String>{};
    for (final key in _portableKeys) {
      final value = await _store.read(key: key);
      if (value != null) settings[key] = value;
    }
    final info = jsonEncode({
      'format': 'belegbox-backup-v1',
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'settings': settings,
    });
    final manifest = await LocalArchive().exportManifestJson();
    final name = await _channel.invokeMethod<String>('exportEncryptedBackup', {
      'folderUri': folder,
      'password': password,
      'settingsJson': info,
      'manifestJson': manifest,
    });
    if (name == null) throw StateError('Sicherung wurde nicht bestätigt.');
    return name;
  }

  /// The text index contains no PDFs or credentials. It can only reconnect
  /// NAS-backed items after reinstall; use .bbx for local-only receipts.
  Future<RestoreSummary> restoreManifest({
    required String documentUri,
    required LocalArchive archive,
  }) async {
    final text = await _channel.invokeMethod<String>('readTextManifest', {
      'documentUri': documentUri,
    });
    if (text == null) throw StateError('Belegliste konnte nicht gelesen werden.');
    return archive.mergeFromManifestJson(text);
  }

  /// Import only known fields. Previously selected Android cloud document URI
  /// grants cannot be transferred to a fresh install and must be selected anew.
  Future<RestoreSummary> restore({
    required String backupUri,
    required String password,
    required LocalArchive archive,
  }) async {
    final stagingPath = await _channel.invokeMethod<String>(
      'restoreEncryptedBackup',
      {'documentUri': backupUri, 'password': password},
    );
    if (stagingPath == null)
      throw StateError('Sicherungsdatei nicht geöffnet.');
    final staging = Directory(stagingPath);
    try {
      final settingsFile = File('${staging.path}/belegbox-info.json');
      if (!await settingsFile.exists()) {
        throw StateError('Die Sicherung enthält keine Einstellungen.');
      }
      final raw = jsonDecode(await settingsFile.readAsString());
      if (raw is! Map<String, dynamic> ||
          raw['format'] != 'belegbox-backup-v1') {
        throw StateError('Unbekanntes Sicherungsformat.');
      }
      final settingsRaw = raw['settings'];
      if (settingsRaw is! Map<String, dynamic>) {
        throw StateError('Einstellungen der Sicherung sind beschädigt.');
      }
      final restored = await archive.mergeFromBackup(
        Directory('${staging.path}/files'),
      );
      for (final key in _portableKeys) {
        final value = settingsRaw[key];
        if (value is String) {
          await _store.write(key: key, value: value);
        }
      }
      // Never restore a previously granted folder permission or destructive
      // cleanup choice without explicit consent in this installation.
      await _store.delete(key: 'cloud_google_folder_v1');
      await _store.delete(key: 'cloud_onedrive_folder_v1');
      await _store.write(key: 'cloud_delete_verified_v1', value: 'false');
      await _store.write(
        key: 'chatgpt_remember_image_consent_v1',
        value: 'false',
      );
      return restored;
    } finally {
      if (await staging.exists()) await staging.delete(recursive: true);
    }
  }
}
