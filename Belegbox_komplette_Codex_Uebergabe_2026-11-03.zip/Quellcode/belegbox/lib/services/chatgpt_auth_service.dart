import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:jose/jose.dart';
import 'package:url_launcher/url_launcher.dart';

import 'dns_retry.dart';

/// Official Sign in with ChatGPT flow for personal/local open-source apps.
/// https://developers.openai.com/siwc/token-sharing-open-source/sign-in
/// No password or API key is handled by Belegbox.
class ChatGptAuthService {
  ChatGptAuthService({FlutterSecureStorage? storage, http.Client? client})
    : _storage = storage ?? const FlutterSecureStorage(),
      _client = client ?? http.Client();

  static const _authorization =
      'https://auth.openai.com/api/accounts/authorize';
  static const _tokenEndpoint =
      'https://auth.openai.com/api/accounts/oauth/token';
  static const _jwksEndpoint = 'https://auth.openai.com/.well-known/jwks.json';
  static const _resource = 'https://api.openai.com/v1';
  static const _credentialKey = 'chatgpt_connection_v1';
  static const _hostKey = 'chatgpt_host_id_v1';
  static const _pendingClientKey = 'chatgpt_pending_client_v1';

  final FlutterSecureStorage _storage;
  final http.Client _client;
  Future<ChatGptCredentials>? _refreshInProgress;

  Future<ChatGptCredentials?> load() async {
    final raw = await _storage.read(key: _credentialKey);
    if (raw == null) return null;
    try {
      return ChatGptCredentials.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
    } catch (_) {
      return null;
    }
  }

  /// Diagnoses the app's own HTTPS access, independently of the browser,
  /// ChatGPT sign-in and Synology settings. No credentials are transmitted.
  Future<String> checkReachability() async {
    final endpoints = <String, Uri>{
      'Anmeldung': Uri.parse(
        'https://auth.openai.com/.well-known/openid-configuration',
      ),
      'Signaturschlüssel': Uri.parse(_jwksEndpoint),
      'OpenAI API': Uri.parse('https://api.openai.com/v1/models'),
    };
    final results = <String>[];
    for (final entry in endpoints.entries) {
      try {
        final response = await _client
            .get(entry.value)
            .timeout(const Duration(seconds: 12));
        final expected = entry.key == 'OpenAI API'
            ? <int>{200, 401, 403}
            : <int>{200};
        results.add(
          '${entry.key}: ${expected.contains(response.statusCode) ? 'erreichbar' : 'HTTP ${response.statusCode}'}',
        );
      } catch (error) {
        results.add('${entry.key}: Fehler: ${error.toString()}');
      }
    }
    return results.join('\n');
  }

  Future<ChatGptCredentials> connect({
    void Function(String)? onProgress,
  }) async {
    final previous = await load();
    final pendingId = previous == null
        ? await _storage.read(key: _pendingClientKey)
        : null;
    final host = await _hostId();
    final state = _randomUrlSafe(32);
    final nonce = _randomUrlSafe(32);
    final verifier = _randomUrlSafe(48);
    final challenge = base64UrlEncode(
      sha256.convert(ascii.encode(verifier)).bytes,
    ).replaceAll('=', '');

    // Only listen on this device. The system browser returns to this socket.
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    final redirect = 'http://127.0.0.1:${server.port}/auth/callback';
    final registration =
        previous?.clientId ?? pendingId ?? 'dynamic_agent_client';
    final arguments = <String, String>{
      'client_id': registration,
      'ext_agent_host_id': host,
      'response_type': 'code',
      'redirect_uri': redirect,
      'scope':
          'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct',
      'resource': _resource,
      'state': state,
      'nonce': nonce,
      'code_challenge_method': 'S256',
      'code_challenge': challenge,
    };
    if (registration == 'dynamic_agent_client') {
      arguments['agent_name_hint'] = 'Belegbox';
    } else if (previous != null) {
      // The hint is sent exclusively to OpenAI's authorization endpoint.
      arguments['id_token_hint'] = previous.idToken;
    }

    try {
      onProgress?.call(
        'ChatGPT-Anmeldung im Browser geöffnet. Bitte dort zustimmen.',
      );
      final uri = Uri.parse(_authorization).replace(queryParameters: arguments);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw StateError(
          'Die ChatGPT-Anmeldeseite konnte nicht geöffnet werden.',
        );
      }

      final callback = await _receiveCallback(server).timeout(
        const Duration(minutes: 10),
        onTimeout: () => throw TimeoutException(
          'Die Anmeldung wurde nicht innerhalb von zehn Minuten beendet.',
        ),
      );
      onProgress?.call(
        'Browser-Bestätigung eingetroffen. Prüfe ChatGPT-Anmeldung ...',
      );
      if (callback['state'] != state) {
        throw const FormatException(
          'Die Anmeldung konnte nicht geprüft werden (state).',
        );
      }
      if (callback['error'] != null) {
        throw StateError(
          'ChatGPT-Anmeldung abgebrochen oder nicht freigegeben.',
        );
      }
      final code = callback['code'];
      if (code == null || code.isEmpty) {
        throw const FormatException('Der Anmeldecode fehlt.');
      }
      final clientId = callback['client_id'] ?? previous?.clientId ?? pendingId;
      if (clientId == null || clientId == 'dynamic_agent_client') {
        throw const FormatException(
          'Die Registrierung wurde nicht abgeschlossen.',
        );
      }
      if (previous != null && clientId != previous.clientId) {
        throw const FormatException(
          'Die Anmeldung gehört zu einem anderen Konto.',
        );
      }
      if (pendingId != null && previous == null && clientId != pendingId) {
        throw const FormatException(
          'Die Anmeldebestätigung gehört nicht zur gespeicherten Registrierung.',
        );
      }
      // Registrierung merken, auch wenn der einmalige Code später fehlschlägt.
      // Bei einer Wiederholung darf dynamic_agent_client nicht erneut benutzt werden.
      await _storage.write(key: _pendingClientKey, value: clientId);
      onProgress?.call(
        'ChatGPT hat die Anmeldung bestätigt. Fordere sichere Zugangsdaten an ...',
      );
      final tokenData = await _requestTokens({
        'grant_type': 'authorization_code',
        'client_id': clientId,
        'code': code,
        'code_verifier': verifier,
        'redirect_uri': redirect,
        'resource': _resource,
      }, onProgress: onProgress);
      final token = tokenData['id_token'];
      if (token is! String) {
        throw const FormatException(
          'ChatGPT hat keine überprüfbare Kontoidentität geliefert.',
        );
      }
      onProgress?.call('Prüfe die ChatGPT-Kontosignatur und Berechtigung ...');
      final identity = await _verifyIdToken(token, clientId, nonce);
      if (previous != null && identity['sub'] != previous.subject) {
        throw const FormatException(
          'Anderes ChatGPT-Konto erkannt. Anmeldung verworfen.',
        );
      }
      final scopes = _scopes(tokenData['scope']);
      if (!scopes.contains('chatgpt.tokens.use.direct') ||
          !scopes.contains('resource.invoke')) {
        throw StateError(
          'Bitte bei ChatGPT die Nutzung deines Abos für Belegbox erlauben.',
        );
      }
      final credentials = ChatGptCredentials(
        clientId: clientId,
        subject: identity['sub'] as String,
        email:
            identity['email'] as String? ?? previous?.email ?? 'ChatGPT-Konto',
        idToken: token,
        accessToken: tokenData['access_token'] as String,
        refreshToken: tokenData['refresh_token'] as String,
        scopes: scopes,
        expiresAt: DateTime.now().toUtc().add(
          Duration(seconds: (tokenData['expires_in'] as num?)?.toInt() ?? 3600),
        ),
      );
      await _save(credentials);
      await _storage.delete(key: _pendingClientKey);
      onProgress?.call(
        'ChatGPT erfolgreich verbunden und dauerhaft gespeichert.',
      );
      return credentials;
    } finally {
      await server.close(force: true);
    }
  }

  /// Inference tokens are only used after verifying the OIDC identity and
  /// the explicit ChatGPT plan usage scopes.
  Future<String> accessToken() async {
    final credentials = await load();
    if (credentials == null) {
      throw StateError('Bitte zuerst unter ChatGPT anmelden.');
    }
    if (!credentials.planEnabled) {
      throw StateError(
        'Die ChatGPT-Abo-Nutzung ist für Belegbox nicht freigegeben.',
      );
    }
    if (credentials.expiresAt.isAfter(
      DateTime.now().toUtc().add(const Duration(minutes: 2)),
    )) {
      return credentials.accessToken;
    }
    final refresh = _refreshInProgress ??= _refresh(credentials);
    try {
      return (await refresh).accessToken;
    } finally {
      _refreshInProgress = null;
    }
  }

  Future<void> disconnect() async {
    final credentials = await load();
    if (credentials != null) {
      try {
        final discovery = await _client
            .get(
              Uri.parse(
                'https://auth.openai.com/.well-known/openid-configuration',
              ),
            )
            .timeout(const Duration(seconds: 12));
        if (discovery.statusCode == 200) {
          final metadata = jsonDecode(discovery.body) as Map<String, dynamic>;
          final revocation = metadata['revocation_endpoint'] as String?;
          if (revocation != null &&
              Uri.tryParse(revocation)?.host == 'auth.openai.com') {
            await _client
                .post(
                  Uri.parse(revocation),
                  body: {
                    'token': credentials.refreshToken,
                    'token_type_hint': 'refresh_token',
                    'client_id': credentials.clientId,
                  },
                )
                .timeout(const Duration(seconds: 12));
          }
        }
      } catch (_) {
        // Local sign-out still takes effect; remote revocation might not have.
      }
    }
    await _storage.delete(key: _credentialKey);
    await _storage.delete(key: _pendingClientKey);
  }

  Future<ChatGptCredentials> _refresh(ChatGptCredentials previous) async {
    final data = await _requestTokens({
      'grant_type': 'refresh_token',
      'client_id': previous.clientId,
      'refresh_token': previous.refreshToken,
      'resource': _resource,
    });
    final next = previous.copyWith(
      accessToken: data['access_token'] as String,
      refreshToken: data['refresh_token'] as String,
      scopes: data['scope'] == null ? previous.scopes : _scopes(data['scope']),
      expiresAt: DateTime.now().toUtc().add(
        Duration(seconds: (data['expires_in'] as num?)?.toInt() ?? 3600),
      ),
    );
    if (!next.planEnabled) throw StateError('ChatGPT-Freigabe ist abgelaufen.');
    await _save(next);
    return next;
  }

  Future<Map<String, dynamic>> _requestTokens(
    Map<String, String> form, {
    void Function(String)? onProgress,
  }) async {
    final result = await retryDnsLookup(
      () => _client
          .post(Uri.parse(_tokenEndpoint), body: form)
          .timeout(const Duration(seconds: 30)),
      onRetry: (attempt, total) async {
        onProgress?.call(
          'DNS nach Browser-Rückkehr kurz unterbrochen. '
          'Prüfe OpenAI-Verbindung und wiederhole Anmeldung '
          '(Versuch ${attempt + 1} von $total) ...',
        );
        // A harmless HTTPS GET can restore the HTTP client's connection to
        // this origin. Keep the OAuth code and secret verifier inside the app.
        try {
          await _client
              .get(
                Uri.parse(
                  'https://auth.openai.com/.well-known/openid-configuration',
                ),
              )
              .timeout(const Duration(seconds: 5));
        } catch (_) {
          // The following POST attempt remains the authoritative test.
        }
      },
    );
    if (result.statusCode != 200) {
      String? code;
      try {
        final failure = jsonDecode(result.body);
        if (failure is Map<String, dynamic> && failure['error'] is String) {
          code = failure['error'] as String;
        }
      } catch (_) {
        // Absichtlich keine rohen Token-Antworten oder andere Kontodaten anzeigen.
      }
      final reason = code == null ? '' : ' ($code)';
      throw StateError(
        'Die ChatGPT-Anmeldung konnte nicht bestätigt werden '
        '(HTTP ${result.statusCode}$reason). '
        'Bitte erneut anmelden.',
      );
    }
    return jsonDecode(result.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> _verifyIdToken(
    String token,
    String clientId,
    String expectedNonce,
  ) async {
    final jws = JsonWebSignature.fromCompactSerialization(token);
    final protectedHeader = jws.unverifiedPayload.protectedHeader;
    if (protectedHeader == null) {
      throw const FormatException('Die ChatGPT-Signatur fehlt.');
    }
    final header = protectedHeader.toJson();
    final algorithm = header['alg'];
    if (algorithm != 'RS256' && algorithm != 'ES256') {
      throw const FormatException('Unbekannte Signatur der ChatGPT-Anmeldung.');
    }
    final keyResponse = await retryDnsLookup(
      () => _client
          .get(Uri.parse(_jwksEndpoint))
          .timeout(const Duration(seconds: 25)),
    );
    if (keyResponse.statusCode != 200) {
      throw const FormatException(
        'ChatGPT-Signaturschlüssel nicht erreichbar.',
      );
    }
    final jwks = jsonDecode(keyResponse.body) as Map<String, dynamic>;
    final store = JsonWebKeyStore();
    for (final key in (jwks['keys'] as List<dynamic>)) {
      if (key is! Map<String, dynamic>) continue;
      if (key['kid'] != header['kid']) continue;
      if (key['use'] != null && key['use'] != 'sig') continue;
      store.addKey(JsonWebKey.fromJson(key));
    }
    if (!await jws.verify(store)) {
      throw const FormatException('Die ChatGPT-Kontosignatur ist ungültig.');
    }
    final claims =
        jsonDecode(jws.unverifiedPayload.stringContent) as Map<String, dynamic>;
    final audience = claims['aud'];
    final audienceValid =
        audience == clientId ||
        (audience is List && audience.contains(clientId));
    final expiresAt = claims['exp'];
    final nowSeconds = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    if (claims['iss'] != 'https://auth.openai.com' ||
        !audienceValid ||
        expiresAt is! num ||
        expiresAt.toInt() <= nowSeconds ||
        claims['nonce'] != expectedNonce ||
        claims['sub'] is! String ||
        (claims['sub'] as String).isEmpty) {
      throw const FormatException('ChatGPT-Identitätsprüfung fehlgeschlagen.');
    }
    return claims;
  }

  Future<Map<String, String>> _receiveCallback(HttpServer server) async {
    await for (final request in server) {
      if (request.uri.path != '/auth/callback') {
        request.response.statusCode = 404;
        await request.response.close();
        continue;
      }
      request.response.headers.contentType = ContentType.html;
      final returnButton = Platform.isAndroid
          ? '<p><a href="belegboxbeta://auth-return" '
                'style="display:inline-block;padding:14px 22px;'
                'background:#176957;color:white;border-radius:8px;'
                'text-decoration:none">Belegbox öffnen</a></p>'
          : '';
      request.response.write(
        '<!doctype html><html lang="de"><meta charset="utf-8">'
        '<title>Belegbox</title><body><h2>Bitte Belegbox wieder öffnen</h2>'
        'Die Browser-Anmeldung ist beendet. Belegbox prüft jetzt noch '
        'den Zugang. Ob die Verbindung geklappt hat, siehst du '
        'im Bereich ChatGPT in der App.'
        '$returnButton'
        '</body></html>',
      );
      await request.response.close();
      return request.uri.queryParameters;
    }
    throw StateError('Anmeldeverbindung wurde geschlossen.');
  }

  Future<String> _hostId() async {
    final saved = await _storage.read(key: _hostKey);
    if (saved != null) return saved;
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    final hex = bytes.map((v) => v.toRadixString(16).padLeft(2, '0')).join();
    final id =
        'urn:uuid:${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
        '${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
    await _storage.write(key: _hostKey, value: id);
    return id;
  }

  String _randomUrlSafe(int length) {
    final random = Random.secure();
    return base64UrlEncode(
      List<int>.generate(length, (_) => random.nextInt(256)),
    ).replaceAll('=', '');
  }

  Set<String> _scopes(Object? raw) => (raw?.toString() ?? '')
      .split(RegExp(r'\s+'))
      .where((s) => s.isNotEmpty)
      .toSet();

  Future<void> _save(ChatGptCredentials credentials) => _storage.write(
    key: _credentialKey,
    value: jsonEncode(credentials.toJson()),
  );
}

class ChatGptCredentials {
  const ChatGptCredentials({
    required this.clientId,
    required this.subject,
    required this.email,
    required this.idToken,
    required this.accessToken,
    required this.refreshToken,
    required this.scopes,
    required this.expiresAt,
  });

  final String clientId;
  final String subject;
  final String email;
  final String idToken;
  final String accessToken;
  final String refreshToken;
  final Set<String> scopes;
  final DateTime expiresAt;

  bool get planEnabled =>
      scopes.contains('chatgpt.tokens.use.direct') &&
      scopes.contains('resource.invoke');

  ChatGptCredentials copyWith({
    String? accessToken,
    String? refreshToken,
    Set<String>? scopes,
    DateTime? expiresAt,
  }) => ChatGptCredentials(
    clientId: clientId,
    subject: subject,
    email: email,
    idToken: idToken,
    accessToken: accessToken ?? this.accessToken,
    refreshToken: refreshToken ?? this.refreshToken,
    scopes: scopes ?? this.scopes,
    expiresAt: expiresAt ?? this.expiresAt,
  );

  Map<String, dynamic> toJson() => {
    'client_id': clientId,
    'sub': subject,
    'email': email,
    'id_token': idToken,
    'access_token': accessToken,
    'refresh_token': refreshToken,
    'scopes': scopes.toList(),
    'expires_at': expiresAt.toIso8601String(),
  };

  factory ChatGptCredentials.fromJson(Map<String, dynamic> value) =>
      ChatGptCredentials(
        clientId: value['client_id'] as String,
        subject: value['sub'] as String,
        email: value['email'] as String,
        idToken: value['id_token'] as String,
        accessToken: value['access_token'] as String,
        refreshToken: value['refresh_token'] as String,
        scopes: (value['scopes'] as List<dynamic>).cast<String>().toSet(),
        expiresAt: DateTime.parse(value['expires_at'] as String),
      );
}
