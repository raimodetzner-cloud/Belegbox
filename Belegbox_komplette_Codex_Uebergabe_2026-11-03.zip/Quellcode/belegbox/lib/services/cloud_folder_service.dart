import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/receipt.dart';

/// The Android Storage Access Framework delegates authentication to Google
/// Drive or OneDrive's installed app. This is a provider-side copy: successful
/// writing to the provider does not guarantee upload to its remote servers.
class CloudFolderService {
  static const _channel = MethodChannel('de.dnh24.belegbox/files');

  Future<String?> chooseFolder() async {
    if (!Platform.isAndroid) throw UnsupportedError('Android erforderlich');
    return _channel.invokeMethod<String>('chooseFolder');
  }

  Future<String> copyPdf(String folderUri, SavedReceipt receipt) async {
    if (!Platform.isAndroid) throw UnsupportedError('Android erforderlich');
    final uri = await _channel.invokeMethod<String>('copyPdf', {
      'folderUri': folderUri,
      'filePath': receipt.localPath,
      'fileName': receipt.fileName,
      'year': receipt.invoiceDate.year.toString(),
      'month': receipt.invoiceDate.month.toString().padLeft(2, '0'),
    });
    if (uri == null || uri.isEmpty) {
      throw StateError('Der Cloud-Anbieter hat keine Datei bestätigt.');
    }
    return uri;
  }

  Future<void> openPdf(String filePath) async {
    if (!Platform.isAndroid) throw UnsupportedError('Android erforderlich');
    await _channel.invokeMethod<void>('openPdf', {'filePath': filePath});
  }

  Future<void> openCloudCopy(String documentUri) async {
    if (!Platform.isAndroid) throw UnsupportedError('Android erforderlich');
    await _channel.invokeMethod<void>('openCloudCopy', {
      'documentUri': documentUri,
    });
  }

  /// Let the user place a copy in a visible folder such as Documents.
  Future<bool> exportPdfAs(String filePath) async {
    if (!Platform.isAndroid) throw UnsupportedError('Android erforderlich');
    return await _channel.invokeMethod<bool>('exportPdfAs', {
          'filePath': filePath,
        }) ??
        false;
  }
}

class CloudSelection {
  const CloudSelection({
    this.target = 'synology',
    this.googleFolder,
    this.oneDriveFolder,
    this.deleteAfterNasVerification = false,
    this.rememberAiConsent = false,
  });

  final String target;
  final String? googleFolder;
  final String? oneDriveFolder;
  final bool deleteAfterNasVerification;
  final bool rememberAiConsent;

  String? folderFor(String provider) => switch (provider) {
    'google_drive' => googleFolder,
    'onedrive' => oneDriveFolder,
    _ => null,
  };

  CloudSelection copyWith({
    String? target,
    String? googleFolder,
    String? oneDriveFolder,
    bool? deleteAfterNasVerification,
    bool? rememberAiConsent,
  }) => CloudSelection(
    target: target ?? this.target,
    googleFolder: googleFolder ?? this.googleFolder,
    oneDriveFolder: oneDriveFolder ?? this.oneDriveFolder,
    deleteAfterNasVerification:
        deleteAfterNasVerification ?? this.deleteAfterNasVerification,
    rememberAiConsent: rememberAiConsent ?? this.rememberAiConsent,
  );
}

class CloudSelectionStore {
  const CloudSelectionStore();

  static const _store = FlutterSecureStorage();

  Future<CloudSelection> load() async => CloudSelection(
    target: await _store.read(key: 'cloud_selected_target_v1') ?? 'synology',
    googleFolder: await _store.read(key: 'cloud_google_folder_v1'),
    oneDriveFolder: await _store.read(key: 'cloud_onedrive_folder_v1'),
    deleteAfterNasVerification:
        await _store.read(key: 'cloud_delete_verified_v1') == 'true',
    rememberAiConsent:
        await _store.read(key: 'chatgpt_remember_image_consent_v1') == 'true',
  );

  Future<void> save(CloudSelection selection) async {
    await _store.write(
      key: 'cloud_selected_target_v1',
      value: selection.target,
    );
    if (selection.googleFolder != null) {
      await _store.write(
        key: 'cloud_google_folder_v1',
        value: selection.googleFolder,
      );
    }
    if (selection.oneDriveFolder != null) {
      await _store.write(
        key: 'cloud_onedrive_folder_v1',
        value: selection.oneDriveFolder,
      );
    }
    await _store.write(
      key: 'cloud_delete_verified_v1',
      value: selection.deleteAfterNasVerification.toString(),
    );
    await _store.write(
      key: 'chatgpt_remember_image_consent_v1',
      value: selection.rememberAiConsent.toString(),
    );
  }
}
