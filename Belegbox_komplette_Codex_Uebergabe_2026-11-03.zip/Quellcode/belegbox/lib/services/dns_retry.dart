import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;

/// Android can briefly lose a DNS answer after returning from the system
/// browser. Retry only hostname lookups: never automatically repeat HTTP
/// failures, rejected OAuth grants, TLS errors, or other socket failures.
Future<T> retryDnsLookup<T>(
  Future<T> Function() operation, {
  Future<void> Function(int completedAttempts, int totalAttempts)? onRetry,
  Future<void> Function(Duration delay)? wait,
}) async {
  const delays = <Duration>[
    Duration(milliseconds: 400),
    Duration(milliseconds: 900),
    Duration(milliseconds: 1800),
    Duration(milliseconds: 3000),
  ];
  for (var attempt = 0; ; attempt++) {
    try {
      return await operation();
    } catch (error) {
      if (!_isDnsLookupFailure(error) || attempt >= delays.length) rethrow;
      await onRetry?.call(attempt + 1, delays.length + 1);
      await (wait?.call(delays[attempt]) ??
          Future<void>.delayed(delays[attempt]));
    }
  }
}

bool _isDnsLookupFailure(Object error) {
  if (error is SocketException) {
    if (error.osError?.errorCode == 7) return true;
  }
  // package:http wraps SocketException into a ClientException on some targets.
  if (error is SocketException || error is http.ClientException) {
    final text = error.toString().toLowerCase();
    return text.contains('failed host lookup') ||
        text.contains('no address associated with hostname');
  }
  return false;
}
