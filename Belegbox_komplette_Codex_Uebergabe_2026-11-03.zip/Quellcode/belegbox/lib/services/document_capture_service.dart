import 'dart:io';

import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

/// Native Android scanner detects document edges and returns perspective-
/// corrected JPEG pages. PDF import rasterizes a chosen PDF into JPEG pages.
/// Both feed the same existing OCR, preview and final PDF pipeline.
class DocumentCaptureService {
  const DocumentCaptureService();

  static const _channel = MethodChannel('de.dnh24.belegbox/files');

  Future<List<XFile>> scanDocument() async {
    if (!Platform.isAndroid) {
      throw UnsupportedError('Der Dokumentenscanner benötigt Android.');
    }
    final paths = await _channel.invokeListMethod<String>('scanDocument');
    return (paths ?? []).map(XFile.new).toList(growable: false);
  }

  Future<List<XFile>> importPdf() async {
    if (!Platform.isAndroid) {
      throw UnsupportedError('Der PDF-Import benötigt Android.');
    }
    final paths = await _channel.invokeListMethod<String>('importReceiptPdf');
    return (paths ?? []).map(XFile.new).toList(growable: false);
  }
}
