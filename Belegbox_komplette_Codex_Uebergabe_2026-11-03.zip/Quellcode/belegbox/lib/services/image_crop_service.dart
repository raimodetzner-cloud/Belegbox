import 'dart:io';
import 'dart:math' as math;

import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;

/// Normalized rectangle: (0,0) is top left, (1,1) bottom right.
/// The original scanned image is never overwritten.
class ImageCropService {
  const ImageCropService();

  static img.Image crop(
    img.Image input, {
    required double left,
    required double top,
    required double right,
    required double bottom,
  }) {
    if (![left, top, right, bottom].every((value) => value.isFinite) ||
        left < 0 ||
        top < 0 ||
        right > 1 ||
        bottom > 1 ||
        right <= left ||
        bottom <= top) {
      throw const FormatException('Ungültiger Bildausschnitt.');
    }
    final upright = img.bakeOrientation(input);
    final x = (left * upright.width).floor().clamp(0, upright.width - 1);
    final y = (top * upright.height).floor().clamp(0, upright.height - 1);
    final xEnd = (right * upright.width).ceil().clamp(x + 1, upright.width);
    final yEnd = (bottom * upright.height).ceil().clamp(y + 1, upright.height);
    return img.copyCrop(
      upright,
      x: x,
      y: y,
      width: math.max(1, xEnd - x),
      height: math.max(1, yEnd - y),
    );
  }

  Future<String> saveCrop(
    String path, {
    required double left,
    required double top,
    required double right,
    required double bottom,
  }) async {
    final source = File(path);
    final decoded = img.decodeImage(await source.readAsBytes());
    if (decoded == null) {
      throw const FormatException(
        'Dieses Bild kann nicht zugeschnitten werden.',
      );
    }
    final result = crop(
      decoded,
      left: left,
      top: top,
      right: right,
      bottom: bottom,
    );
    final filename = 'Ausschnitt_${DateTime.now().microsecondsSinceEpoch}.jpg';
    final target = File(p.join(source.parent.path, filename));
    await target.writeAsBytes(img.encodeJpg(result, quality: 92), flush: true);
    return target.path;
  }
}
