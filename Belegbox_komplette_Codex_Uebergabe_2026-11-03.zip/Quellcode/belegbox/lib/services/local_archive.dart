import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

import '../models/receipt.dart';
import '../models/receipt_analysis.dart';
import 'receipt_paths.dart';

class LocalArchive {
  LocalArchive({Directory? documentsDirectory})
    : _documentsDirectory = documentsDirectory;

  final Directory? _documentsDirectory;

  Future<Directory> _folder() async {
    final root =
        _documentsDirectory ?? await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(root.path, 'Belegbox'));
    await folder.create(recursive: true);
    return folder;
  }

  Future<File> _indexFile() async =>
      File('${(await _folder()).path}/belege.json');

  Future<Directory> pdfDirectory() async =>
      Directory(p.join((await _folder()).path, ReceiptPaths.incomingFolder));

  Future<List<SavedReceipt>> list() async {
    final file = await _indexFile();
    if (!await file.exists()) return [];
    final raw = jsonDecode(await file.readAsString()) as List<dynamic>;
    return raw
        .map((e) => SavedReceipt.fromJson(e as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<void> _writeIndex(List<SavedReceipt> receipts) async {
    final file = await _indexFile();
    final staging = File('${file.path}.tmp');
    await staging.writeAsString(
      jsonEncode(receipts.map((e) => e.toJson()).toList()),
      flush: true,
    );
    await staging.rename(file.path);
  }

  Future<SavedReceipt> savePdf({
    required Uint8List pdfBytes,
    required String vendor,
    required DateTime date,
    required int totalCents,
    ReceiptAnalysis? analysis,
    String storageTarget = 'synology',
  }) async {
    final now = DateTime.now();
    final id = now.microsecondsSinceEpoch.toString();
    final root = await _folder();
    final target = Directory(
      p.join(
        root.path,
        ReceiptPaths.incomingFolder,
        ReceiptPaths.year(date),
        ReceiptPaths.month(date),
      ),
    );
    await target.create(recursive: true);
    final stem = ReceiptPaths.baseFileName(
      receiptDate: date,
      vendor: vendor,
      grossCents: totalCents,
      paymentMethod: analysis?.paymentMethod ?? PaymentMethod.unknown,
    );
    var counter = 1;
    var name = '$stem.pdf';
    // Niemals einen frueheren Beleg ueberschreiben.
    while (await File(p.join(target.path, name)).exists()) {
      counter++;
      name = '${stem}_$counter.pdf';
    }
    final filePath = p.join(target.path, name);
    await File(filePath).writeAsBytes(pdfBytes, flush: true);

    final receipt = SavedReceipt(
      id: id,
      fileName: name,
      localPath: filePath,
      vendor: vendor,
      invoiceDate: date,
      totalCents: totalCents,
      createdAt: now,
      uploaded: false,
      storageTarget: storageTarget,
      sha256Digest: sha256.convert(pdfBytes).toString(),
      analysis: analysis,
    );
    final all = await list();
    await _writeIndex([...all, receipt]);
    return receipt;
  }

  Future<void> markUploaded(
    String id, {
    bool deleteLocalAfterVerification = false,
    String? remoteUri,
  }) async {
    final all = await list();
    final matching = all.where((e) => e.id == id).toList();
    if (matching.length != 1)
      throw StateError('Beleg nicht eindeutig gefunden.');
    await _writeIndex(
      all.map((e) => e.id == id
          ? e.copyWith(uploaded: true, remoteUri: remoteUri)
          : e).toList(),
    );
    if (deleteLocalAfterVerification) {
      final file = File(matching.single.localPath);
      if (await file.exists()) await file.delete();
    }
  }

  Future<void> markCloudCopied(String id, String documentUri) async {
    final all = await list();
    if (!all.any((r) => r.id == id)) throw StateError('Beleg nicht gefunden.');
    await _writeIndex(
      all
          .map(
            (r) => r.id == id ? r.copyWith(cloudDocumentUri: documentUri) : r,
          )
          .toList(),
    );
  }

  /// Human-readable portable receipt index (without passwords, access
  /// tokens, absolute Android paths or stale Android cloud permissions).
  /// It contains only links/metadata, not the PDF bytes.
  Future<String> exportManifestJson() async {
    final receipts = await list();
    return const JsonEncoder.withIndent('  ').convert({
      'format': 'belegbox-belegliste-v1',
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'note': 'Nur Index. Lokale PDFs sind ausschließlich in der verschlüsselten .bbx-Sicherung enthalten.',
      'receipts': receipts.map((receipt) {
        final entry = receipt.toJson();
        entry['localPath'] = '';
        entry['cloudDocumentUri'] = null;
        // Item texts and notes belong only to the encrypted full backup.
        entry.remove('analysis');
        return entry;
      }).toList(),
    });
  }

  /// Reconnect NAS-only documents from a portable text index. Local-only
  /// documents cannot be reconstructed without a complete .bbx backup.
  Future<RestoreSummary> mergeFromManifestJson(String jsonText) async {
    if (jsonText.length > 8 * 1024 * 1024) {
      throw const FormatException('Belegliste ist zu groß.');
    }
    final decoded = jsonDecode(jsonText);
    if (decoded is! Map<String, dynamic> ||
        decoded['format'] != 'belegbox-belegliste-v1' ||
        decoded['receipts'] is! List) {
      throw const FormatException('Unbekanntes Beleglistenformat.');
    }
    final entries = decoded['receipts'] as List;
    if (entries.length > 50000) {
      throw const FormatException('Zu viele Belege in der Liste.');
    }
    // Reuse the same path validation and duplicate handling as full restore.
    // The temporary staging area is empty: only NAS-verified records with
    // remote status may be re-linked. Android content:// grants are excluded.
    final staging = await Directory.systemTemp.createTemp('belegbox_manifest_');
    try {
      final sanitized = entries.map((entry) {
        if (entry is! Map<String, dynamic>) {
          throw const FormatException('Beschädigter Belegeintrag.');
        }
        final record = Map<String, dynamic>.from(entry);
        record['localPath'] = '';
        record['cloudDocumentUri'] = null;
        if (!const ['synology', 'qnap'].contains(record['storageTarget'])) {
          record['uploaded'] = false;
        }
        return record;
      }).toList();
      await File(p.join(staging.path, 'belege.json'))
          .writeAsString(jsonEncode(sanitized), flush: true);
      return await mergeFromBackup(staging);
    } finally {
      if (await staging.exists()) await staging.delete(recursive: true);
    }
  }

  /// Remove one indexed receipt. Never trust an imported absolute path for
  /// deletion: only a file inside our own archive may be removed.
  Future<void> deleteReceipt(String id) async {
    final receipts = await list();
    final matches = receipts.where((r) => r.id == id).toList();
    if (matches.length != 1) {
      throw StateError('Der Beleg wurde nicht eindeutig gefunden.');
    }
    final receipt = matches.single;
    final root = await _folder();
    final base = p.canonicalize(
      p.join(root.absolute.path, ReceiptPaths.incomingFolder),
    );
    final target = p.canonicalize(p.absolute(receipt.localPath));
    if (!p.isWithin(base, target) || !target.toLowerCase().endsWith('.pdf')) {
      throw StateError('Ungültiger lokaler Belegpfad. Nichts gelöscht.');
    }
    final file = File(target);
    if (await file.exists()) await file.delete();
    await _writeIndex(receipts.where((r) => r.id != id).toList());
  }

  /// After remote deletion the archive must not claim there is a NAS copy.
  Future<void> markRemoteDeleted(String id) async {
    final receipts = await list();
    if (!receipts.any((r) => r.id == id)) {
      throw StateError('Beleg nicht gefunden.');
    }
    await _writeIndex(receipts.map((r) => r.id == id
      ? SavedReceipt(
          id: r.id,
          fileName: r.fileName,
          localPath: r.localPath,
          vendor: r.vendor,
          invoiceDate: r.invoiceDate,
          totalCents: r.totalCents,
          createdAt: r.createdAt,
          uploaded: false,
          storageTarget: r.storageTarget,
          cloudDocumentUri: null,
          sha256Digest: r.sha256Digest,
          remoteUri: null,
          analysis: r.analysis,
        ) : r).toList());
  }

  /// Merge a fully decrypted and validated backup. Existing PDFs and metadata
  /// are never overwritten; previous absolute Android paths are ignored.
  Future<RestoreSummary> mergeFromBackup(Directory filesRoot) async {
    final file = File(p.join(filesRoot.path, 'belege.json'));
    if (!await file.exists()) throw StateError('Belegliste fehlt im Archiv.');
    final json = jsonDecode(await file.readAsString());
    if (json is! List) throw StateError('Ungültige Belegliste.');
    final originals = json
        .map((entry) => SavedReceipt.fromJson(entry as Map<String, dynamic>))
        .toList();
    final root = await _folder();
    final existing = await list();
    final knownIds = existing.map((r) => r.id).toSet();
    final added = <SavedReceipt>[];
    var skipped = 0;
    var cloudOnly = 0;

    for (final old in originals) {
      if (old.fileName.isEmpty ||
          old.fileName != p.basename(old.fileName) ||
          old.fileName.contains('\\') ||
          !old.fileName.toLowerCase().endsWith('.pdf')) {
        skipped++;
        continue;
      }
      final relative = p.join(
        ReceiptPaths.incomingFolder,
        ReceiptPaths.year(old.invoiceDate),
        ReceiptPaths.month(old.invoiceDate),
        old.fileName,
      );
      final source = File(p.join(filesRoot.path, relative));
      final hadPdf = await source.exists();
      if (knownIds.contains(old.id)) {
        final previous = existing.firstWhere((r) => r.id == old.id);
        if (hadPdf && !await File(previous.localPath).exists()) {
          await File(previous.localPath).parent.create(recursive: true);
          await source.copy(previous.localPath);
        }
        skipped++;
        continue;
      }
      if (!hadPdf && !old.uploaded) {
        // An old Android cloud URI alone is not usable after reinstall.
        skipped++;
        continue;
      }
      var name = old.fileName;
      var target = File(p.join(root.path, p.dirname(relative), name));
      await target.parent.create(recursive: true);
      if (hadPdf && await target.exists()) {
        final sourceBytes = await source.readAsBytes();
        final targetBytes = await target.readAsBytes();
        if (!_sameBytes(sourceBytes, targetBytes)) {
          var index = 1;
          do {
            name =
                '${p.basenameWithoutExtension(old.fileName)}_wiederhergestellt_$index.pdf';
            target = File(p.join(root.path, p.dirname(relative), name));
            index++;
          } while (await target.exists());
        }
      }
      if (hadPdf && !await target.exists()) await source.copy(target.path);
      if (!hadPdf) cloudOnly++;
      added.add(
        SavedReceipt(
          id: old.id,
          fileName: name,
          localPath: target.path,
          vendor: old.vendor,
          invoiceDate: old.invoiceDate,
          totalCents: old.totalCents,
          createdAt: old.createdAt,
          uploaded: old.uploaded,
          storageTarget: old.storageTarget,
          cloudDocumentUri: null,
          sha256Digest: old.sha256Digest,
          remoteUri: old.remoteUri,
          analysis: old.analysis,
        ),
      );
      knownIds.add(old.id);
    }
    await _writeIndex([...existing, ...added]);
    return RestoreSummary(
      imported: added.length,
      alreadyPresentOrSkipped: skipped,
      synologyOnly: cloudOnly,
    );
  }

  bool _sameBytes(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }
}

class RestoreSummary {
  const RestoreSummary({
    required this.imported,
    required this.alreadyPresentOrSkipped,
    required this.synologyOnly,
  });

  final int imported;
  final int alreadyPresentOrSkipped;
  final int synologyOnly;
}
