import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/receipt_analysis.dart';

class PdfService {
  Future<Uint8List> create({
    required List<XFile> photos,
    required String vendor,
    ReceiptAnalysis? analysis,
  }) async {
    if (photos.isEmpty)
      throw StateError('Bitte zuerst einen Beleg fotografieren.');
    final document = pw.Document(title: 'Beleg $vendor', author: 'Belegbox');
    final fontData = await rootBundle.load('assets/fonts/DejaVuSans.ttf');
    final textFont = pw.Font.ttf(fontData);
    for (final photo in photos) {
      final original = await File(photo.path).readAsBytes();
      final decoded = img.decodeImage(original);
      if (decoded == null) {
        throw FormatException(
          'Das Bildformat wird nicht unterstützt. Bitte JPG oder PNG verwenden.',
        );
      }
      final upright = img.bakeOrientation(decoded);
      final longest = upright.width > upright.height
          ? upright.width
          : upright.height;
      final resized = longest > 2200
          ? img.copyResize(
              upright,
              width: (upright.width * 2200 / longest).round(),
              height: (upright.height * 2200 / longest).round(),
            )
          : upright;
      final jpeg = Uint8List.fromList(img.encodeJpg(resized, quality: 86));
      document.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(16),
          build: (context) => pw.Center(
            child: pw.Image(pw.MemoryImage(jpeg), fit: pw.BoxFit.contain),
          ),
        ),
      );
    }
    if (analysis != null) {
      final result = analysis;
      String show(int? cents) => cents == null
          ? 'nicht erkannt'
          : '${cents ~/ 100},${(cents % 100).toString().padLeft(2, '0')} EUR';
      document.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          theme: pw.ThemeData.withFont(base: textFont, bold: textFont),
          build: (context) => [
            pw.Header(level: 1, text: 'Belegbox - KI-Auswertung'),
            pw.Text('Bitte alle Angaben anhand des Originalbelegs pruefen.'),
            pw.SizedBox(height: 14),
            pw.Text('Firma: ${result.vendor}'),
            pw.Text(
              'Belegdatum: ${result.invoiceDate?.toIso8601String().substring(0, 10) ?? "nicht erkannt"}',
            ),
            pw.Text('Bruttobetrag: ${show(result.grossCents)}'),
            pw.Text('Nettobetrag: ${show(result.netCents)}'),
            pw.Text('Mehrwertsteuer: ${show(result.vatCents)}'),
            pw.Text('Belegnummer: ${result.invoiceNumber ?? "nicht erkannt"}'),
            pw.Text('Zahlungsart: ${result.paymentMethod.label}'),
            pw.Text(
              'Buchungskategorie: ${result.paymentMethod.bookingAccount}',
            ),
            if (result.lineItems.isNotEmpty) ...[
              pw.SizedBox(height: 18),
              pw.Header(level: 2, text: 'Erkannte Artikel / Positionen'),
              ...result.lineItems.map(
                (item) => pw.Text(
                  '${item.description}   ${item.quantity ?? ""}   ${show(item.grossCents)}',
                ),
              ),
            ],
            if (result.note != null) ...[
              pw.SizedBox(height: 12),
              pw.Text('Hinweis: ${result.note}'),
            ],
          ],
        ),
      );
    }
    return document.save();
  }
}
