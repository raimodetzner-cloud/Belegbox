import '../models/receipt.dart';
import '../models/receipt_analysis.dart';

class ReceiptParser {
  static final _datePattern = RegExp(
    r'(?<!\d)(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2}|\d{4})(?!\d)',
  );
  static final _isoDatePattern = RegExp(
    r'(?<!\d)(20\d{2})-(\d{2})-(\d{2})(?!\d)',
  );
  static final _amountPattern = RegExp(
    r'(?<!\d)(\d{1,3}(?:[. ]\d{3})*|\d+)[,.](\d{2})(?!\d)',
  );
  static const _knownVendors = <String, String>{
    'HORNBACH': 'HORNBACH',
    'OBI': 'OBI',
    'BAUHAUS': 'BAUHAUS',
    'TOOM': 'toom',
    'HAGEBAU': 'hagebau',
    'LIDL': 'Lidl',
    'ALDI': 'ALDI',
    'REWE': 'REWE',
    'EDEKA': 'EDEKA',
    'KAUFLAND': 'Kaufland',
    'NETTO': 'Netto',
    'PENNY': 'PENNY',
    'ROSSMANN': 'ROSSMANN',
    'MEDIAMARKT': 'MediaMarkt',
    'SATURN': 'SATURN',
    'WÜRTH': 'Würth',
    'WUERTH': 'Würth',
    'OBETA': 'OBETA',
    'IKEA': 'IKEA',
    'AMAZON': 'Amazon',
  };

  static ReceiptDraft parse(String text) {
    final lines = text
        .split(RegExp(r'[\r\n]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    return ReceiptDraft(
      vendor: _findVendor(lines),
      date: _findDate(lines),
      totalCents: _findTotal(lines),
      paymentMethod: _findPaymentMethod(lines),
    );
  }

  static PaymentMethod _findPaymentMethod(List<String> lines) {
    final tail = lines.skip(lines.length > 18 ? lines.length - 18 : 0);
    for (final line in tail.toList().reversed) {
      final text = line.toUpperCase();
      if (RegExp(r'\bGIROCARD\b|\bEC[- ]?KARTE\b|\bMAESTRO\b').hasMatch(text)) {
        return PaymentMethod.girocard;
      }
      if (RegExp(r'\bKREDITKARTE\b|\bMASTERCARD\b|\bAMEX\b').hasMatch(text)) {
        return PaymentMethod.creditCard;
      }
      if (RegExp(r'\bDEBITKARTE\b|\bVISA DEBIT\b').hasMatch(text)) {
        return PaymentMethod.debitCard;
      }
      if (RegExp(r'\bPAYPAL\b').hasMatch(text)) return PaymentMethod.paypal;
      if (RegExp(r'\bÜBERWEISUNG\b|\bUEBERWEISUNG\b').hasMatch(text)) {
        return PaymentMethod.transfer;
      }
      if (RegExp(
        r'\bBARZAHLUNG\b|\bBARGELD\b|\bBAR BEZAHLT\b',
      ).hasMatch(text)) {
        return PaymentMethod.cash;
      }
      if (RegExp(
        r'^(?:ZAHLUNGSART:?)?\s*BAR\s*(?:[\d,.€ ]+)?$',
      ).hasMatch(text)) {
        return PaymentMethod.cash;
      }
    }
    return PaymentMethod.unknown;
  }

  static String _findVendor(List<String> lines) {
    for (final line in lines.take(14)) {
      final upper = line.toUpperCase();
      for (final vendor in _knownVendors.entries) {
        if (RegExp(
          '(^|[^A-ZÄÖÜ])${RegExp.escape(vendor.key)}([^A-ZÄÖÜ]|\$)',
        ).hasMatch(upper)) {
          return vendor.value;
        }
      }
    }
    for (final line in lines.take(7)) {
      if (line.length < 4 || line.length > 65) continue;
      if (RegExp(r'\d').allMatches(line).length > 2) continue;
      if (RegExp(
        r'^(RECHNUNG|KASSENBON|BON |BELEG|TEL\.?|WWW\.|HTTP|UST|STEUER|DATUM|FILIALE|STRA[Sß]E|PLZ)',
        caseSensitive: false,
      ).hasMatch(line))
        continue;
      if (!RegExp(r'[A-Za-zÄÖÜäöüß]{3}').hasMatch(line)) continue;
      return line;
    }
    return '';
  }

  static DateTime? _findDate(List<String> lines) {
    final ordered = [
      ...lines.where(
        (l) => RegExp(
          r'RECHNUNGSDATUM|BELEGDATUM|DATUM|BON-DATUM',
          caseSensitive: false,
        ).hasMatch(l),
      ),
      ...lines,
    ];
    for (final line in ordered) {
      final iso = _isoDatePattern.firstMatch(line);
      if (iso != null) {
        final date = parseDate('${iso[3]}.${iso[2]}.${iso[1]}');
        if (date != null) return date;
      }
      for (final m in _datePattern.allMatches(line)) {
        final date = parseDate('${m[1]}.${m[2]}.${m[3]}');
        if (date != null) return date;
      }
    }
    return null;
  }

  static DateTime? parseDate(String raw) {
    final m = RegExp(
      r'^\s*(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2}|\d{4})\s*$',
    ).firstMatch(raw);
    if (m == null) return null;
    final day = int.parse(m[1]!);
    final month = int.parse(m[2]!);
    var year = int.parse(m[3]!);
    if (year < 100) year += 2000;
    if (year < 2000 || year > DateTime.now().year + 1) return null;
    final date = DateTime(year, month, day);
    return (date.year == year && date.month == month && date.day == day)
        ? date
        : null;
  }

  static int? parseEuro(String raw) {
    var text = raw.trim().replaceAll('€', '').replaceAll(RegExp(r'\s+'), '');
    if (text.isEmpty || text.startsWith('-')) return null;
    if (!RegExp(r'^\d+(?:[.,]\d+)*$').hasMatch(text)) return null;
    final comma = text.lastIndexOf(',');
    final dot = text.lastIndexOf('.');
    final decimalSeparator = comma > dot ? comma : dot;
    if (decimalSeparator < 0) {
      return int.tryParse(text) == null ? null : int.parse(text) * 100;
    }
    final decimal = text.substring(decimalSeparator + 1);
    if (decimal.length != 2 && decimal.length != 1) return null;
    final integerPart = text.substring(0, decimalSeparator);
    if (!RegExp(r'^\d+$|^\d{1,3}(?:[.,]\d{3})+$').hasMatch(integerPart))
      return null;
    text = integerPart.replaceAll(RegExp(r'[.,]'), '');
    final euros = int.tryParse(text);
    if (euros == null) return null;
    return euros * 100 + int.parse(decimal) * (decimal.length == 1 ? 10 : 1);
  }

  static int? _findTotal(List<String> lines) {
    int? result;
    var bestScore = -999.0;
    for (var i = 0; i < lines.length; i++) {
      final upper = lines[i].toUpperCase();
      if (RegExp(
        r'RÜCKGELD|WECHSELGELD|GEGEBEN|MWST|MEHRWERT|STEUER|NETTOBETRAG|ZWISCHENSUMME|UST|SKONTO|SPARBETRAG',
      ).hasMatch(upper))
        continue;
      final matches = _amountPattern.allMatches(lines[i]).toList();
      if (matches.isEmpty) continue;
      final amount = parseEuro(matches.last.group(0)!);
      if (amount == null) continue;
      var score = i * 0.01;
      if (RegExp(
        r'GESAMT|ENDSUMME|RECHNUNGSBETRAG|ZAHLBETRAG|ZU ZAHLEN|SUMME|TOTAL|BRUTTO',
      ).hasMatch(upper))
        score += 100;
      if (RegExp(r'BETRAG|EUR|€').hasMatch(upper)) score += 30;
      if (RegExp(r'BAR|KARTE|EC|VISA|MASTERCARD').hasMatch(upper)) score += 10;
      if (score > bestScore) {
        bestScore = score;
        result = amount;
      }
    }
    return result;
  }
}
