import 'package:intl/intl.dart';

import '../models/receipt_analysis.dart';

/// Eine Ablagestruktur fuer lokales Archiv und Synology:
/// PDF-Eingang/JJJJ/MM/JJJJ-MM-TT_Firma_12,34_B.pdf
class ReceiptPaths {
  static const incomingFolder = 'PDF-Eingang';

  static String year(DateTime receiptDate) =>
      DateFormat('yyyy').format(receiptDate);

  static String month(DateTime receiptDate) =>
      DateFormat('MM').format(receiptDate);

  static String accountLetter(PaymentMethod paymentMethod) =>
      switch (paymentMethod.bookingAccount) {
        'Kasse' => 'K',
        'Bank' => 'B',
        _ => 'U',
      };

  static String baseFileName({
    required DateTime receiptDate,
    required String vendor,
    required int grossCents,
    required PaymentMethod paymentMethod,
  }) {
    final normalized = vendor.trim().replaceAll(
      RegExp(r'[^A-Za-z0-9ÄÖÜäöüß_-]+'),
      '_',
    );
    final cleaned = normalized.replaceAll(RegExp(r'^_+|_+$'), '');
    final company = cleaned.isEmpty
        ? 'Unbekannte_Firma'
        : (cleaned.length > 48 ? cleaned.substring(0, 48) : cleaned);
    final euro =
        '${grossCents ~/ 100},${(grossCents % 100).toString().padLeft(2, '0')}';
    final date = DateFormat('yyyy-MM-dd').format(receiptDate);
    return '${date}_${company}_${euro}_${accountLetter(paymentMethod)}';
  }
}
