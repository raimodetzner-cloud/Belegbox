import 'dart:convert';
import 'dart:io';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

class ScanService {
  Future<String> recognize(List<XFile> photos) async {
    if (Platform.isWindows) return _recognizeWindows(photos);
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final pages = <String>[];
      for (final photo in photos) {
        final input = InputImage.fromFilePath(photo.path);
        final result = await recognizer.processImage(input);
        pages.add(result.text);
      }
      return pages.join('\n');
    } finally {
      await recognizer.close();
    }
  }

  Future<String> _recognizeWindows(List<XFile> photos) async {
    final possiblePaths = <String>[
      r'C:\Program Files\Tesseract-OCR\tesseract.exe',
      r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
      'tesseract',
    ];
    String? executable;
    for (final path in possiblePaths) {
      if (path == 'tesseract' || File(path).existsSync()) {
        executable = path;
        if (path != 'tesseract') break;
      }
    }
    if (executable == null)
      throw StateError('Tesseract OCR fehlt auf Windows.');
    final pages = <String>[];
    for (final photo in photos) {
      ProcessResult result;
      try {
        result = await Process.run(
          executable,
          [photo.path, 'stdout', '-l', 'deu+eng'],
          stdoutEncoding: utf8,
          stderrEncoding: utf8,
        );
      } on ProcessException {
        throw StateError(
          'Tesseract OCR nicht gefunden. Bitte auf dem Windows-PC installieren.',
        );
      }
      if (result.exitCode != 0) {
        // Manche Installationen enthalten anfangs nur das englische Sprachpaket.
        result = await Process.run(
          executable,
          [photo.path, 'stdout', '-l', 'eng'],
          stdoutEncoding: utf8,
          stderrEncoding: utf8,
        );
      }
      if (result.exitCode != 0) {
        throw StateError('Texterkennung fehlgeschlagen: ${result.stderr}');
      }
      pages.add(result.stdout as String);
    }
    return pages.join('\n');
  }
}
