import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../models/receipt.dart';
import 'receipt_paths.dart';

class SynologySettings {
  const SynologySettings({
    required this.url,
    required this.sharedFolder,
    required this.user,
    required this.password,
    this.providerName = 'Synology',
  });

  final String url;
  final String sharedFolder;
  final String user;
  final String password;
  final String providerName;

  bool get isComplete =>
      url.isNotEmpty &&
      sharedFolder.isNotEmpty &&
      user.isNotEmpty &&
      password.isNotEmpty;

  Uri get baseUri {
    final uri = Uri.tryParse(url.trim());
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.isEmpty ||
        uri.hasQuery ||
        uri.hasFragment ||
        uri.userInfo.isNotEmpty ||
        uri.pathSegments.any(
          (part) =>
              part == '.' ||
              part == '..' ||
              part.contains('\\') ||
              part.contains('/'),
        )) {
      throw const FormatException(
        'Bitte die direkte WebDAV-HTTPS-Adresse eingeben, z. B. '
        'https://nas.example:5006 oder https://nas.example/webdav.',
      );
    }
    return uri;
  }

  /// Der erste Teil ist der vom NAS freigegebene Hauptordner. Weitere Teile
  /// sind bereits vorhandene Unterordner, z. B. `Firma/Belege/Eingang`.
  List<String> get folderSegments {
    final value = sharedFolder.trim().replaceAll(RegExp(r'^/+|/+$'), '');
    final parts = value.split('/');
    if (value.isEmpty ||
        parts.any(
          (part) =>
              part.isEmpty ||
              part.trim() != part ||
              part == '.' ||
              part == '..' ||
              part.contains('\\') ||
              part.contains(RegExp(r'[\x00-\x1f]')),
        )) {
      throw const FormatException(
        'Bitte einen gültigen NAS-Freigabepfad eingeben, z. B. '
        'Daten/Belege/Eingang. Keine Punkte als Pfadteile verwenden.',
      );
    }
    return parts;
  }

  String get cleanFolder {
    return folderSegments.join('/');
  }

  List<String> get _baseSegments => baseUri.pathSegments
      .where((part) => part.isNotEmpty)
      .toList(growable: false);

  Uri _uriForSegments(List<String> segments) =>
      baseUri.replace(pathSegments: [..._baseSegments, ...segments]);

  /// Every level of the pre-existing NAS share has to be accessible.
  /// Unlike the year and month folders, none of these levels are created.
  Iterable<Uri> get configuredFolderUris sync* {
    final parts = folderSegments;
    for (var index = 1; index <= parts.length; index++) {
      yield _uriForSegments([...parts.take(index), '']);
    }
  }

  Uri collectionUri() => _uriForSegments([...folderSegments, '']);

  Uri yearUri(DateTime date) =>
      _uriForSegments([...folderSegments, ReceiptPaths.year(date), '']);

  Uri monthUri(DateTime date) => _uriForSegments([
    ...folderSegments,
    ReceiptPaths.year(date),
    ReceiptPaths.month(date),
    '',
  ]);

  Uri documentUri(String filename, {required DateTime date}) {
    if (filename.isEmpty || filename.contains('/') || filename.contains('\\')) {
      throw const FormatException('Ungültiger Dateiname.');
    }
    return _uriForSegments([
      ...folderSegments,
      ReceiptPaths.year(date),
      ReceiptPaths.month(date),
      filename,
    ]);
  }
}

class SettingsStore {
  static const _secure = FlutterSecureStorage();

  Future<SynologySettings> load() async => SynologySettings(
    url: await _secure.read(key: 'nas_url') ?? '',
    sharedFolder: await _secure.read(key: 'nas_folder') ?? 'PDF-Eingang',
    user: await _secure.read(key: 'nas_user') ?? '',
    password: await _secure.read(key: 'nas_password') ?? '',
  );

  Future<void> save(SynologySettings config) async {
    config.baseUri;
    config.cleanFolder;
    await _secure.write(key: 'nas_url', value: config.url.trim());
    await _secure.write(key: 'nas_folder', value: config.sharedFolder.trim());
    await _secure.write(key: 'nas_user', value: config.user.trim());
    await _secure.write(key: 'nas_password', value: config.password);
  }
}

/// QNAP uses the same WebDAV protocol but its credentials and settings must
/// never overwrite the user's existing Synology connection.
class QnapSettingsStore {
  static const _secure = FlutterSecureStorage();

  Future<SynologySettings> load() async => SynologySettings(
    url: await _secure.read(key: 'qnap_url') ?? '',
    sharedFolder: await _secure.read(key: 'qnap_folder') ?? 'PDF-Eingang',
    user: await _secure.read(key: 'qnap_user') ?? '',
    password: await _secure.read(key: 'qnap_password') ?? '',
    providerName: 'QNAP',
  );

  Future<void> save(SynologySettings config) async {
    config.baseUri;
    config.cleanFolder;
    await _secure.write(key: 'qnap_url', value: config.url.trim());
    await _secure.write(key: 'qnap_folder', value: config.sharedFolder.trim());
    await _secure.write(key: 'qnap_user', value: config.user.trim());
    await _secure.write(key: 'qnap_password', value: config.password);
  }
}

class SynologyService {
  SynologyService({http.Client? client}) : _client = client;

  final http.Client? _client;

  Map<String, String> _headers(SynologySettings settings) => {
    'Authorization':
        'Basic ${base64Encode(utf8.encode('${settings.user}:${settings.password}'))}',
  };

  Future<void> testConnection(SynologySettings settings) async {
    final client = _client ?? http.Client();
    try {
      await _checkConfiguredFolders(client, settings);
    } finally {
      if (_client == null) client.close();
    }
  }

  Future<void> _checkConfiguredFolders(
    http.Client client,
    SynologySettings settings,
  ) async {
    for (final folder in settings.configuredFolderUris) {
      await _ensureCollection(client, settings, folder, canCreate: false);
    }
  }

  Future<void> upload(SynologySettings settings, SavedReceipt receipt) async {
    final file = File(receipt.localPath);
    if (!await file.exists()) throw StateError('Lokale PDF-Datei fehlt.');
    final client = _client ?? http.Client();
    try {
      await _checkConfiguredFolders(client, settings);
      await _ensureCollection(
        client,
        settings,
        settings.yearUri(receipt.invoiceDate),
      );
      await _ensureCollection(
        client,
        settings,
        settings.monthUri(receipt.invoiceDate),
      );
      final request = http.Request(
        'PUT',
        settings.documentUri(receipt.fileName, date: receipt.invoiceDate),
      );
      request.headers.addAll(_headers(settings));
      request.followRedirects = false;
      request.headers['Content-Type'] = 'application/pdf';
      request.headers['If-None-Match'] =
          '*'; // Bestehende Dateien niemals überschreiben.
      request.bodyBytes = await file.readAsBytes();
      final response = await client
          .send(request)
          .timeout(const Duration(seconds: 60));
      await response.stream.drain<void>();
      if (response.statusCode == 412) {
        throw const RemoteDocumentExistsException();
      }
      if (response.statusCode != 201 &&
          response.statusCode != 204 &&
          response.statusCode != 200) {
        throw StateError(_friendlyStatus(response.statusCode, settings));
      }
    } finally {
      if (_client == null) client.close();
    }
  }

  /// Store the PDF, then GET it from the NAS and compare both byte length and
  /// SHA-256 with the original file. Only after this returns may a caller
  /// remove its local copy. A pre-existing file is accepted only if identical.
  Future<void> uploadAndVerify(
    SynologySettings settings,
    SavedReceipt receipt,
  ) async {
    try {
      await upload(settings, receipt);
    } on RemoteDocumentExistsException {
      // A previous upload may have succeeded but its confirmation was lost.
      // Never overwrite the existing document; compare it instead.
    }
    await verifyRemoteCopy(settings, receipt);
  }

  Future<void> verifyRemoteCopy(
    SynologySettings settings,
    SavedReceipt receipt,
  ) async {
    final source = File(receipt.localPath);
    if (!await source.exists()) {
      throw StateError(
        'Lokale PDF fehlt. Die Cloud-Kopie kann nicht geprüft werden.',
      );
    }
    final local = await source.readAsBytes();
    final client = _client ?? http.Client();
    try {
      final request = http.Request(
        'GET',
        settings.documentUri(receipt.fileName, date: receipt.invoiceDate),
      );
      request.headers.addAll(_headers(settings));
      request.followRedirects = false;
      request.headers['Cache-Control'] = 'no-cache';
      final response = await client
          .send(request)
          .timeout(const Duration(seconds: 60));
      if (response.statusCode != 200) {
        await response.stream.drain<void>();
        throw StateError(
          'Die ${settings.providerName}-Kopie konnte nicht kontrolliert werden '
          '(HTTP ${response.statusCode}). Lokale PDF bleibt erhalten.',
        );
      }
      // Limit remote data to one byte more than the source. A broken server
      // must not be allowed to exhaust the phone's memory on a GET.
      final received = <int>[];
      await for (final part in response.stream) {
        received.addAll(part);
        if (received.length > local.length) {
          throw StateError(
            'Die ${settings.providerName}-Datei hat eine andere Länge. Lokal bleibt erhalten.',
          );
        }
      }
      if (received.length != local.length ||
          sha256.convert(received) != sha256.convert(local)) {
        throw StateError(
          'Die ${settings.providerName}-Datei stimmt nicht mit dem PDF auf dem Handy überein. '
          'Lokal bleibt erhalten.',
        );
      }
    } finally {
      if (_client == null) client.close();
    }
  }

  /// Delete exactly one recorded WebDAV PDF. An existing local PDF or a
  /// recorded digest must match the NAS copy first. Remote failure never
  /// triggers removal from the local index.
  Future<void> deleteRemoteCopy(
    SynologySettings settings,
    SavedReceipt receipt,
  ) async {
    if (!receipt.uploaded) {
      throw StateError('Keine bestätigte NAS-Kopie vorhanden.');
    }
    final remoteUri = settings.documentUri(
      receipt.fileName, date: receipt.invoiceDate,
    );
    if (receipt.remoteUri != null && receipt.remoteUri != remoteUri.toString()) {
      throw StateError('Der NAS-Speicherort wurde seit dem Upload geändert. '
          'Bitte die ursprüngliche WebDAV-Verbindung wiederherstellen. Nicht gelöscht.');
    }
    final client = _client ?? http.Client();
    try {
      final get = http.Request('GET', remoteUri)
        ..headers.addAll(_headers(settings));
      get.followRedirects = false;
      get.headers['Cache-Control'] = 'no-cache';
      final check = await client.send(get).timeout(const Duration(seconds: 60));
      if (check.statusCode == 404) {
        await check.stream.drain<void>();
        // Already absent, so it is safe to forget this remote reference.
        return;
      }
      if (check.statusCode != 200) {
        await check.stream.drain<void>();
        throw StateError('NAS-Datei konnte nicht geprüft werden: HTTP ${check.statusCode}.');
      }
      final etag = check.headers['etag'];
      final remoteBytes = <int>[];
      await for (final chunk in check.stream) {
        remoteBytes.addAll(chunk);
        if (remoteBytes.length > 150 * 1024 * 1024) {
          throw StateError('NAS-Datei ist für die sichere Löschprüfung zu groß. Nicht gelöscht.');
        }
      }
      if (remoteBytes.length < 4 ||
          utf8.decode(remoteBytes.take(4).toList(), allowMalformed: true) != '%PDF') {
        throw StateError('Auf der NAS liegt keine gültige PDF. Nicht gelöscht.');
      }
      final hash = sha256.convert(remoteBytes).toString();
      final local = File(receipt.localPath);
      if (await local.exists()) {
        if (hash != sha256.convert(await local.readAsBytes()).toString()) {
          throw StateError('NAS- und lokale PDF unterscheiden sich. Nicht gelöscht.');
        }
      } else if (receipt.sha256Digest != null && receipt.sha256Digest != hash) {
        throw StateError('NAS-Datei entspricht nicht dem ursprünglichen Beleg. Nicht gelöscht.');
      }
      final request = http.Request('DELETE', remoteUri)
        ..headers.addAll(_headers(settings));
      request.followRedirects = false;
      if (etag != null && etag.isNotEmpty) request.headers['If-Match'] = etag;
      final response = await client.send(request).timeout(const Duration(seconds: 60));
      await response.stream.drain<void>();
      if (![200, 202, 204, 404].contains(response.statusCode)) {
        throw StateError('NAS konnte die PDF nicht löschen (HTTP ${response.statusCode}).');
      }
      // Verify that the targeted file is no longer readable. Never delete
      // local data if the server has not confirmed remote disappearance.
      final verify = http.Request('GET', remoteUri)
        ..headers.addAll(_headers(settings));
      verify.followRedirects = false;
      verify.headers['Cache-Control'] = 'no-cache';
      final gone = await client.send(verify).timeout(const Duration(seconds: 60));
      await gone.stream.drain<void>();
      if (gone.statusCode != 404) {
        throw StateError('Löschung auf der NAS nicht bestätigt (HTTP ${gone.statusCode}).');
      }
    } finally {
      if (_client == null) client.close();
    }
  }

  Future<File> downloadToCache(
    SynologySettings settings,
    SavedReceipt receipt,
  ) async {
    final expectedUri = settings.documentUri(
      receipt.fileName, date: receipt.invoiceDate,
    );
    if (receipt.remoteUri != null && receipt.remoteUri != expectedUri.toString()) {
      throw StateError('Der ursprüngliche NAS-Speicherort stimmt nicht mit den '
          'aktuellen Einstellungen überein. Bitte NAS-Verbindung korrigieren.');
    }
    final client = _client ?? http.Client();
    try {
      final response = await client
          .get(
            expectedUri,
            headers: _headers(settings),
          )
          .timeout(const Duration(seconds: 60));
      if (response.statusCode != 200) {
        throw StateError('PDF nicht abrufbar (HTTP ${response.statusCode}).');
      }
      if (receipt.sha256Digest != null &&
          sha256.convert(response.bodyBytes).toString() != receipt.sha256Digest) {
        throw StateError('Die NAS-Datei stimmt nicht mehr mit dem Originalbeleg überein.');
      }
      final cache = await Directory.systemTemp.createTemp('belegbox_preview_');
      final target = File('${cache.path}/${receipt.fileName}');
      await target.writeAsBytes(response.bodyBytes, flush: true);
      return target;
    } finally {
      if (_client == null) client.close();
    }
  }

  Future<void> _ensureCollection(
    http.Client client,
    SynologySettings settings,
    Uri uri, {
    bool canCreate = true,
  }) async {
    final probe = http.Request('PROPFIND', uri);
    probe.headers.addAll(_headers(settings));
    probe.followRedirects = false;
    probe.headers['Depth'] = '0';
    final existing = await client
        .send(probe)
        .timeout(const Duration(seconds: 25));
    await existing.stream.drain<void>();
    // WebDAV PROPFIND uses HTTP 207. A 200 frequently indicates an HTML
    // login page or a wrongly configured reverse-proxy route.
    if (existing.statusCode == 207) return;
    if (existing.statusCode != 404) {
      throw StateError(_friendlyStatus(existing.statusCode, settings));
    }
    if (!canCreate) {
      throw StateError(
        'Der NAS-WebDAV-Ordner "${uri.path}" ist nicht erreichbar '
        '(HTTP 404). Bitte den Freigabenamen und jeden vorhandenen '
        'Unterordner auf ${settings.providerName} prüfen. '
        'Nur Jahr und Monat erstellt Belegbox selbst.',
      );
    }
    final create = http.Request('MKCOL', uri);
    create.headers.addAll(_headers(settings));
    create.followRedirects = false;
    final response = await client
        .send(create)
        .timeout(const Duration(seconds: 25));
    await response.stream.drain<void>();
    if (response.statusCode == 405) {
      // Could be a parallel create, but also a denied method. Verify it.
      await _ensureCollection(client, settings, uri, canCreate: false);
      return;
    }
    if (response.statusCode != 201) {
      throw StateError(_friendlyStatus(response.statusCode, settings));
    }
  }

  String _friendlyStatus(
    int status,
    SynologySettings settings,
  ) => switch (status) {
    401 => 'Anmeldung fehlgeschlagen. Benutzername und Passwort prüfen.',
    403 =>
      'Dieser NAS-Benutzer hat auf den angegebenen WebDAV-Ordner '
          'keinen ausreichenden Zugriff. Bitte Freigabe-, Lese- und '
          'Schreibberechtigungen kontrollieren.',
    404 => 'Freigegebener Ordner nicht gefunden. Ordnernamen prüfen.',
    405 => 'WebDAV ist möglicherweise nicht aktiviert.',
    200 =>
      'Die NAS antwortet auf die WebDAV-Ordnerprüfung nicht mit WebDAV. '
          'Bitte Port und WebDAV-/Reverse-Proxy-Adresse kontrollieren.',
    301 || 302 || 303 || 307 || 308 =>
      'Die NAS leitet auf eine andere Seite um. Bitte die direkte '
          'WebDAV-HTTPS-Adresse verwenden, nicht die DSM-Anmeldeseite.',
    409 => 'Der Zielordner existiert nicht.',
    412 =>
      'Ein PDF mit diesem Namen existiert bereits. Nichts wurde überschrieben.',
    413 => 'Die PDF-Datei überschreitet die erlaubte Größe.',
    507 => 'Auf ${settings.providerName} ist nicht genug Speicher frei.',
    _ => '${settings.providerName} meldet HTTP $status.',
  };
}

class RemoteDocumentExistsException implements Exception {
  const RemoteDocumentExistsException();

  @override
  String toString() =>
      'PDF existiert bereits auf der Synology. Die vorhandene Datei wird geprüft.';
}
