import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import '../services/image_crop_service.dart';

/// Editable rectangular crop for an imported PDF page or a camera image.
/// Scanner results are normally cropped already, but this permits correction.
class ImageCropPage extends StatefulWidget {
  const ImageCropPage({super.key, required this.path});

  final String path;

  @override
  State<ImageCropPage> createState() => _ImageCropPageState();
}

class _ImageCropPageState extends State<ImageCropPage> {
  late final Future<img.Image?> _source = _loadImage();
  Rect _crop = const Rect.fromLTRB(0.07, 0.07, 0.93, 0.93);
  int _dragging = -1;
  bool _saving = false;

  Future<img.Image?> _loadImage() async =>
      img.decodeImage(await File(widget.path).readAsBytes());

  void _beginDrag(Offset position, Size size) {
    final normalized = Offset(
      position.dx / size.width,
      position.dy / size.height,
    );
    final corners = [
      _crop.topLeft,
      _crop.topRight,
      _crop.bottomLeft,
      _crop.bottomRight,
    ];
    var closest = 1000.0;
    var index = -1;
    for (var i = 0; i < corners.length; i++) {
      final distance = (normalized - corners[i]).distance;
      if (distance < closest) {
        closest = distance;
        index = i;
      }
    }
    // A larger hit area lets a finger comfortably grab each green corner.
    _dragging = closest <= 0.12 ? index : (_crop.contains(normalized) ? 4 : -1);
  }

  void _drag(Offset delta, Size size) {
    if (_dragging == -1) return;
    final dx = delta.dx / size.width;
    final dy = delta.dy / size.height;
    final rect = _crop;
    final minW = 0.07;
    final minH = 0.035;
    setState(() {
      switch (_dragging) {
        case 0:
          _crop = Rect.fromLTRB(
            (rect.left + dx).clamp(0.0, rect.right - minW),
            (rect.top + dy).clamp(0.0, rect.bottom - minH),
            rect.right,
            rect.bottom,
          );
        case 1:
          _crop = Rect.fromLTRB(
            rect.left,
            (rect.top + dy).clamp(0.0, rect.bottom - minH),
            (rect.right + dx).clamp(rect.left + minW, 1.0),
            rect.bottom,
          );
        case 2:
          _crop = Rect.fromLTRB(
            (rect.left + dx).clamp(0.0, rect.right - minW),
            rect.top,
            rect.right,
            (rect.bottom + dy).clamp(rect.top + minH, 1.0),
          );
        case 3:
          _crop = Rect.fromLTRB(
            rect.left,
            rect.top,
            (rect.right + dx).clamp(rect.left + minW, 1.0),
            (rect.bottom + dy).clamp(rect.top + minH, 1.0),
          );
        case 4:
          final moveX = dx.clamp(-rect.left, 1.0 - rect.right);
          final moveY = dy.clamp(-rect.top, 1.0 - rect.bottom);
          _crop = rect.shift(Offset(moveX, moveY));
      }
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final saved = await const ImageCropService().saveCrop(
        widget.path,
        left: _crop.left,
        top: _crop.top,
        right: _crop.right,
        bottom: _crop.bottom,
      );
      if (mounted) Navigator.of(context).pop(saved);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ausschnitt konnte nicht gespeichert werden: $error'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Belegrand zuschneiden')),
    body: SafeArea(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text(
              'Ziehe die vier grünen Ecken auf den Belegrand. '
              'Du kannst auch den Rahmen als Ganzes verschieben.',
            ),
          ),
          Expanded(
            child: FutureBuilder<img.Image?>(
              future: _source,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Bild nicht lesbar: ${snapshot.error}'),
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final source = snapshot.data!;
                return LayoutBuilder(
                  builder: (context, constraints) {
                    final aspect = source.width / source.height;
                    final width = math.min(
                      constraints.maxWidth,
                      constraints.maxHeight * aspect,
                    );
                    final height = width / aspect;
                    final size = Size(width, height);
                    return Center(
                      child: SizedBox(
                        width: width,
                        height: height,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onPanStart: (details) =>
                              _beginDrag(details.localPosition, size),
                          onPanUpdate: (details) => _drag(details.delta, size),
                          onPanEnd: (_) => _dragging = -1,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.file(File(widget.path), fit: BoxFit.fill),
                              CustomPaint(painter: _CropOverlay(_crop)),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                OutlinedButton(
                  onPressed: _saving
                      ? null
                      : () => setState(
                          () => _crop = const Rect.fromLTRB(
                            0.07,
                            0.07,
                            0.93,
                            0.93,
                          ),
                        ),
                  child: const Text('Zurücksetzen'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: const Icon(Icons.crop),
                    label: Text(
                      _saving ? 'Bitte warten …' : 'Ausschnitt übernehmen',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class _CropOverlay extends CustomPainter {
  const _CropOverlay(this.normalized);
  final Rect normalized;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Offset.zero & size;
    final inner = Rect.fromLTRB(
      normalized.left * size.width,
      normalized.top * size.height,
      normalized.right * size.width,
      normalized.bottom * size.height,
    );
    canvas.drawPath(
      Path.combine(
        PathOperation.difference,
        Path()..addRect(outer),
        Path()..addRect(inner),
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.52),
    );
    canvas.drawRect(
      inner,
      Paint()
        ..color = const Color(0xFF54F5AC)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    for (final corner in [
      inner.topLeft,
      inner.topRight,
      inner.bottomLeft,
      inner.bottomRight,
    ]) {
      canvas.drawCircle(corner, 9, Paint()..color = const Color(0xFF09684C));
      canvas.drawCircle(corner, 6, Paint()..color = const Color(0xFFB6FFDD));
    }
  }

  @override
  bool shouldRepaint(covariant _CropOverlay oldDelegate) =>
      oldDelegate.normalized != normalized;
}
