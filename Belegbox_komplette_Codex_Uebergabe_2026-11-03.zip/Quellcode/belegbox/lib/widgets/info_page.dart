import 'package:flutter/material.dart';

/// These are beta/test notices, not a substitute for a professionally reviewed
/// privacy statement, licence or binding consumer terms.
class BelegboxInfoPage extends StatelessWidget {
  const BelegboxInfoPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Info & Rechtliches')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text(
          'Belegbox',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 4),
        Text('Version 0.5.2 Beta · Build 13 · 29.10.2026'),
        SizedBox(height: 20),
        _InfoSection(
          title: 'Urheberrecht und Herausgeber',
          text:
              '© 2026 Hallesche Gesellschaft für Informationssicherheit KG. '
              'Nach Angaben des Herausgebers liegen die Nutzungs- und '
              'Verwertungsrechte bei der HGI KG; Raimo Detzner wird als '
              'Urheber benannt. Die rechtliche Rechtezuordnung und eine '
              'Softwarelizenz sind vor einer öffentlichen Verteilung zu klären.',
        ),
        _InfoSection(
          title: 'Beta-Testversion',
          text:
              'Belegbox befindet sich in der Erprobung. Funktionen können '
              'unvollständig sein oder Fehler enthalten. Die Anwendung ist '
              'noch nicht für den unbeaufsichtigten produktiven Einsatz '
              'freigegeben. Bitte Rechnungsdaten mit dem Original vergleichen.',
        ),
        _InfoSection(
          title: 'Datenschutz – Stand der Prüfung',
          text:
              'Eine vollständige Prüfung und Dokumentation der '
              'DSGVO-Anforderungen steht noch aus. Diese Beta-Version ist '
              'derzeit nicht als DSGVO-konform freigegeben. Bei der KI-Nutzung '
              'werden Belegbilder nach erteilter Freigabe an OpenAI gesendet. '
              'Bei externen Cloud-Anbietern kann eine Übertragung an deren '
              'Infrastruktur erfolgen. Vertrauliche oder personenbezogene '
              'Belege nur mit geeigneter Rechtsgrundlage und Schutzmaßnahmen '
              'verarbeiten.',
        ),
        _InfoSection(
          title: 'Haftung und Nutzungsbedingungen – Entwurf',
          text:
              'Die Beta-Version wird zu Testzwecken bereitgestellt. '
              'Nutzer prüfen selbst die Richtigkeit der erkannten Daten '
              'und müssen geeignete Sicherungskopien vorhalten. Für '
              'Datenverluste, fehlerhafte Zuordnungen, Ausfälle oder '
              'unberechtigte Zugriffe kann im gesetzlich zulässigen Umfang '
              'eine Haftungsbegrenzung vorgesehen werden. Gesetzlich '
              'zwingende Haftungsansprüche bleiben unberührt. Dieser '
              'Hinweis ersetzt keine rechtlich geprüften AGB oder '
              'Datenschutzerklärung.',
        ),
        _InfoSection(
          title: 'Sicherheitsregeln',
          text:
              'Originalbelege aufbewahren. Cloud-Kopien werden erst dann '
              'als geprüft markiert, wenn ihr Inhalt nach dem Hochladen '
              'erneut verglichen wurde. Ein Android-Cloud-Anbieter kann '
              'Dateien zwischenspeichern: Eine lokale Kopierbestätigung '
              'garantiert keinen abgeschlossenen Upload auf seine Server.',
        ),
      ],
    ),
  );
}

class _InfoSection extends StatelessWidget {
  const _InfoSection({required this.title, required this.text});

  final String title;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 9),
            Text(text),
          ],
        ),
      ),
    ),
  );
}
