import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../services/cloud_folder_service.dart';
import '../services/local_archive.dart';

class LocalFolderPage extends StatefulWidget {
  const LocalFolderPage({
    super.key,
    required this.archive,
    required this.files,
  });

  final LocalArchive archive;
  final CloudFolderService files;

  @override
  State<LocalFolderPage> createState() => _LocalFolderPageState();
}

class _LocalFolderPageState extends State<LocalFolderPage> {
  late Future<({String path, Map<String, List<File>> groups})> _listing =
      _refresh();

  Future<({String path, Map<String, List<File>> groups})> _refresh() async {
    final root = await widget.archive.pdfDirectory();
    final groups = <String, List<File>>{};
    if (await root.exists()) {
      await for (final entity in root.list(recursive: true)) {
        if (entity is! File || !entity.path.toLowerCase().endsWith('.pdf')) {
          continue;
        }
        final relative = p.relative(entity.path, from: root.path);
        final month = p.dirname(relative).replaceAll(p.separator, ' / ');
        groups.putIfAbsent(month, () => []).add(entity);
      }
    }
    final ordered = Map.fromEntries(
      groups.entries.toList()..sort((a, b) => b.key.compareTo(a.key)),
    );
    for (final files in ordered.values) {
      files.sort((a, b) => a.path.compareTo(b.path));
    }
    return (path: root.path, groups: ordered);
  }

  Future<void> _open(File file) async {
    try {
      await widget.files.openPdf(file.path);
    } catch (error) {
      _show('PDF konnte nicht geöffnet werden: $error');
    }
  }

  Future<void> _export(File file) async {
    try {
      final saved = await widget.files.exportPdfAs(file.path);
      if (saved) _show('PDF-Kopie im ausgewählten Ordner gespeichert.');
    } catch (error) {
      _show('PDF konnte nicht exportiert werden: $error');
    }
  }

  void _show(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Lokaler PDF-Ordner'),
      actions: [
        IconButton(
          tooltip: 'Ordnerliste aktualisieren',
          onPressed: () => setState(() => _listing = _refresh()),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: FutureBuilder(
      future: _listing,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Fehler beim Lesen: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final data = snapshot.data!;
        return ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Text(
              'Hier sind alle PDFs, die noch lokal auf deinem Handy liegen. '
              'Tippe auf einen Dateinamen zum Öffnen. Mit dem Symbol rechts '
              'kannst du eine PDF zusätzlich in „Dokumente“ oder einen anderen '
              'sichtbaren Ordner exportieren.',
            ),
            const SizedBox(height: 14),
            SelectableText(
              'Interner Speicherort der App:\n${data.path}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            if (data.groups.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(18),
                  child: Text(
                    'Im lokalen PDF-Ordner liegen derzeit keine Dateien.',
                  ),
                ),
              ),
            for (final entry in data.groups.entries)
              Card(
                child: ExpansionTile(
                  initiallyExpanded: true,
                  leading: const Icon(Icons.folder_open),
                  title: Text(entry.key),
                  subtitle: Text('${entry.value.length} PDF-Datei(en)'),
                  children: [
                    for (final file in entry.value)
                      ListTile(
                        leading: const Icon(Icons.picture_as_pdf_outlined),
                        title: Text(p.basename(file.path)),
                        onTap: () => _open(file),
                        trailing: IconButton(
                          tooltip: 'PDF in sichtbaren Ordner exportieren',
                          icon: const Icon(Icons.save_alt),
                          onPressed: () => _export(file),
                        ),
                      ),
                  ],
                ),
              ),
            const SizedBox(height: 10),
            const Text(
              'Der geschützte App-Ordner ist in vielen Android-Dateimanagern '
              'nicht direkt sichtbar. Deshalb gibt es diese Ordneransicht '
              'innerhalb der Belegbox.',
              style: TextStyle(color: Colors.black54),
            ),
          ],
        );
      },
    ),
  );
}
