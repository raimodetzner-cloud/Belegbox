import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:belegbox/services/local_archive.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'Wiederherstellung übernimmt PDF und Belegdaten ohne alten Android-Pfad',
    () async {
      final base = await Directory.systemTemp.createTemp('belegbox_restore_');
      try {
        final oldArchive = LocalArchive(
          documentsDirectory: Directory('${base.path}/vorher'),
        );
        final original = await oldArchive.savePdf(
          pdfBytes: Uint8List.fromList([37, 80, 68, 70, 45, 49]),
          vendor: 'OBETA',
          date: DateTime(2026, 10, 21),
          totalCents: 4999,
        );
        final staging = Directory('${base.path}/sicherung/files');
        await staging.create(recursive: true);
        await File(
          '${base.path}/vorher/Belegbox/belege.json',
        ).copy('${staging.path}/belege.json');
        final source = File(original.localPath);
        final target = File(
          '${staging.path}/PDF-Eingang/2026/10/${original.fileName}',
        );
        await target.parent.create(recursive: true);
        await source.copy(target.path);

        final restoredArchive = LocalArchive(
          documentsDirectory: Directory('${base.path}/nachher'),
        );
        final report = await restoredArchive.mergeFromBackup(staging);
        expect(report.imported, 1);
        final recovered = (await restoredArchive.list()).single;
        expect(recovered.vendor, 'OBETA');
        expect(recovered.totalCents, 4999);
        expect(recovered.localPath, contains('/nachher/Belegbox/'));
        expect(
          await File(recovered.localPath).readAsBytes(),
          await source.readAsBytes(),
        );

        final repeated = await restoredArchive.mergeFromBackup(staging);
        expect(repeated.imported, 0);
        expect((await restoredArchive.list()).length, 1);
      } finally {
        await base.delete(recursive: true);
      }
    },
  );

  test(
    'Wiederherstellung lässt bereits vorhandenes anderes PDF unverändert',
    () async {
      final base = await Directory.systemTemp.createTemp('belegbox_merge_');
      try {
        final source = LocalArchive(
          documentsDirectory: Directory('${base.path}/s'),
        );
        final old = await source.savePdf(
          pdfBytes: Uint8List.fromList([1, 2, 3]),
          vendor: 'OBI',
          date: DateTime(2026, 10, 20),
          totalCents: 1000,
        );
        final targetArchive = LocalArchive(
          documentsDirectory: Directory('${base.path}/t'),
        );
        final already = await targetArchive.savePdf(
          pdfBytes: Uint8List.fromList([9, 8, 7]),
          vendor: 'OBI',
          date: DateTime(2026, 10, 20),
          totalCents: 1000,
        );
        final stage = Directory('${base.path}/stage');
        await stage.create(recursive: true);
        await File(
          '${base.path}/s/Belegbox/belege.json',
        ).copy('${stage.path}/belege.json');
        final copied = File(
          '${stage.path}/PDF-Eingang/2026/10/${old.fileName}',
        );
        await copied.parent.create(recursive: true);
        await File(old.localPath).copy(copied.path);
        final result = await targetArchive.mergeFromBackup(stage);
        expect(result.imported, 1);
        expect(await File(already.localPath).readAsBytes(), [9, 8, 7]);
        expect((await targetArchive.list()).length, 2);
        expect(
          (await targetArchive.list())
              .where((r) => r.fileName.contains('wiederhergestellt'))
              .length,
          1,
        );
      } finally {
        await base.delete(recursive: true);
      }
    },
  );

  test(
    'Gefährliche Dateinamen aus Sicherung werden nicht geschrieben',
    () async {
      final base = await Directory.systemTemp.createTemp('belegbox_traversal_');
      try {
        final stage = Directory('${base.path}/stage');
        await stage.create(recursive: true);
        await File('${stage.path}/belege.json').writeAsString(
          jsonEncode([
            {
              'id': '99',
              'fileName': '../bad.pdf',
              'localPath': '/irrelevant',
              'vendor': 'Test',
              'invoiceDate': '2026-10-28T00:00:00.000',
              'totalCents': 100,
              'createdAt': '2026-10-28T00:00:00.000',
              'uploaded': true,
            },
          ]),
        );
        final target = LocalArchive(
          documentsDirectory: Directory('${base.path}/t'),
        );
        final summary = await target.mergeFromBackup(stage);
        expect(summary.imported, 0);
        expect(summary.alreadyPresentOrSkipped, 1);
      } finally {
        await base.delete(recursive: true);
      }
    },
  );
}
