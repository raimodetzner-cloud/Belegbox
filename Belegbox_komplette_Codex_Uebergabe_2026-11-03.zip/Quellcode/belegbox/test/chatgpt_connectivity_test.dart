import 'package:belegbox/services/chatgpt_auth_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  test('ChatGPT-Verbindungstest kommt ohne Konto oder Synology aus', () async {
    final calls = <String>[];
    final client = MockClient((request) async {
      calls.add('${request.method} ${request.url.host}${request.url.path}');
      expect(request.headers.containsKey('authorization'), isFalse);
      if (request.url.host == 'api.openai.com') {
        return http.Response('', 401);
      }
      return http.Response('{}', 200);
    });
    final service = ChatGptAuthService(client: client);
    final result = await service.checkReachability();
    expect(result, contains('Anmeldung: erreichbar'));
    expect(result, contains('Signaturschlüssel: erreichbar'));
    expect(result, contains('OpenAI API: erreichbar'));
    expect(calls, hasLength(3));
  });

  test(
    'Fehlende OpenAI-Erreichbarkeit erscheint an der richtigen Stelle',
    () async {
      final client = MockClient(
        (_) async => throw http.ClientException(
          'Verbindung verweigert',
          Uri.parse('https://auth.openai.com'),
        ),
      );
      final result = await ChatGptAuthService(
        client: client,
      ).checkReachability();
      expect(result, contains('Anmeldung: Fehler'));
      expect(result, contains('Signaturschlüssel: Fehler'));
      expect(result, contains('OpenAI API: Fehler'));
    },
  );
}
