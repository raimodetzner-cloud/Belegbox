import 'dart:convert';

import 'package:belegbox/models/receipt.dart';
import 'package:belegbox/models/receipt_analysis.dart';
import 'package:belegbox/services/chatgpt_receipt_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('ChatGPT-JSON übernimmt alle Belegdaten und bucht Karte auf Bank', () {
    final receipt = ReceiptAnalysis.fromJson({
      'vendor': 'HORNBACH Baumarkt',
      'invoice_date': '2026-10-27',
      'gross_cents': 12849,
      'net_cents': 10797,
      'vat_cents': 2052,
      'payment_method': 'credit_card',
      'invoice_number': 'ABC 2710',
      'currency': 'EUR',
      'line_items': [
        {'description': 'Dübel', 'quantity': '2', 'gross_cents': 998},
        {'description': 'Schrauben', 'quantity': '1', 'gross_cents': 495},
      ],
      'note': null,
    });

    expect(receipt.vendor, 'HORNBACH Baumarkt');
    expect(receipt.invoiceDate, DateTime(2026, 10, 27));
    expect(receipt.grossCents, 12849);
    expect(receipt.paymentMethod, PaymentMethod.creditCard);
    expect(receipt.paymentMethod.bookingAccount, 'Bank');
    expect(receipt.lineItems.length, 2);
    expect(
      ReceiptAnalysis.fromJson(receipt.toJson()).paymentMethod,
      PaymentMethod.creditCard,
    );
  });

  test('Barzahlung wird Kasse, unklare Zahlung bleibt unbekannt', () {
    expect(PaymentMethod.cash.bookingAccount, 'Kasse');
    expect(PaymentMethod.girocard.bookingAccount, 'Bank');
    expect(PaymentMethod.transfer.bookingAccount, 'Bank');
    expect(PaymentMethod.fromValue('').bookingAccount, 'Unbekannt');
  });

  test(
    'Fehlerhafte Geldwerte und ungültige Datumsangaben werden ignoriert',
    () {
      final receipt = ReceiptAnalysis.fromJson({
        'vendor': '  OBI ',
        'invoice_date': '2026-02-30',
        'gross_cents': 12.5,
        'payment_method': 'unknown',
        'line_items': [],
      });
      expect(receipt.vendor, 'OBI');
      expect(receipt.invoiceDate, isNull);
      expect(receipt.grossCents, isNull);
      expect(receipt.paymentMethod.bookingAccount, 'Unbekannt');
    },
  );

  test('Alte gespeicherte Belege bleiben ohne AI-Metadaten lesbar', () {
    final legacy = SavedReceipt.fromJson({
      'id': '1',
      'fileName': 'bon.pdf',
      'localPath': '/tmp/bon.pdf',
      'vendor': 'OBI',
      'invoiceDate': '2026-10-27T00:00:00.000',
      'totalCents': 1500,
      'createdAt': '2026-10-27T12:00:00.000',
      'uploaded': true,
    });
    expect(legacy.analysis, isNull);
    expect(legacy.uploaded, isTrue);
  });

  test('SSE-Text wird erst nach erfolgreicher Completion freigegeben', () async {
    final messages = [
      'data: ${jsonEncode({'type': 'response.output_text.delta', 'delta': '{"vendor":"OBI"}'})}\n\n',
      'data: ${jsonEncode({
        'type': 'response.completed',
        'response': {'status': 'completed'},
      })}\n\n',
      'data: [DONE]\n\n',
    ];
    final value = await collectOpenAiText(
      Stream.fromIterable(messages.map(utf8.encode)),
    );
    expect(parseModelJson(value)['vendor'], 'OBI');
  });

  test('Abgebrochene Antwort darf nicht als fertiger Beleg gelten', () async {
    expect(
      collectOpenAiText(
        Stream.value(
          utf8.encode(
            'data: ${jsonEncode({'type': 'response.output_text.delta', 'delta': '{"vendor":"OBI"}'})}\n\n',
          ),
        ),
      ),
      throwsStateError,
    );
  });
}
