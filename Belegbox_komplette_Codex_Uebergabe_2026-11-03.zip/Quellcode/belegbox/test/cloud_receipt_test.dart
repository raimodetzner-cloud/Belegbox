import 'package:belegbox/models/receipt.dart';
import 'package:belegbox/services/cloud_folder_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Altarchiv ohne Cloud-Angaben bleibt lesbar', () {
    final saved = SavedReceipt.fromJson({
      'id': 'old',
      'fileName': 'old.pdf',
      'localPath': '/tmp/old.pdf',
      'vendor': 'OBI',
      'invoiceDate': '2026-10-27T00:00:00.000',
      'totalCents': 1299,
      'createdAt': '2026-10-27T12:00:00.000',
      'uploaded': true,
    });
    expect(saved.storageTarget, 'synology');
    expect(saved.cloudDocumentUri, isNull);
  });

  test('Cloud-Speicherort und Dokument-URI bleiben im Belegindex erhalten', () {
    final receipt = SavedReceipt(
      id: 'new',
      fileName: '2026-10-27_OBETA_12,99_B.pdf',
      localPath: '/tmp/beleg.pdf',
      vendor: 'OBETA',
      invoiceDate: DateTime(2026, 10, 27),
      totalCents: 1299,
      createdAt: DateTime(2026, 10, 27),
      uploaded: false,
      storageTarget: 'google_drive',
    ).copyWith(cloudDocumentUri: 'content://provider/document/4711');
    final reloaded = SavedReceipt.fromJson(receipt.toJson());
    expect(reloaded.storageTarget, 'google_drive');
    expect(reloaded.cloudDocumentUri, 'content://provider/document/4711');
    expect(reloaded.uploaded, isFalse);
  });

  test(
    'Cloud-Auswahl speichert Einstellungen ohne NAS-Daten zu überschreiben',
    () {
      final old = const CloudSelection(target: 'synology');
      final selected = old.copyWith(
        target: 'onedrive',
        oneDriveFolder: 'content://test/tree/onedrive',
        deleteAfterNasVerification: true,
      );
      expect(selected.folderFor('onedrive'), 'content://test/tree/onedrive');
      expect(selected.folderFor('google_drive'), isNull);
      expect(selected.deleteAfterNasVerification, true);
    },
  );
}
