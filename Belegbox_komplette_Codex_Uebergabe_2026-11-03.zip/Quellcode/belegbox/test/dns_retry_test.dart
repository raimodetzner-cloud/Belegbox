import 'dart:io';

import 'package:belegbox/services/dns_retry.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;

void main() {
  test('DNS-Fehler nach Browser-Rückkehr führt zu erneutem Versuch', () async {
    var attempts = 0;
    final notices = <String>[];
    final response = await retryDnsLookup(
      () async {
        attempts++;
        if (attempts < 3) {
          throw const SocketException('Failed host lookup: auth.openai.com');
        }
        return http.Response('ok', 200);
      },
      onRetry: (attempt, total) async => notices.add('$attempt/$total'),
      wait: (_) async {},
    );
    expect(response.statusCode, 200);
    expect(attempts, 3);
    expect(notices, ['1/5', '2/5']);
  });

  test('Nach fünf DNS-Versuchen endet der Ablauf mit Originalfehler', () async {
    var attempts = 0;
    await expectLater(
      retryDnsLookup(() async {
        attempts++;
        throw const SocketException('Failed host lookup: auth.openai.com');
      }, wait: (_) async {}),
      throwsA(isA<SocketException>()),
    );
    expect(attempts, 5);
  });

  test('HTTP-/OAuth-Fehler darf nicht wiederholt werden', () async {
    var attempts = 0;
    final result = await retryDnsLookup(() async {
      attempts++;
      return http.Response('{"error":"invalid_grant"}', 400);
    }, wait: (_) async {});
    expect(result.statusCode, 400);
    expect(attempts, 1);
  });

  test('Andere Netzwerkfehler dürfen nicht wiederholt werden', () async {
    var attempts = 0;
    await expectLater(
      retryDnsLookup(() async {
        attempts++;
        throw const SocketException('Connection reset by peer');
      }, wait: (_) async {}),
      throwsA(isA<SocketException>()),
    );
    expect(attempts, 1);
  });
}
