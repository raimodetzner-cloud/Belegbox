import 'dart:io';

import 'package:belegbox/services/image_crop_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;

void main() {
  const cutter = ImageCropService();

  test('Belegausschnitt hat nur die ausgewählten Pixel', () {
    final source = img.Image(width: 100, height: 200);
    final crop = ImageCropService.crop(
      source,
      left: 0.2,
      top: 0.1,
      right: 0.6,
      bottom: 0.5,
    );
    expect(crop.width, 40);
    expect(crop.height, 80);
  });

  test('Ungültige Rahmenkoordinaten werden abgewehrt', () {
    final source = img.Image(width: 100, height: 200);
    expect(
      () => ImageCropService.crop(
        source,
        left: 0.8,
        top: 0.2,
        right: 0.1,
        bottom: 0.7,
      ),
      throwsFormatException,
    );
    expect(
      () => ImageCropService.crop(
        source,
        left: -0.1,
        top: 0,
        right: 1,
        bottom: 1,
      ),
      throwsFormatException,
    );
  });

  test(
    'Zuschneiden erzeugt neue Datei und lässt das Original unverändert',
    () async {
      final directory = await Directory.systemTemp.createTemp('belegbox_crop_');
      try {
        final original = File('${directory.path}/original.png');
        await original.writeAsBytes(
          img.encodePng(img.Image(width: 120, height: 80)),
        );
        final before = await original.readAsBytes();
        final path = await cutter.saveCrop(
          original.path,
          left: 0.25,
          top: 0.25,
          right: 0.75,
          bottom: 0.75,
        );
        final cropped = img.decodeImage(await File(path).readAsBytes());
        expect(cropped?.width, 60);
        expect(cropped?.height, 40);
        expect(await original.readAsBytes(), before);
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );
}
