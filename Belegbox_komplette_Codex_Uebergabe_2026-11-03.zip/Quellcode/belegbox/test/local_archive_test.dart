import 'dart:io';
import 'dart:typed_data';

import 'package:belegbox/services/local_archive.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'Ohne Löschoption bleibt die PDF bei bestätigter Ablage lokal',
    () async {
      final directory = await Directory.systemTemp.createTemp('belegbox_keep_');
      try {
        final archive = LocalArchive(documentsDirectory: directory);
        final receipt = await archive.savePdf(
          pdfBytes: Uint8List.fromList([37, 80, 68, 70]),
          vendor: 'OBI',
          date: DateTime(2026, 10, 27),
          totalCents: 2750,
        );
        expect(receipt.localPath, contains('PDF-Eingang/2026/10/'));
        await archive.markUploaded(receipt.id);
        expect(await File(receipt.localPath).exists(), true);
        expect((await archive.list()).single.uploaded, true);
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );

  test(
    'Mit geprüfter NAS-Übertragung und Löschoption wird nur die lokale PDF entfernt',
    () async {
      final directory = await Directory.systemTemp.createTemp(
        'belegbox_delete_',
      );
      try {
        final archive = LocalArchive(documentsDirectory: directory);
        final receipt = await archive.savePdf(
          pdfBytes: Uint8List.fromList([37, 80, 68, 70]),
          vendor: 'OBETA',
          date: DateTime(2026, 10, 27),
          totalCents: 1590,
        );
        await archive.markUploaded(
          receipt.id,
          deleteLocalAfterVerification: true,
        );
        expect(await File(receipt.localPath).exists(), false);
        final remaining = (await archive.list()).single;
        expect(remaining.uploaded, true);
        expect(remaining.fileName, receipt.fileName);
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );

  test('Android-Cloud-Kopie löscht das lokale PDF niemals', () async {
    final directory = await Directory.systemTemp.createTemp('belegbox_cloud_');
    try {
      final archive = LocalArchive(documentsDirectory: directory);
      final receipt = await archive.savePdf(
        pdfBytes: Uint8List.fromList([37, 80, 68, 70]),
        vendor: 'HORNBACH',
        date: DateTime(2026, 10, 27),
        totalCents: 720,
        storageTarget: 'google_drive',
      );
      await archive.markCloudCopied(receipt.id, 'content://google/copy');
      expect(await File(receipt.localPath).exists(), true);
      final saved = (await archive.list()).single;
      expect(saved.cloudDocumentUri, 'content://google/copy');
      expect(saved.uploaded, false);
    } finally {
      await directory.delete(recursive: true);
    }
  });
}
