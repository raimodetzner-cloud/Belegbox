import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:belegbox/services/local_archive.dart';
import 'package:belegbox/services/synology_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  final pdf = Uint8List.fromList('%PDF-1.7\nTest'.codeUnits);

  test('Textliste enthält keine alten Handy-Pfade oder NAS-Passwörter', () async {
    final root = await Directory.systemTemp.createTemp('bb_manifest_');
    try {
      final archive = LocalArchive(documentsDirectory: root);
      final receipt = await archive.savePdf(
        pdfBytes: pdf,
        vendor: 'OBETA', date: DateTime(2026, 10, 28), totalCents: 3795,
      );
      await archive.markUploaded(receipt.id, remoteUri: 'https://nas.example/PDF-Eingang/2026/10/${receipt.fileName}');
      final manifest = await archive.exportManifestJson();
      final decoded = jsonDecode(manifest) as Map<String, dynamic>;
      expect(decoded['format'], 'belegbox-belegliste-v1');
      expect(decoded['receipts'], hasLength(1));
      expect(manifest, isNot(contains(receipt.localPath)));
      expect(manifest, isNot(contains('nas_password')));
      expect((decoded['receipts'] as List).first['sha256Digest'], isNotNull);
      expect((decoded['receipts'] as List).first['remoteUri'], contains('PDF-Eingang/2026/10')); 
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('JSON-Import verknüpft NAS-Belege, nicht aber ungesicherte lokale PDFs', () async {
    final root = await Directory.systemTemp.createTemp('bb_relink_');
    try {
      final origin = LocalArchive(documentsDirectory: Directory('${root.path}/a'));
      final cloud = await origin.savePdf(
        pdfBytes: pdf, vendor: 'HORNBACH',
        date: DateTime(2026, 10, 28), totalCents: 1000,
      );
      await origin.markUploaded(cloud.id);
      await origin.savePdf(
        pdfBytes: pdf, vendor: 'OBI',
        date: DateTime(2026, 10, 29), totalCents: 2000,
      );
      final destination = LocalArchive(documentsDirectory: Directory('${root.path}/b'));
      final report = await destination.mergeFromManifestJson(
        await origin.exportManifestJson(),
      );
      expect(report.imported, 1);
      expect(report.synologyOnly, 1);
      expect(report.alreadyPresentOrSkipped, 1);
      final saved = (await destination.list()).single;
      expect(saved.vendor, 'HORNBACH');
      expect(saved.uploaded, isTrue);
      expect(await File(saved.localPath).exists(), isFalse);
      expect((await destination.mergeFromManifestJson(await origin.exportManifestJson())).imported, 0);
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('Lokales Löschen entfernt exakt einen Beleg und lässt anderen bestehen', () async {
    final root = await Directory.systemTemp.createTemp('bb_local_delete_');
    try {
      final archive = LocalArchive(documentsDirectory: root);
      final a = await archive.savePdf(
        pdfBytes: pdf, vendor: 'OBI', date: DateTime(2026, 10, 10), totalCents: 100,
      );
      final b = await archive.savePdf(
        pdfBytes: pdf, vendor: 'OBI', date: DateTime(2026, 10, 10), totalCents: 100,
      );
      await archive.deleteReceipt(a.id);
      expect(await File(a.localPath).exists(), false);
      expect(await File(b.localPath).exists(), true);
      expect((await archive.list()).single.id, b.id);
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('WebDAV-Löschen prüft exakte Datei und bestätigt HTTP 404 danach', () async {
    final root = await Directory.systemTemp.createTemp('bb_remote_delete_');
    try {
      final archive = LocalArchive(documentsDirectory: root);
      final receipt = await archive.savePdf(
        pdfBytes: pdf, vendor: 'OBETA', date: DateTime(2026, 10, 28), totalCents: 1250,
      );
      await archive.markUploaded(receipt.id);
      final calls = <String>[];
      var deleted = false;
      final client = MockClient((request) async {
        calls.add(request.method);
        if (request.method == 'GET') {
          return deleted ? http.Response('', 404) : http.Response.bytes(pdf, 200, headers: {'etag': '"abc"'});
        }
        if (request.method == 'DELETE') {
          deleted = true;
          return http.Response('', 204);
        }
        return http.Response('', 405);
      });
      const nas = SynologySettings(
        url: 'https://nas.example:5006', sharedFolder: 'PDF-Eingang',
        user: 'test', password: 'secret',
      );
      await SynologyService(client: client).deleteRemoteCopy(nas, (await archive.list()).single);
      expect(calls, ['GET', 'DELETE', 'GET']);
      expect(deleted, true);
      expect(await File(receipt.localPath).exists(), true);
    } finally {
      await root.delete(recursive: true);
    }
  });

  test('Geänderte NAS-PDF wird nicht gelöscht', () async {
    final root = await Directory.systemTemp.createTemp('bb_safe_delete_');
    try {
      final archive = LocalArchive(documentsDirectory: root);
      final receipt = await archive.savePdf(
        pdfBytes: pdf, vendor: 'OBETA', date: DateTime(2026, 10, 28), totalCents: 1250,
      );
      await archive.markUploaded(receipt.id);
      final calls = <String>[];
      final client = MockClient((request) async {
        calls.add(request.method);
        return http.Response.bytes('%PDF-1.7\nANDERS'.codeUnits, 200);
      });
      const nas = SynologySettings(
        url: 'https://nas.example:5006', sharedFolder: 'PDF-Eingang',
        user: 'test', password: 'secret',
      );
      await expectLater(
        SynologyService(client: client).deleteRemoteCopy(nas, (await archive.list()).single),
        throwsStateError,
      );
      expect(calls, ['GET']);
      expect(await File(receipt.localPath).exists(), true);
      expect((await archive.list()).single.uploaded, true);
    } finally {
      await root.delete(recursive: true);
    }
  });
}

test('Neue Verbindung darf niemals eine andere NAS-Datei löschen', () async {
  final root = await Directory.systemTemp.createTemp('bb_wrong_nas_');
  try {
    final archive = LocalArchive(documentsDirectory: root);
    final receipt = await archive.savePdf(
      pdfBytes: Uint8List.fromList('%PDF-1.7'.codeUnits),
      vendor: 'OBI', date: DateTime(2026, 10, 29), totalCents: 2000,
    );
    await archive.markUploaded(
      receipt.id,
      remoteUri: 'https://andere-nas.example/PDF-Eingang/2026/10/${receipt.fileName}',
    );
    var requests = 0;
    final client = MockClient((request) async {
      requests++;
      return http.Response('', 200);
    });
    const nas = SynologySettings(
      url: 'https://nas.example:5006', sharedFolder: 'PDF-Eingang',
      user: 'test', password: 'secret',
    );
    await expectLater(
      SynologyService(client: client).deleteRemoteCopy(nas, (await archive.list()).single),
      throwsStateError,
    );
    expect(requests, 0);
    expect(await File(receipt.localPath).exists(), isTrue);
  } finally {
    await root.delete(recursive: true);
  }
});
