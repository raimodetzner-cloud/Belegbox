import 'dart:io';

import 'package:belegbox/models/receipt_analysis.dart';
import 'package:belegbox/services/pdf_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('Erzeugt Originalbeleg plus KI-Auswertung als PDF', () async {
    final directory = await Directory.systemTemp.createTemp('belegbox_pdf_');
    try {
      final file = File('${directory.path}/beleg.jpg');
      final photo = img.Image(width: 200, height: 300);
      img.fill(photo, color: img.ColorRgb8(255, 255, 255));
      await file.writeAsBytes(img.encodeJpg(photo));
      final analysis = ReceiptAnalysis(
        vendor: 'HORNBACH',
        invoiceDate: DateTime(2026, 10, 27),
        grossCents: 1599,
        paymentMethod: PaymentMethod.girocard,
        lineItems: const [
          ReceiptItem(description: 'Schrauben', grossCents: 1599),
        ],
      );
      final pdf = await PdfService().create(
        photos: [XFile(file.path)],
        vendor: analysis.vendor,
        analysis: analysis,
      );
      expect(pdf.length, greaterThan(1000));
      expect(String.fromCharCodes(pdf.take(4)), '%PDF');
    } finally {
      await directory.delete(recursive: true);
    }
  });
}
