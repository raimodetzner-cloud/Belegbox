import 'package:flutter_test/flutter_test.dart';
import 'package:belegbox/services/receipt_parser.dart';

void main() {
  test('HORNBACH-Kassenbon wird erkannt', () {
    const text = '''
HORNBACH Baumarkt
Datum: 27.10.2026
Holzschrauben     12,49
Kabel               8,51
MwSt 19%            3,35
Gesamtsumme EUR    21,00
Gegeben            30,00
Rueckgeld           9,00
''';
    final result = ReceiptParser.parse(text);
    expect(result.vendor, 'HORNBACH');
    expect(result.date, DateTime(2026, 10, 27));
    expect(result.totalCents, 2100);
  });

  test('OBI-Beleg mit Tausendertrennzeichen', () {
    const text = '''
OBI GmbH
Rechnungsdatum 02.09.2026
Endbetrag 1.234,56 EUR
19% USt 197,14 EUR
''';
    final result = ReceiptParser.parse(text);
    expect(result.vendor, 'OBI');
    expect(result.totalCents, 123456);
    expect(result.date, DateTime(2026, 9, 2));
  });

  test('Beträge bleiben centgenau', () {
    expect(ReceiptParser.parseEuro('1.234,56 €'), 123456);
    expect(ReceiptParser.parseEuro('159,90'), 15990);
    expect(ReceiptParser.parseEuro('9.99'), 999);
    expect(ReceiptParser.parseEuro('-10,00'), isNull);
    expect(ReceiptParser.parseEuro('1,2,3'), isNull);
  });

  test('Fehlerhafte Datumswerte werden nicht erfunden', () {
    expect(ReceiptParser.parseDate('31.02.2026'), isNull);
    expect(ReceiptParser.parseDate('27.10.2026'), DateTime(2026, 10, 27));
  });

  test('Fehlender OCR-Text ergibt leere, editierbare Felder', () {
    final result = ReceiptParser.parse('');
    expect(result.vendor, isEmpty);
    expect(result.date, isNull);
    expect(result.totalCents, isNull);
  });
}
