import 'package:belegbox/models/receipt_analysis.dart';
import 'package:belegbox/services/receipt_paths.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final date = DateTime(2026, 10, 27);

  test('Ordner Jahr und Monat aus dem Belegdatum, nicht dem Scan-Datum', () {
    expect(ReceiptPaths.year(date), '2026');
    expect(ReceiptPaths.month(date), '10');
    expect(ReceiptPaths.month(DateTime(2025, 1, 2)), '01');
  });

  test('Bankbon bekommt B, Barbon K und unklarer Bon U', () {
    expect(
      ReceiptPaths.baseFileName(
        receiptDate: date,
        vendor: 'HORNBACH Baumarkt',
        grossCents: 3795,
        paymentMethod: PaymentMethod.creditCard,
      ),
      '2026-10-27_HORNBACH_Baumarkt_37,95_B',
    );
    expect(
      ReceiptPaths.baseFileName(
        receiptDate: date,
        vendor: 'OBI',
        grossCents: 599,
        paymentMethod: PaymentMethod.cash,
      ),
      '2026-10-27_OBI_5,99_K',
    );
    expect(ReceiptPaths.accountLetter(PaymentMethod.unknown), 'U');
  });

  test('Sonderzeichen in Firmennamen erzeugen keinen Unterordner', () {
    final name = ReceiptPaths.baseFileName(
      receiptDate: date,
      vendor: '../Meine Firma / GmbH',
      grossCents: 100,
      paymentMethod: PaymentMethod.debitCard,
    );
    expect(name, isNot(contains('/')));
    expect(name, endsWith('_1,00_B'));
  });
}
