import 'dart:io';

import 'package:belegbox/models/receipt.dart';
import 'package:belegbox/models/receipt_analysis.dart';
import 'package:belegbox/services/receipt_paths.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:belegbox/services/synology_service.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  const good = SynologySettings(
    url: 'https://nas.example:5006',
    sharedFolder: 'PDF-Eingang',
    user: 'scanner',
    password: 'test',
  );

  test('Datei landet im Eingangsordner, darunter Jahr und Monat', () {
    expect(
      good.collectionUri().toString(),
      'https://nas.example:5006/PDF-Eingang/',
    );
    expect(good.yearUri(DateTime(2026, 10, 27)).pathSegments, [
      'PDF-Eingang',
      '2026',
      '',
    ]);
    expect(good.monthUri(DateTime(2026, 10, 27)).pathSegments, [
      'PDF-Eingang',
      '2026',
      '10',
      '',
    ]);
    expect(
      good
          .documentUri(
            '2026-10-27_HORNBACH_21,00_B.pdf',
            date: DateTime(2026, 10, 27),
          )
          .pathSegments,
      ['PDF-Eingang', '2026', '10', '2026-10-27_HORNBACH_21,00_B.pdf'],
    );
  });

  test('Unverschlüsseltes WebDAV wird abgelehnt', () {
    const insecure = SynologySettings(
      url: 'http://nas.example:5005',
      sharedFolder: 'PDF-Eingang',
      user: 'x',
      password: 'y',
    );
    expect(() => insecure.baseUri, throwsFormatException);
  });

  test('Direktes WebDAV mit bestehendem Unterordner und URL-Präfix', () {
    const nested = SynologySettings(
      url: 'https://nas.example/webdav/',
      sharedFolder: 'Firma/Belege/Eingang',
      user: 'scanner',
      password: 'test',
    );
    expect(nested.configuredFolderUris.map((uri) => uri.path).toList(), [
      '/webdav/Firma/',
      '/webdav/Firma/Belege/',
      '/webdav/Firma/Belege/Eingang/',
    ]);
    expect(
      nested.monthUri(DateTime(2026, 10)).toString(),
      'https://nas.example/webdav/Firma/Belege/Eingang/2026/10/',
    );
    expect(
      nested
          .documentUri('27.10_HORNBACH_21,00_B.pdf', date: DateTime(2026, 10))
          .path,
      '/webdav/Firma/Belege/Eingang/2026/10/27.10_HORNBACH_21,00_B.pdf',
    );
  });

  test('Pfadsegmente mit Leerzeichen werden korrekt URL-codiert', () {
    const nested = SynologySettings(
      url: 'https://nas.example:5006',
      sharedFolder: 'Meine Daten/Belege 2026',
      user: 'scanner',
      password: 'test',
    );
    expect(
      nested.collectionUri().toString(),
      'https://nas.example:5006/Meine%20Daten/Belege%202026/',
    );
  });

  test('QNAP legt PDF im freigegebenen Jahres- und Monatsordner ab', () async {
    const qnap = SynologySettings(
      url: 'https://qnap.example:5001',
      sharedFolder: 'PDF-Eingang',
      user: 'belegbox_qnap',
      password: 'sicher',
      providerName: 'QNAP',
    );
    final directory = await Directory.systemTemp.createTemp('belegbox_qnap_');
    try {
      final file = File('${directory.path}/bon.pdf');
      final pdf = <int>[37, 80, 68, 70, 45, 49, 46, 55];
      await file.writeAsBytes(pdf);
      final calls = <String>[];
      final client = MockClient((request) async {
        expect(request.url.host, 'qnap.example');
        expect(request.url.port, 5001);
        expect(request.headers['authorization'], isNotNull);
        calls.add('${request.method} ${request.url.path}');
        return switch (request.method) {
          'PROPFIND' => http.Response(
            '',
            request.url.path == '/PDF-Eingang/' ? 207 : 404,
          ),
          'MKCOL' => http.Response('', 201),
          'PUT' => http.Response('', 201),
          'GET' => http.Response.bytes(pdf, 200),
          _ => http.Response('', 405),
        };
      });
      final receipt = _receiptFor(file);
      await SynologyService(client: client).testConnection(qnap);
      await SynologyService(client: client).uploadAndVerify(qnap, receipt);
      expect(calls, [
        'PROPFIND /PDF-Eingang/',
        'PROPFIND /PDF-Eingang/',
        'PROPFIND /PDF-Eingang/2026/',
        'MKCOL /PDF-Eingang/2026/',
        'PROPFIND /PDF-Eingang/2026/10/',
        'MKCOL /PDF-Eingang/2026/10/',
        'PUT /PDF-Eingang/2026/10/2026-10-27_OBETA_10,00_B.pdf',
        'GET /PDF-Eingang/2026/10/2026-10-27_OBETA_10,00_B.pdf',
      ]);
      expect(await file.exists(), isTrue);
    } finally {
      await directory.delete(recursive: true);
    }
  });

  test('Pfadüberschreitungen werden abgelehnt', () {
    const invalid = SynologySettings(
      url: 'https://nas.example:5006',
      sharedFolder: '../Sonstiges',
      user: 'x',
      password: 'y',
    );
    expect(() => invalid.cleanFolder, throwsFormatException);
    for (final invalidPath in [
      'Daten//Belege',
      'Daten/../Privat',
      'Daten/./Belege',
      'Daten\\Belege',
    ]) {
      expect(
        () => SynologySettings(
          url: 'https://nas.example:5006',
          sharedFolder: invalidPath,
          user: 'x',
          password: 'y',
        ).cleanFolder,
        throwsFormatException,
      );
    }
    expect(
      () => good.documentUri('../x.pdf', date: DateTime(2026, 10, 27)),
      throwsFormatException,
    );
  });

  test('Verbindung prüft jeden konfigurierten NAS-Unterordner', () async {
    const nested = SynologySettings(
      url: 'https://nas.example:5006',
      sharedFolder: 'Daten/Belege/2026-Eingang',
      user: 'scanner',
      password: 'passwort',
    );
    final paths = <String>[];
    final client = MockClient((request) async {
      expect(request.method, 'PROPFIND');
      expect(request.headers['depth'], '0');
      paths.add(request.url.path);
      return http.Response('', 207);
    });
    await SynologyService(client: client).testConnection(nested);
    expect(paths, ['/Daten/', '/Daten/Belege/', '/Daten/Belege/2026-Eingang/']);
  });

  test(
    'Upload in bestehenden Unterordner legt nur Jahr und Monat an',
    () async {
      const nested = SynologySettings(
        url: 'https://nas.example:5006',
        sharedFolder: 'Daten/Belege',
        user: 'scanner',
        password: 'passwort',
      );
      final directory = await Directory.systemTemp.createTemp(
        'belegbox_nested_',
      );
      try {
        final file = File('${directory.path}/bon.pdf');
        await file.writeAsBytes([37, 80, 68, 70]);
        final calls = <String>[];
        final client = MockClient((request) async {
          calls.add('${request.method} ${request.url.path}');
          if (request.method == 'PROPFIND') {
            return http.Response(
              '',
              request.url.path == '/Daten/' ||
                      request.url.path == '/Daten/Belege/'
                  ? 207
                  : 404,
            );
          }
          if (request.method == 'MKCOL') return http.Response('', 201);
          if (request.method == 'PUT') return http.Response('', 201);
          return http.Response('', 405);
        });
        await SynologyService(client: client).upload(nested, _receiptFor(file));
        expect(calls, [
          'PROPFIND /Daten/',
          'PROPFIND /Daten/Belege/',
          'PROPFIND /Daten/Belege/2026/',
          'MKCOL /Daten/Belege/2026/',
          'PROPFIND /Daten/Belege/2026/10/',
          'MKCOL /Daten/Belege/2026/10/',
          'PUT /Daten/Belege/2026/10/2026-10-27_OBETA_10,00_B.pdf',
        ]);
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );

  test('Fehlender freigegebener Unterordner wird genau gemeldet', () async {
    const nested = SynologySettings(
      url: 'https://nas.example:5006',
      sharedFolder: 'Daten/Belege',
      user: 'scanner',
      password: 'passwort',
    );
    final client = MockClient((request) async {
      if (request.url.path == '/Daten/') return http.Response('', 207);
      return http.Response('', 404);
    });
    await expectLater(
      SynologyService(client: client).testConnection(nested),
      throwsA(
        isA<StateError>().having(
          (error) => error.toString(),
          'unterordner',
          contains('/Daten/Belege/'),
        ),
      ),
    );
  });

  test('HTTP 200 statt WebDAV-207 ist keine erfolgreiche Prüfung', () async {
    final client = MockClient((request) async => http.Response('<html/>', 200));
    await expectLater(
      SynologyService(client: client).testConnection(good),
      throwsStateError,
    );
  });

  test('Synology-Jahres- und Monatsordner werden vor Upload angelegt', () async {
    final directory = await Directory.systemTemp.createTemp('belegbox_dav_');
    try {
      final file = File('${directory.path}/bon.pdf');
      await file.writeAsBytes([37, 80, 68, 70]);
      final calls = <String>[];
      final client = MockClient((request) async {
        calls.add('${request.method} ${request.url.path}');
        if (request.method == 'PROPFIND') {
          return http.Response(
            '',
            request.url.path == '/PDF-Eingang/' ? 207 : 404,
          );
        }
        if (request.method == 'MKCOL') return http.Response('', 201);
        if (request.method == 'PUT') {
          expect(request.headers['if-none-match'], '*');
          return http.Response('', 201);
        }
        return http.Response('', 405);
      });
      final receipt = SavedReceipt(
        id: 'abc',
        fileName:
            '${ReceiptPaths.baseFileName(receiptDate: DateTime(2026, 10, 27), vendor: 'OBI', grossCents: 500, paymentMethod: PaymentMethod.unknown)}.pdf',
        localPath: file.path,
        vendor: 'OBI',
        invoiceDate: DateTime(2026, 10, 27),
        totalCents: 500,
        createdAt: DateTime.now(),
        uploaded: false,
      );
      await SynologyService(client: client).upload(good, receipt);
      expect(calls, [
        'PROPFIND /PDF-Eingang/',
        'PROPFIND /PDF-Eingang/2026/',
        'MKCOL /PDF-Eingang/2026/',
        'PROPFIND /PDF-Eingang/2026/10/',
        'MKCOL /PDF-Eingang/2026/10/',
        'PUT /PDF-Eingang/2026/10/2026-10-27_OBI_5,00_U.pdf',
      ]);
    } finally {
      await directory.delete(recursive: true);
    }
  });

  test(
    'Synology-PDF wird nach PUT vollständig erneut gelesen und geprüft',
    () async {
      final directory = await Directory.systemTemp.createTemp(
        'belegbox_verify_',
      );
      try {
        final file = File('${directory.path}/rechnung.pdf');
        final original = <int>[37, 80, 68, 70, 45, 49, 46, 55];
        await file.writeAsBytes(original);
        final calls = <String>[];
        final client = MockClient((request) async {
          calls.add(request.method);
          return switch (request.method) {
            'PROPFIND' => http.Response('', 207),
            'PUT' => http.Response('', 201),
            'GET' => http.Response.bytes(original, 200),
            _ => http.Response('', 405),
          };
        });
        await SynologyService(
          client: client,
        ).uploadAndVerify(good, _receiptFor(file));
        expect(calls.last, 'GET');
        expect(await file.exists(), true);
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );

  test('Abweichende NAS-Datei gilt nicht als sichere Kopie', () async {
    final directory = await Directory.systemTemp.createTemp('belegbox_wrong_');
    try {
      final file = File('${directory.path}/rechnung.pdf');
      await file.writeAsBytes([37, 80, 68, 70]);
      final client = MockClient(
        (request) async => switch (request.method) {
          'PROPFIND' => http.Response('', 207),
          'PUT' => http.Response('', 201),
          'GET' => http.Response.bytes([37, 80, 68, 71], 200),
          _ => http.Response('', 405),
        },
      );
      await expectLater(
        SynologyService(
          client: client,
        ).uploadAndVerify(good, _receiptFor(file)),
        throwsStateError,
      );
      expect(await file.readAsBytes(), [37, 80, 68, 70]);
    } finally {
      await directory.delete(recursive: true);
    }
  });

  test(
    'Nach abgebrochener PUT-Bestätigung ist eine identische Kopie gültig',
    () async {
      final directory = await Directory.systemTemp.createTemp('belegbox_same_');
      try {
        final file = File('${directory.path}/rechnung.pdf');
        await file.writeAsBytes([37, 80, 68, 70]);
        final client = MockClient(
          (request) async => switch (request.method) {
            'PROPFIND' => http.Response('', 207),
            'PUT' => http.Response('', 412),
            'GET' => http.Response.bytes([37, 80, 68, 70], 200),
            _ => http.Response('', 405),
          },
        );
        await SynologyService(
          client: client,
        ).uploadAndVerify(good, _receiptFor(file));
      } finally {
        await directory.delete(recursive: true);
      }
    },
  );
}

SavedReceipt _receiptFor(File file) => SavedReceipt(
  id: 'verify',
  fileName: '2026-10-27_OBETA_10,00_B.pdf',
  localPath: file.path,
  vendor: 'OBETA',
  invoiceDate: DateTime(2026, 10, 27),
  totalCents: 1000,
  createdAt: DateTime.now(),
  uploaded: false,
);
