import 'package:belegbox/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Startbildschirm zeigt den Belegscanner', (tester) async {
    await tester.pumpWidget(const BelegboxApp());
    expect(find.text('Belegbox'), findsOneWidget);
    expect(find.text('Aus Galerie auswählen'), findsOneWidget);
  });
  testWidgets('Info-Button zeigt Beta-Version und Datenschutz-Hinweis', (
    tester,
  ) async {
    await tester.pumpWidget(const BelegboxApp());
    await tester.tap(find.byTooltip('Info & Rechtliches'));
    await tester.pumpAndSettle();
    expect(find.text('Info & Rechtliches'), findsOneWidget);
    expect(find.textContaining('Version 0.5.1 Beta'), findsOneWidget);
  });
}
