// Einmal nach "flutter create . --platforms=android,ios" ausführen.
// Ergänzt native Berechtigungen und die für ML Kit nötige iOS-Version.
import 'dart:io';

void main() {
  final iosPlist = File('ios/Runner/Info.plist');
  if (iosPlist.existsSync()) {
    var contents = iosPlist.readAsStringSync();
    if (!contents.contains('<key>NSCameraUsageDescription</key>')) {
      final index = contents.lastIndexOf('</dict>');
      if (index < 0) throw StateError('iOS Info.plist ist ungültig.');
      contents = contents.replaceRange(index, index, '''
  <key>NSCameraUsageDescription</key>
  <string>Belege fotografieren und als PDF speichern.</string>
  <key>NSPhotoLibraryUsageDescription</key>
  <string>Bereits fotografierte Rechnungen auswählen.</string>
''');
      iosPlist.writeAsStringSync(contents);
    }
  }

  final podfile = File('ios/Podfile');
  if (podfile.existsSync()) {
    var contents = podfile.readAsStringSync();
    final declaration = RegExp(
      r'''^\s*#?\s*platform\s+:ios,\s*['\"]\d+(?:\.\d+)*['\"].*$''',
      multiLine: true,
    );
    contents = declaration.hasMatch(contents)
        ? contents.replaceFirst(declaration, "platform :ios, '15.5'")
        : "platform :ios, '15.5'\n$contents";
    podfile.writeAsStringSync(contents);
  }

  final project = File('ios/Runner.xcodeproj/project.pbxproj');
  if (project.existsSync()) {
    var contents = project.readAsStringSync();
    contents = contents.replaceAll(
      RegExp(r'IPHONEOS_DEPLOYMENT_TARGET = [0-9.]+;'),
      'IPHONEOS_DEPLOYMENT_TARGET = 15.5;',
    );
    project.writeAsStringSync(contents);
  }

  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (manifest.existsSync()) {
    var contents = manifest.readAsStringSync();
    if (!contents.contains('android.permission.INTERNET')) {
      final manifestStart = contents.indexOf('<manifest');
      final openTag = manifestStart < 0
          ? -1
          : contents.indexOf('>', manifestStart);
      if (openTag < 0) throw StateError('AndroidManifest.xml ist ungültig.');
      contents = contents.replaceRange(
        openTag + 1,
        openTag + 1,
        '\n    <uses-permission android:name="android.permission.INTERNET"/>',
      );
      manifest.writeAsStringSync(contents);
    }
  }
  stdout.writeln('Native Plattformkonfiguration erledigt.');
}
